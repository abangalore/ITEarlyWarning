#!/usr/bin/env perl
###############################################################################
#   afick_common.pl
#      it's a part of the afick project
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# common sub and var for afick's tool
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

use strict;
use warnings;

use English qw(-no_match_vars);
use POSIX qw(strftime);
use File::Basename;

#use FindBin qw($Bin);
#use Data::Dumper;

##########################################################################
# afick current version : to be common for afick and afick-tk
sub get_afick_version() {
	return '3.6.0';
}
###############################################################################
# where are installed afick modules (.pm)
# will be used to load packages
# and for auto-control
sub get_module_dir() {

	# get bin dir
	# way 1
	my $bin_dir = dirname($PROGRAM_NAME);

	# way 2 (FindBin)
	# my $bin_dir = $Bin;

	my $win_dir   = $bin_dir . '/lib';
	my $tgz_dir   = $bin_dir . '/../lib';
	my $linux_dir = '/usr/lib/afick/lib';

	my $newdir;
	if ( -e "$win_dir/Afick" ) {

		# for windows and tests
		$newdir = $win_dir;
	}
	elsif ( -d "$tgz_dir/Afick" ) {

		# tar.gz install on /usr/local , /opt
		# opt / afick / bin
		#             / lib
		$newdir = $tgz_dir;
	}
	elsif ( -d $linux_dir ) {

		# for linux rpm/deb
		$newdir = $linux_dir;
	}
	else {
		die "no lib directory found, check installation\n";
	}
	return $newdir;
}
##########################################################################
# load libraries from given list
sub load_modules(@) {
	my @modules = @_;

	foreach my $module (@modules) {
		## no critic (ProhibitStringyEval,RequireCheckingReturnValueOfEval)
		eval "require $module";
		if ($EVAL_ERROR) {
			die "CRITICAL : can not find $module : $EVAL_ERROR\n";
		}
		else {
			import $module;
		}
	}
	return;
}
##########################################################################
my $module_dir = get_module_dir();
push @INC, $module_dir;

my @common_modules = (
	'Afick::Constant',
	'Afick::Msg',
	'Afick::Lock',
	'Afick::Tst',
	'Afick::Gen',
	'Afick::Directives',
	'Afick::Macros',
	'Afick::Aliases',
	'Afick::Cfg',
	'Afick::Log',
	'Afick::Backend',
	'Afick::Control',
	'Afick::Learn',
	'Afick::Report',
	'Afick::Object',
	'Afick::Plugins',

	#'Afick::File',
	#'Afick::Res',
);

my @windows_modules = ( 'Afick::WinAcl', );

load_modules(@common_modules);

load_modules(@windows_modules) if ( is_microsoft() );

1;
