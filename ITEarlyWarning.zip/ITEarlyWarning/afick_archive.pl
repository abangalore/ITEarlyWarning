#!/usr/bin/env perl
###############################################################################
#    Copyright (C) 2002-2204 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# afick_archive is a tool to manage history file and archive directory
#
###############################################################################

use strict;
use warnings;
use English '-no_match_vars';
use Pod::Usage;
use Getopt::Long;    # option analysis

# debuggging
# use diagnostics;
# use Data::Dumper;
# use Carp qw(cluck);	# debugging

use File::Basename;    # for path
my $dirname = dirname($PROGRAM_NAME);
require $dirname . '/afick-common.pl';

###############################################################################
#                     global variables
###############################################################################

my $Version = '0.8';

my $EMPTY = Afick::Constant->EMPTY;
#############################################################
# just display program version
sub version($) {
	my $version = shift @_;
	print "\n";
	print
"afick_archive : another file integrity checker tool for history/archive\nversion $version\n";
	return;
}
#############################################################
# get date of previous run from report file
# and type of run : init, update, compare
sub get_info($) {
	my $fic = shift @_;

	my ( $type, $date );

	my $log = Afick::Log->new();
	if ( $log->parse_file($fic) ) {
		my %meta_run = $log->get_run();
		$type = $meta_run{'action'};
		$date = $EMPTY;
		if ( exists $meta_run{'previous_run_date'} ) {
			$date =
			    $meta_run{'previous_run_date'} . q{ }
			  . $meta_run{'previous_run_time'};

			# parse date and transform to such as file name
			$date =~ s/://g;
			$date =~ s/ //g;
			$date =~ s/\///g;
		}
	}

	return ( $type, $date );
}

#############################################################
# transform a date in human format
sub human_date($) {
	my $date       = shift @_;
	my $human_date = $EMPTY;

	# date
	my ( $year, $month, $day );

	# time
	my ( $hour, $min, $sec );
	if ( $date =~ m/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)/ ) {
		$year  = $1;
		$month = $2;
		$day   = $3;
		$hour  = $4;
		$min   = $5;
		$sec   = $6;

		$human_date = "$year/$month/$day $hour:$min:$sec";
	}

	return $human_date;
}
#############################################################
# return the list of reports file in archive directory
# sorted by date
sub get_reports_list($) {
	my $archive_dir = shift @_;

	if ( -d $archive_dir ) {
		if ( opendir my $fh_arc, $archive_dir ) {

			# we read reports files form archive directory
			# and sort the list to have them sort from old to last
			my @reports = sort grep /^afick/, readdir $fh_arc;
			closedir $fh_arc
			  or Afick::Msg->warning(
				"can not close archive directory $archive_dir: $ERRNO");
			return @reports;
		}
		else {
			Afick::Msg->warning(
				"can not open archive directory $archive_dir: $ERRNO");
			exit;
		}
	}
	else {
		Afick::Msg->warning("$archive_dir is not a directory");
		exit;
	}

	# just for perlcritic
	return;
}
#############################################################
# suppress reports from archive directory
# older than $period
sub clean_archive($$$) {
	my $period      = shift @_;
	my $archive_dir = shift @_;
	my $dry_run     = shift @_;

	my $age = is_retention($period);
	if ( !defined $age ) {
		Afick::Msg->warning( Afick::Msg->get_error() );
		exit;
	}

	# convert to seconds
	$age *= 86_400;

	# get current date
	my $current = time;

	# convert to human date
	# and build date in reports format
	my $limit = reports_date( localtime( $current - $age ) );
	Afick::Msg->debug("limit : $limit\n");

	my @reports    = get_reports_list($archive_dir);
	my $nb_deleted = 0;
	foreach my $report (@reports) {
		my $report_date = $report;
		## no critic (ProhibitEscapedMetacharacters)
		$report_date =~ s/^afick\.//;

		if ( $report_date < $limit ) {

			# so we have to remove file
			my $fic = $archive_dir . '/afick.' . $report_date;

			if ($dry_run) {
				Afick::Msg->info("(dummy) remove old reports $fic");
			}
			else {
				unlink $fic;
				Afick::Msg->info("remove old reports $fic");
				$nb_deleted++;
			}
		}
		else {

			# reports are sorted, so all others have a date newer than limit
			last;
		}
	}
	Afick::Msg->info("$nb_deleted reports removed");
	return;
}
#############################################################
# rewrite new history file
sub rewrite_history($@) {
	my $history     = shift @_;
	my @new_history = @_;

	if ( open my $fh_new_hist, '>', $history ) {
		foreach my $line (@new_history) {
			print {$fh_new_hist} $line . "\n";
		}
		close $fh_new_hist
		  or Afick::Msg->warning("can not close history $history : $ERRNO");
	}
	else {
		Afick::Msg->warning("can not rewrite $history : $ERRNO");
	}
	return;
}
#############################################################
# clean history : remove all entry, which does not have a reports
# in archive directory
sub clean_history($$$) {
	my $history     = shift @_;
	my $archive_dir = shift @_;
	my $dry_run     = shift @_;

	if ( !$history ) {
		Afick::Msg->warning('history directive is not set !');
	}
	elsif ( !-f $history ) {
		Afick::Msg->warning("history $history is not a file");
	}
	else {
		if ( open my $fh_hist, '<', $history ) {
			my @new_history;    # new history file
			my $changes = 0;
			while ( my $ligne = <$fh_hist> ) {
				chomp $ligne;
				if ( $ligne =~ m/^(\d+)\/(\d+)\/(\d+) (\d+):(\d+):(\d+) / ) {
					my $report =
					  $archive_dir . '/afick.' . $1 . $2 . $3 . $4 . $5 . $6;
					if ( -r $report ) {

						# looks good
						push @new_history, $ligne;
					}
					else {

						# reports does not exist any more
						Afick::Msg->info("remove history line : $ligne");
						$changes++;
					}
				}
				else {

					# bad format
					Afick::Msg->warning("bad history line : $ligne");
					$changes++;
				}
			}
			close $fh_hist
			  or Afick::Msg->warning(
				"can not close history file $history : $ERRNO");

			if ($changes) {
				if ($dry_run) {
					Afick::Msg->info(
						"(dummy )$changes lines removed from history");
				}
				else {
					rewrite_history( $history, @new_history );
					Afick::Msg->info("$changes lines removed from history");
				}
			}
			else {
				Afick::Msg->info('no lines removed from history');
			}
		}
		else {
			Afick::Msg->warning("can not open history file $history : $ERRNO");
		}
	}
	return;
}
#############################################################
sub check_date($$$$$) {
	my $expected_date = shift @_;
	my $report_date   = shift @_;
	my $r_txt         = shift @_;
	my $r_init        = shift @_;
	my $r_first       = shift @_;

	my $etat = 0;

	if ($expected_date) {
		if ( $report_date == $expected_date ) {
			${$r_txt} .= ' ok ';
		}
		elsif ( $report_date > $expected_date ) {
			${$r_txt} .=
			  " strange report : expected $expected_date, got $report_date";
			$etat++;
		}
		else {
			${$r_txt} .= " missing report afick.$expected_date";
			$etat++;
		}
	}
	elsif ( ${$r_first} ) {
		${$r_txt} .= ' ok (last run)';
		${$r_first} = 0;
	}
	elsif ( ${$r_init} ) {
		${$r_txt} .= ' ok? (next run is init)';
		${$r_init} = 0;
	}
	else {

		# last run or init
		${$r_txt} .= ' problem (no chaining run)';
	}

	#print "check_date : $txt\n";
	return $etat;
}
#############################################################
# the idea is to check for "holes" in afick's reports
# each report contains date from previous run so we
# can build a chain, from the last one
sub check($) {
	my $archive_dir = shift @_;    # archive directory

	my $expected_date = $EMPTY;    # expected date of report
	my @reports = reverse get_reports_list($archive_dir);

	my $nb_pb = 0;
	my $first = 1;                 # flag for first report
	my $init  = 0;                 # flag for init
	foreach my $report (@reports) {
		my $etat = 0;

		# get run's date of current report from name
		my $report_date = $report;
		## no critic (ProhibitEscapedMetacharacters)
		$report_date =~ s/^afick\.//;

		my $txt = human_date($report_date) . ' : ';

		my ( $type, $last_run_date ) = get_info("$archive_dir/$report");
		## no critic (ProhibitCascadingIfElse)
		if ( !defined $type ) {

			# not a regular report
			Afick::Msg->warning(
				"$report is not a regular report : you may remove it");
			next;
		}
		elsif ( $type eq 'init' ) {

			$etat = check_date( $expected_date, $report_date, \$txt, \$init,
				\$first );
			$txt .= ' (but init may masq some changes)';
			$expected_date = $EMPTY;
			$init          = 1;
		}
		elsif ( $type eq 'compare' ) {

			# compare run do not modify database
			# so does not appear in the chain
			Afick::Msg->info("$txt ok (compare run)");
			next;
		}
		elsif ( $type eq 'update' ) {

			$etat = check_date( $expected_date, $report_date, \$txt, \$init,
				\$first );

			# get previous run date
			if ($last_run_date) {
				$expected_date = $last_run_date;

				#$txt .= ", preceding run is $expected_date";
			}
			else {
				$txt .= ', no date found';
				$etat++;
			}
		}
		else {
			Afick::Msg->warning("$report : unknown type of action : $type");
			next;
		}
		## use critic

		if ($etat) {
			Afick::Msg->warning($txt);
			$nb_pb++;
		}
		else {
			Afick::Msg->info($txt);
		}

	}    # end foreach
	if ($nb_pb) {
		Afick::Msg->info("$nb_pb problems detected");
	}
	else {
		Afick::Msg->info('congratulations : no problems detected');
	}

	return;
}
#############################################################
# search for a regex into reports in archive directory
sub search($$) {
	my $archive_dir = shift @_;
	my $regex       = shift @_;

	my @reports  = get_reports_list($archive_dir);
	my $nb_match = 0;
	my $nb_files = 0;
	foreach my $report (@reports) {
		if ( open my $fh_report, '<', "$archive_dir/$report" ) {
			my $found = 0;
			Afick::Msg->debug("scan $report");
			while (<$fh_report>) {
				if (m/$regex/) {
					chomp;
					Afick::Msg->info("$report : $_");
					$nb_match++;
					if ( !$found ) {
						$found = 1;
						$nb_files++;
					}
				}
			}
			close $fh_report
			  or
			  Afick::Msg->warning("can not close report file $report : $ERRNO");
		}
		else {
			Afick::Msg->warning("can not open report file $report : $ERRNO");
		}
	}
	if ($nb_match) {
		Afick::Msg->info("$nb_match lines founds in $nb_files files");
	}
	else {
		Afick::Msg->info("no line found matching $regex");
	}

	return;
}
#############################################################
#                          main
#############################################################
my $config = Afick::Cfg->new();

$OUTPUT_AUTOFLUSH = 1;

# variables for parameter analysis
my %opt = ();

Getopt::Long::Configure('no_ignore_case');
if (
	!GetOptions(
		\%opt,       'config_file|c=s', 'check|C', 'clean_history|H',
		'keep|k=s',  'search|s=s',      'help|h',  'man',
		'version|V', 'verbose|v',       'dry-run|n',
	)
  )
{
	pod2usage('incorrect option');
}

# this options can be treated as soon as possible
if ( exists $opt{'help'} ) {

	# -h : help
	pod2usage(
		-sections => 'NAME|SYNOPSIS|DESCRIPTION|OPTIONS|ACTIONS',
		-verbose  => 99,
	);
}
elsif ( exists $opt{'man'} ) {
	pod2usage( -verbose => 2 );
}
elsif ( exists $opt{'version'} ) {

	# -V : version
	version($Version);
	exit;
}

# do we have a configuration file ?
if ( exists $opt{'config_file'} ) {
	$config->set_configfile( $opt{'config_file'} );
}
if ( !$config->get_configfile() ) {
	pod2usage("abort : missing configfile name (-c flag)\n");
}

if ( exists $opt{'verbose'} ) {
	$config->set_directive( 'verbose', $opt{'verbose'} );
}

# get old config from, to be able to check new aliases/rules
$config->read_configuration(0);

# get archive directory
my $archive_dir = $config->get_directive('archive');
if ( !$archive_dir ) {
	Afick::Msg->my_die('archive directory is not set !');
}
my $history = $config->get_directive('history');
my $dry_run = $opt{'dry-run'};

# treat others options
## no critic (ProhibitCascadingIfElse)
if ( exists $opt{'check'} ) {
	check($archive_dir);
}
elsif ( exists $opt{'keep'} ) {
	clean_archive( $opt{'keep'}, $archive_dir, $dry_run );
	if ( exists $opt{'clean_history'} ) {
		clean_history( $history, $archive_dir, $dry_run );
	}
}
elsif ( exists $opt{'clean_history'} ) {
	clean_history( $history, $archive_dir, $dry_run );
}
elsif ( exists $opt{'search'} ) {
	search( $archive_dir, $opt{'search'} );
}
else {
	pod2usage('missing action');
}
## use critic

__END__


=head1 NAME

afick_archive - a tool to manage history file and archive directory

=head1 DESCRIPTION

C<afick_archive> is designed to manage afick's archives reports.
It allow to suppress old reports, check reports consistency, and search 
for informations in reports.

=head1 SYNOPSIS

afick_archive.pl [L<options|/OPTIONS>] [L<actions|/ACTIONS>]

=head1 REQUIRED ARGUMENTS

one of the 3 actions is mandatory (check, keep, search) (see below)

=head1 OPTIONS

options are used to control afick_archive

=over 4

=item B<--config_file|-c configfile>

read the configuration in config file named "configfile".

=item B<--help|-h>

Output summary help information and exit.

=item B<--man>

Output full help infomation and exit

=item B<--version|-V>

Output version information and exit.

=item B<--verbose|-v>

add debugging messages

=item B<--dry-run|-n>

on cleaning actions (keep, clean_history), just simulate, do 
not remove anything

=back

=head1 ACTIONS

=over 4

=item B<--check|-C>

check consistency in archives : check if a report is missing

=item B<--search|-s regex>

regex is a regular expression to search in all reports, for exemple : "changed file :.*\.pl$"
(search all changed perl files)

=item B<--keep|-k age>

with age in the form xP, x un number, P can be d for days, w for weeks, m for months (ex : 2w ask for 2 weeks)

the software will remove all reports older than the specified period from archive directory.

=item B<--clean_history|-H>

clean history file : remove line matching removed reports

=back

=head1 USAGE

the archive directory may grow fast, if your config file is not adapted.
afick_archive is to be run to avoid file system full.

=head1 EXAMPLES

Check archive consistency

C<afick_archive.pl --check>

Remove reports older than 2 months

C<afick_archive.pl --keep 2m>

Search all changed perl files

C<afick_archive.pl --search "changed file :.*\.pl$">

=head1 DEPENDENCIES

this program only use perl and its standard modules.

=head1 SEE ALSO

=for html
<a href="afick.conf.5.html">afick.conf(5)</a> for the configuration file syntax
<br>
<a href="afick-tk.1.html">afick-tk(1)</a> for the graphical interface
<br>
<a href="afick.1.html">afick(1)</a> for the command-line interface
<br>
<a href="afickonfig.1.html">afickonfig(1)</a> for a tool to change afick's configuration file
<br>
<a href="afick_archive.1.html">afick_archive(1)</a> for a tool to manage archive's reports
<br>
<a href="afick_learn.1.html">afick_learn(1)</a> for a learning tool

=for man
\fIafick.conf\fR\|(5) for the configuration file syntaxe
.PP
\fIafick\-tk\fR\|(1) for the graphical interface
.PP
\fIafick\fR\|(1) for the command-line interface
.PP
\fIafickonfig\fR\|(1) for a tool to change afick's configuration file
.PP
\fIafick_archive\fR\|(1) for a tool to manage archive's reports
.PP
\fIafick_learn\fR\|(1) for a learning tool

=head1 DIAGNOSTICS

you can use the verbose option to provide diagnostics

=head1 EXIT STATUS

0 (not meaningful)

=head1 CONFIGURATION

this program uses the afick's configuration file

=head1 INCOMPATIBILITIES

none known

=head1 BUGS AND LIMITATIONS

no idea : you have to send me what you find

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2002 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net
