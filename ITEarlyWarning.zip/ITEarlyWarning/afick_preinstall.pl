#!/usr/bin/env perl
###############################################################################
#    Copyright (C) 2002-2204 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this script is to be called at begin of install
# it is in perl to allow it to work on windows

use strict;
use warnings;

use Getopt::Long;      # option analysis
use Pod::Usage;
use File::Basename;    # dirname
use File::Copy;
use English '-no_match_vars';

my $Version = '0.4';

#############################################################
# just display program version
sub version($) {
	my $version = shift @_;
	print "\n";
	print
"afick_preinstall : another file integrity checker configurator\nversion $version\n";
	return;
}
#############################################################
# afick library
# we do not call afick library here to be able
# to use before any install (debian pre-inst)
#my $dirname = dirname($0);
#require $dirname . '/afick-common.pl';

$OUTPUT_AUTOFLUSH = 1;

# arg line
my %opt;
Getopt::Long::Configure('no_ignore_case');
if (
	!GetOptions(
		\%opt, 'config_file|c=s', 'help|h', 'man', 'verbose|v', 'version|V',
	)
  )
{
	pod2usage('incorrect option');
}
if ( exists $opt{'help'} ) {

	# -h : help
	pod2usage(1);
}
elsif ( exists $opt{'man'} ) {
	pod2usage( -verbose => 2 );
}
elsif ( exists $opt{'version'} ) {

	# -V : version
	version($Version);
	exit;
}

my $configfile = $opt{'config_file'};
if ( !$configfile ) {

	# we should provide a default config file
	# to work on debian installer
	$configfile = '/etc/afick.conf';
}

if ( !-r $configfile ) {
	exit;
}

# first save old config file
copy( $configfile, $configfile . '.sav' );
print "save configuration file to $configfile.sav\n";

# open config file and save all line past the mark to "local" config file
# (prepare work for afick_postinstall)
my $local_config = $configfile . '.local';

# be carefull : this is redefined in afick_postinstall !
my $mark = 'put your local config below';

my $fh_local;
my $fh_config;

# no critic (RequireBriefOpen)
if ( !open $fh_config, '<', $configfile ) {
	die "can not open $configfile : $ERRNO\n";
}
if ( !open $fh_local, '>', $local_config ) {
	die "can not open $local_config : $ERRNO\n";
}

my $local = 0;
while (<$fh_config>) {
	if ($local) {
		print {$fh_local} $_;

		#debug("copy line $_");
	}
	elsif (m/$mark/) {
		$local = 1;
	}
}
close $fh_config or warn "can not close $configfile : $ERRNO\n";
if ( close $fh_local ) {
	print "save local configuration file to $local_config\n";
}
else {
	warn "can not close $local_config : $ERRNO\n";
}

__END__

=head1 NAME

afick_preinstall - pre installation script

=head1 DESCRIPTION

C<afick_preinstall>  works with afick_postinstall.pl.
it is used on upgrade, to change afick's configuration defaults
and keep user's configuration (using a mark in configuration file)
It builds a '.local' file containing this config.

=head1 SYNOPSIS

afick_preinstall.pl  [L<options|/options>]

=head1 REQUIRED ARGUMENTS

afick's configuration file

=head1 OPTIONS

=over 4

=item --config_file|-c

full path to afick's configuration file

=item --help|-h

Output help information and exit.

=item --man

Output full help information and exit.

=item --version|-V

Output version information and exit.

=item --verbose|-v

add debugging messages

=back

=head1 USAGE

C<afick_preinstall.pl -c afick.conf>

=head1 NOTES

this program only use perl and its standard modules.

=head1 SEE ALSO

=for html
<a href="afick.conf.5.html">afick.conf(5)</a> for the configuration file syntax
<br>
<a href="afick-tk.1.html">afick-tk(1)</a> for the graphical interface
<br>
<a href="afick.1.html">afick(1)</a> for the command-line interface
<br>
<a href="afickonfig.1.html">afickonfig(1)</a> for a tool to change afick's configuration file
<br>
<a href="afick_archive.1.html">afick_archive(1)</a> for a tool to manage archive's reports
<br>
<a href="afick_learn.1.html">afick_learn(1)</a> for a learning tool

=for man
\fIafick.conf\fR\|(5) for the configuration file syntaxe
.PP
\fIafick\-tk\fR\|(1) for the graphical interface
.PP
\fIafick\fR\|(1) for the command-line interface
.PP
\fIafickonfig\fR\|(1) for a tool to change afick's configuration file
.PP
\fIafick_archive\fR\|(1) for a tool to manage archive's reports
.PP
\fIafick_learn\fR\|(1) for a learning tool

=head1 DIAGNOSTICS

=head1 EXIT STATUS

0

=head1 CONFIGURATION

the afick's configuration file is required and modified

=head1 DEPENDENCIES

perl, afick common library

=head1 INCOMPATIBILITIES

none

=head1 BUGS AND LIMITATIONS

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2002 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net
