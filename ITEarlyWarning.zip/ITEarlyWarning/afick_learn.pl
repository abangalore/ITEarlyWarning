#!/usr/bin/env perl
###############################################################################
#    Copyright (C) 2002-2204 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id: afick_format.pl 3102 2013-04-22 14:55:16Z gerbier $
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# afick_learn is designed to remove false positive
# by learning from afick's logs
#
###############################################################################

use strict;
use warnings;
use Pod::Usage;
use English '-no_match_vars';
use Getopt::Long;    # option analysis
use File::Copy;
use POSIX qw(strftime);

# debuggging
# use diagnostics;
# use Data::Dumper;
# use Carp qw(cluck);	# debugging

use File::Basename;    # for path
my $Dirname = dirname($PROGRAM_NAME);
require $Dirname . '/afick-common.pl';

# constants
my $EMPTY = Afick::Constant->EMPTY;

###############################################################################
#                     global variables
###############################################################################

my $Version = '0.3';

#############################################################
sub is_toapply($$) {
	my $rh_opt = shift @_;
	my $txt    = shift @_;

	if ( $rh_opt->{'interactive'} ) {
		print "want to apply $txt (y/n ?)";
		my $rep = <>;
		chomp $rep;
		return ( $rep eq 'y' );
	}
	else {
		return 1;
	}
}
#############################################################
sub apply_changes($) {
	my $rh_opt = shift @_;

	my $cmd         = $Dirname . '/afickonfig.pl';
	my $config_file = $rh_opt->{'config_file'};
	my @options     = ( '-c', $config_file );

	my $NEGSEL = Afick::Constant->NEGSEL;

	my $changes = learn_get_changes();
	foreach my $change_record ( @{$changes} ) {
		my ( $filename, $oldrule, $newrule, $remove ) =
		  learn_unpack($change_record);

		my $txt = "change $filename from $oldrule to $newrule (remove $remove)";
		if ( $rh_opt->{'dry-run'} ) {
			Afick::Msg->info("(dry-run) would $txt");
		}
		else {
			if ( $newrule eq $NEGSEL ) {

				# empty rule : exclude file
				push @options, $NEGSEL . " \"$filename\"";
			}
			else {
				# change internal format to config format
				push @options, "\"$filename\" $newrule";
			}

			#Afick::Msg->info("$cmd @options");
			if ( is_toapply( $rh_opt, $txt ) ) {
				system $cmd, @options;
			}
		}
	}    # foreach
	return;
}
#############################################################
#                          main
#############################################################

$OUTPUT_AUTOFLUSH = 1;

# variables for parameter analysis
my %opt;
Getopt::Long::Configure('no_ignore_case');
if (
	!GetOptions(
		\%opt,

		'config_file|c=s',
		'dry-run|n',
		'help|h',
		'interactive|i!',
		'log_file|l=s',
		'man',
		'save|s!',
		'version|V',
		'verbose|v!',
	)
  )
{
	pod2usage('incorrect option');
}

if ( exists $opt{'help'} ) {

	# -h : help
	pod2usage(1);
}
elsif ( exists $opt{'man'} ) {
	pod2usage( -verbose => 2 );
}
elsif ( exists $opt{'version'} ) {

	# -V : version
	learn_version($Version);
	exit;
}

if ( exists $opt{'verbose'} ) {
	Afick::Msg->set_verbose( $opt{'verbose'} );
}

if ( !exists $opt{'log_file'} ) {
	pod2usage('missing log file');
}

if ( !exists $opt{'config_file'} ) {
	pod2usage('missing config file');
}

if ( exists $opt{'save'} ) {
	my $config = $opt{'config_file'};
	my $suffix = strftime( '%Y%m%d_%H%M%S', localtime );

	copy( $config, $config . q{.} . $suffix );
}

my %changes = learn_parse_log( \%opt );
learn_compute_changes( \%opt, \%changes );

apply_changes( \%opt );

__END__

=head1 NAME

afick_learn - a tool to learn from log and adapt Afick's configuration

=head1 DESCRIPTION

C<afick_learn> the main idea is to have a customized configuration
to avoid any dummy warning : the default configuration is to be adapted,
but do it may be painful if the afick output is big.
So, this tool will learn from detected changes and modify configuration to 
suppress some fields.
It works only from from 'changed' lines in afick logs : the "new" and "deleted"
lines are ignored.

Attributes changes are removed from afick config : if you have a rule such
"foo md5+p+u+g"
and afick log show an md5 change, afick_learn will change the rule into
"foo p+u+g"

if the log show show the change of all asked attributes, the file is excluded

=head1 SYNOPSIS

afick_learn.pl  [L<options|/OPTIONS>]

=head1 REQUIRED ARGUMENTS

the output format

=head1 OPTIONS

options are used to control afick_learn

=over 4

=item B<--help|-h>

Output help information and exit.

=item B<--man>

Output full help information and exit.

=item B<--version|-V>

Output version information and exit.

=item B<--verbose|-v>

add debugging messages

=item B<--log_file|-l logfile>

full name to the afick's log file to learn from

=item B<--config_file|-c configfile>

read and apply changes in config file named "configfile".

=item B<--interactive|-i>

ask user to confirm before any change in configuration file

=item B<--dry-run|-n>

dry-run mode : show what would be changed but do not apply changes

=item B<--save|-s>

save configuration file before any changes. The saved file
as the same name with a date suffix .yyyymmdd_hhmmss

=back

=head1 USAGE

C<afick_learn.pl -l /var/log/afick/afick.log -c /etc/afick.conf>

=head1 NOTES

this program only use perl and its standard modules.

=head1 SEE ALSO

=for html
<a href="afick.conf.5.html">afick.conf(5)</a> for the configuration file syntax
<br>
<a href="afick-tk.1.html">afick-tk(1)</a> for the graphical interface
<br>
<a href="afick.1.html">afick(1)</a> for the command-line interface
<br>
<a href="afickonfig.1.html">afickonfig(1)</a> for a tool to change afick's configuration file
<br>
<a href="afick_archive.1.html">afick_archive(1)</a> for a tool to manage archive's reports
<br>
<a href="afick_learn.1.html">afick_learn(1)</a> for a learning tool

=for man
\fIafick.conf\fR\|(5) for the configuration file syntaxe
.PP
\fIafick\-tk\fR\|(1) for the graphical interface
.PP
\fIafick\fR\|(1) for the command-line interface
.PP
\fIafickonfig\fR\|(1) for a tool to change afick's configuration file
.PP
\fIafick_archive\fR\|(1) for a tool to manage archive's reports
.PP
\fIafick_learn\fR\|(1) for a learning tool

=head1 DIAGNOSTICS

the input format is analysed and we display some warnings if it does not match
what we are waiting for

=head1 EXIT STATUS

0 if all is ok

=head1 CONFIGURATION

configuration file will be 

=head1 DEPENDENCIES

perl, afick common library

=head1 INCOMPATIBILITIES

none

=head1 BUGS AND LIMITATIONS

input format can be txt or html, not xml
output format can be txt, html, or xml

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2002 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net
