#!/usr/bin/env perl
###############################################################################
##    Copyright (C) 2002 by Eric Gerbier
##    Bug reports to: gerbier@users.sourceforge.net
##    $Id$
##
##    This program is free software; you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation; either version 2 of the License, or
##    (at your option) any later version.
##
##    This program is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
################################################################################
# test for service planning (Windows operating system)
# and add/remove a task to windows service planning
# ask for days, hour, minutes
################################################################################
use strict;
use warnings;

#use diagnostics;
use English qw(-no_match_vars);
use Getopt::Long;
use Pod::Usage;

use Tk;
use File::Basename;    # dirname : to avoid hard-coded path
use Cwd 'abs_path';    # for absolute path

# a windows specific module
use Win32::OLE::NLS qw(:LOCALE :DEFAULT );    # to get days of week

my $Version = '1.4';

# initialize optionmenu with defaults
my $V_hour = 12;    # hour to launch service planning
my $V_min  = 0;     # minutes of hour to launch service planning

# widgets
my $W_set;          # widget to set planning (change state)
my $W_days;         # widget list of days of week
my $W_status;       # widget to display messages
my $W_quit;         # button to quit
my $W_delete;       # button to delete
my $Main;           # main widget

my $Config_file;    # configuration file name

my $at_cmd = 'at';  # windows command to configure service planning
my @find_task;      # at command output for afick

################################################################################
# callback to remove afick tasks
sub cb_delete() {

	# we will remove afick task from service planning
	foreach my $line (@find_task) {

		# get task id
		## no critic (ProhibitEmptyQuotes)
		my ( $id, undef ) = split ' ', $line, 2;

		# remove task
		#my $cmd = "at $id /DELETE";
		system $at_cmd, $id, '/DELETE';

		# write informations
		$W_status->configure( -text => "successful remove : $line" );
	}
	$W_delete->configure( -state => 'disabled' );
	return;
}
################################################################################
# callback function on "set planning" button
# set service planning with our choices (days, hour, min)
sub cb_planning() {

	# get list of days
	my @tab_sel = $W_days->curselection();
	my @t_days;
	foreach my $sel (@tab_sel) {
		push @t_days, $W_days->get($sel);
	}

	# get path from current script
	my $dirname = abs_path( dirname($PROGRAM_NAME) );

# add it :
# cf http://www.microsoft.com/resources/documentation/windows/xp/all/proddocs/en-us/at.mspx?mfr=true
	my $cmd =
	    $V_hour . q{:}
	  . $V_min
	  . ' /interactive /every:'
	  . join( q{,}, @t_days )
	  . " \"$dirname/afick_scan.cmd\" $Config_file";

	#print "cmd=$cmd\n";
	system $at_cmd, $cmd;

	# at answer is localized, so difficult to parse
	# I prefer to ask planning
	my $find_nb = scalar test_planning();
	if ( $find_nb == 1 ) {

		# ok : exit
		$W_status->configure( -text => 'afick is added to service planning' );
		$Main->update();
		sleep 2;
		$Main->destroy();
	}
	else {

		# display an error message
		$W_set->configure( -state => 'disabled' );
		$W_status->configure( -text =>
'problem to add afick on service planning : you have to set by hand'
		);
	}
	return;
}
################################################################################
# build the interface to set day, hour, min
sub display_time() {

	my $frame = $Main->Frame()->pack();
	$W_set =
	  $Main->Button( -text => 'set planning', -command => \&cb_planning )
	  ->pack( -side => 'left' );

	# hours
	$frame->Label( -text => 'hour' )->pack( -side => 'left' );
	my @hour = ( 0 .. 23 );
	$frame->Optionmenu(
		-options      => [@hour],
		-textvariable => \$V_hour,
	)->pack( -side => 'left' );

	# minutes
	$frame->Label( -text => 'minutes' )->pack( -side => 'left' );
	my @min = ( 0 .. 59 );
	$frame->Optionmenu(
		-options      => [@min],
		-textvariable => \$V_min,
	)->pack( -side => 'left' );

	# day of week too
	my @week;

	# get localisation from windows
	for ( 1 .. 7 ) {
		## no critic (ProhibitStringyEval)
		push @week,
		  GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, eval "LOCALE_SDAYNAME$_ " );
		## use critic
	}
	$frame->Label( -text => 'days' )->pack( -side => 'left' );
	$W_days =
	  $frame->Listbox( -selectmode => 'multiple' )->pack( -side => 'left' );
	$W_days->insert( 'end', @week );

	# lock submit until a day is selected
	# choice a day will allow submit
	$W_set->configure( -state => 'disabled' );
	$W_days->bind( '<Button-1>',
		sub { $W_set->configure( -state => 'normal' ) } );
	return;
}
################################################################################
# ask service planning for afick tasks
# return match lines
sub test_planning() {

	# ask all tasks from service planning
	## no critic (ProhibitBacktickOperators)
	my @tab = `$at_cmd`;
	## use critic

	# search for afick's tasks
	my @lignes;
	foreach my $elem (@tab) {

		#print "at return : $elem\n";
		chomp $elem;
		if ( $elem =~ m/afick/ ) {
			push @lignes, $elem;
		}
	}
	return @lignes;
}
################################################################################
#			main
################################################################################

my %opt;
Getopt::Long::Configure('no_ignore_case');
if ( !GetOptions( \%opt, 'version|V', 'help|h', 'man', 'verbose', ) ) {
	pod2usage('incorrect option');
}

if ( exists $opt{'version'} ) {
	print "$PROGRAM_NAME version $Version\n";
	exit;
}
elsif ( exists $opt{'help'} ) {
	pod2usage(1);
}
elsif ( exists $opt{'man'} ) {
	pod2usage( -verbose => 2 );
}

# first argument (optionnal) : configuration file
$Config_file = $ARGV[0] || 'windows.conf';

# second argument (optionnal) : if set (anything), we remove the planning
# (used on uninstall)
my $delete = $ARGV[1] || 0;

# get planning tasks for afick
@find_task = test_planning();
my $find_nb = scalar @find_task;

# build main window
$Main = MainWindow->new( -title => 'afick-planning' );

# frame for buttons
my $w_frame = $Main->Frame();
$w_frame->pack();
$W_delete = $w_frame->Button( -text => 'delete', -command => \&cb_delete );
$W_delete->pack( -side => 'left' );
$W_quit =
  $w_frame->Button( -text => 'quit', -command => [ $Main => 'destroy' ] );
$W_quit->pack( -side => 'left' );

# label for status display
$W_status = $Main->Label();
$W_status->pack();

if ($delete) {

	# call from command line
	cb_delete();
}
elsif ( $find_nb == 1 ) {

	# only one task found : looks good
	# just display found line
	$W_status->configure( -text => "find : @find_task" );
}
elsif ( $find_nb > 1 ) {

	# several task found : looks strange
	# display warning
	$W_status->configure( -text =>
"WARNING : found several afick tasks ( $find_nb) ; you should delete and then re-add the task : @find_task"
	);
}
else {

	# no afick's task found : we can set it
	$W_status->configure( -text  => 'add afick task in service planning at :' );
	$W_delete->configure( -state => 'disabled' );

	# display time chooser
	display_time();
}
MainLoop;

__END__

=head1 NAME

afick_set_planning - a tool to configure afick in the windows service planning

=head1 DESCRIPTION

C<afick_set_planning> is a tool to configure afick in the windows service planning.
It is using a Tk interface to customize when you want afick to run (day of the week,
hour)

=head1 SYNOPSIS

afick_set_planning.pl  [L<options|options>] 

=head1 REQUIRED ARGUMENTS

none

=head1 OPTIONS

options are used to control afickconfig

=over 4

=item --help|-h

Output help information and exit.

=item --man

Output full help information and exit.

=item --version|-V

Output version information and exit.

=item --verbose|-v

add debugging messages

=back

=head1 USAGE

C<afick_set_planning.pl>

=head1 EXIT STATUS

none

=head1 SEE ALSO

=for html
<a href="afick.conf.5.html">afick.conf(5)</a> for the configuration file syntax
<br>
<a href="afick-tk.1.html">afick-tk(1)</a> for the graphical interface
<br>
<a href="afick.1.html">afick(1)</a> for the command-line interface
<br>
<a href="afickonfig.1.html">afickonfig(1)</a> for a tool to change afick's configuration file
<br>
<a href="afick_archive.1.html">afick_archive(1)</a> for a tool to manage archive's reports
<br>
<a href="afick_learn.1.html">afick_learn(1)</a> for a learning tool

=for man
\fIafick.conf\fR\|(5) for the configuration file syntaxe
.PP
\fIafick\-tk\fR\|(1) for the graphical interface
.PP
\fIafick\fR\|(1) for the command-line interface
.PP
\fIafickonfig\fR\|(1) for a tool to change afick's configuration file
.PP
\fIafick_archive\fR\|(1) for a tool to manage archive's reports
.PP
\fIafick_learn\fR\|(1) for a learning tool

=head1 DIAGNOSTICS

the input format is analysed and we display some warnings if it does not match
what we are waiting for

=head1 CONFIGURATION

it does not use afick's configuration file

=head1 DEPENDENCIES

perl, afick common library
this program requires the Tk perl module

=head1 INCOMPATIBILITIES

none

=head1 BUGS AND LIMITATIONS

input format can be txt or html, not xml
output format can be txt, html, or xml

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2002 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net
