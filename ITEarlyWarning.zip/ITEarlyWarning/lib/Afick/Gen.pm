#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# common sub and var for afick's tool
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Gen;

use strict;
use warnings;

use English qw(-no_match_vars);
use POSIX qw(strftime);             # in reports_date history_date
use File::Basename;                 # in to_abspath
use Cwd 'abs_path';                 # in to_abspath
use Fcntl qw( :flock :DEFAULT );    # to get F_* and O_* LOCK_* constants
use Digest;
use MIME::Base64;                   # in print_digest

use base qw(Exporter);
## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );

$VERSION = '1.5';
@EXPORT =
  qw( &array2hash &to_abspath &remove_trailing_spaces &remove_all_spaces &rech_parent
  &check_update &reports_date &history_date &touch &reg_name &joinkey
  &compare_hashkey &diff_tab &diff_hash &print_oct &md5sum &sha1sum &sha256sum &sha512sum
  &print_digest &init_file_macro &get_from_command_line
  &chroot_check &add_chroot &remove_chroot &remove_trailing_slash &compare_array &file_type_h
  &compare_hash &get_time
);

# optional modules
##################
# LWP::UserAgent

# other afick modules
#####################
use Afick::Msg;
use Afick::Tst;    # is_microsoft

#######################################################
# real internal code to return full absolute path name
sub _to_abspath($) {
	my $elem = shift @_;

	my ( $name, $path, undef ) = fileparse($elem);
	my $fpath = abs_path($path);

	# on windows can have .\/history
	## no critic (ProhibitEscapedMetacharacters)
	$fpath =~ s{\.\\}{};

	# to avoid path//name
	my $sep = ( $fpath =~ m{/$} ) ? q{} : q{/};
	my $res = $fpath . $sep . $name;

	Afick::Msg->debug(
		"(_to_abspath) $elem ==> $res name=$name path=$path fpath=$fpath", D4 );
	return $res;
}
#######################################################
# return a file name with full path (not relative)
sub to_abspath($) {
	my $elem = shift @_;

	my $fpath;

	# a test to avoid loosing time
	if ( is_microsoft() ) {
		## no critic (ProhibitEnumeratedClasses)
		if ( $elem !~ m/^[a-z]:[\/\\]/i ) {
			$fpath = _to_abspath($elem);
		}
		else {
			$fpath = $elem;
		}
	}
	elsif ( $elem !~ m/^\// ) {
		$fpath = _to_abspath($elem);
	}
	else {
		$fpath = $elem;
	}
	Afick::Msg->debug( "(to_abspath) $elem => $fpath", D4 );
	return $fpath;
}
#######################################################
# remove_trailing blanks
# syntaxe : remove_trailing_spaces(\$var)
sub remove_trailing_spaces($) {
	my $r_val = shift @_;    # ref to var to clean

	${$r_val} =~ s/^\s+//;
	${$r_val} =~ s/\s+$//;

	return ${$r_val};
}
#######################################################
# remove all spaces in a string
# syntaxe : remove_all_spaces(\$var)
sub remove_all_spaces($) {
	my $r_val = shift @_;

	${$r_val} =~ s/\s+//g;

	return ${$r_val};
}
##########################################################################
# remove the trailing slash in a path
# unless if it is the unix root
sub remove_trailing_slash($) {
	my $r_val = shift @_;

	if ( !is_fsroot( ${$r_val} ) ) {
		${$r_val} =~ s{/$}{};
	}
	return ${$r_val};
}
##########################################################################
# search for a rule matching $file in $rscan
# return 2 values
# - undef if not found, 0 if an exception, else the rule
# - name of file giving the rule
sub rech_parent($$) {
	my $file    = shift @_;
	my $rh_scan = shift @_;

	Afick::Msg->debug_begin();
	my $found   = undef;
	my $dirname = $file;

	# first search for this file
	if ( exists $rh_scan->{$file} ) {
		$found = $rh_scan->{$file};
		if ( $found ne '0' ) {

			# found the name in the list and not an exception
			Afick::Msg->debug(
				"(rech_parent) found $file in config file : $found", D2 );
		}
		else {

			# found the file as an exception : the end
			Afick::Msg->debug( "(rech_parent) $file is an exception", D2 );
		}
	}
	else {

		# then search for directory parent
		$dirname = dirname($file);

		# infinite loop
		# there is 2 ways to go out
		while (1) {
			if ( exists $rh_scan->{$dirname} ) {
				$found = $rh_scan->{$dirname};
				if ( $rh_scan->{$dirname} ne '0' ) {

					# found a good parent directory
					Afick::Msg->debug(
"(rech_parent) found $dirname for $file in config file : $found",
						D2
					);
					last;
				}
				else {

					# found the directory as an exception : the end
					Afick::Msg->debug(
"(rech_parent) found $dirname for $file is an exception",
						D2
					);
					last;
				}
			}
			else {

				# next parent directory
				my $newdirname = dirname($dirname);
				if ( $newdirname eq $dirname ) {
					Afick::Msg->debug( "(rech_parent) stop on $dirname", D2 );
					last;
				}
				else {
					Afick::Msg->debug(
						"(rech_parent) search $newdirname (from $dirname)",
						D3 );
					$dirname = $newdirname;
				}
			}
		}
	}
	Afick::Msg->debug_end();
	return ( $found, $dirname );
}
##########################################################################
# check if a new release is available
# return 1 if true
# return 0 if not
# return undef if some error
sub check_update($$) {
	my $cur_product = shift @_;    # ex : afick
	my $cur_version = shift @_;    # ex : 2.13

	my $url = 'http://afick.sourceforge.net/version';

	# version 1 : LWP::Simple
	# very easy and simple to code, but can not configure timeout
	#eval {require  LWP::Simple};
	#$content =  LWP::Simple::get($url);

	my $ret;    # return code

	# version 2 : LWP::UserAgent : a little bit more complex
	# no critic (RequireCheckingReturnValueOfEval)
	if ( !is_perl_module('LWP::UserAgent') ) {
		Afick::Msg->warning(
			'missing library LWP : impossible get last version');
	}
	else {
		my $ua = LWP::UserAgent->new();

		# no critic (ProhibitMagicNumbers)
		$ua->timeout(5);    # wait
		my $response = $ua->get($url);    # HTTP::Response
		if ( $response->is_success ) {

			# get file content
			my $content = $response->content;

			# parse each line to search for product
			my @lines = split /\n/, $content;
			my $version;
			foreach my $line (@lines) {
				my ( $l_prod, $l_version ) = split / /, $line;
				if ( $l_prod eq $cur_product ) {
					$version = $l_version;
					last;
				}
			}
			if ( !defined $version ) {
				Afick::Msg->warning("can not find version for $cur_product");
			}
			else {

				# can get version file
				# then compare with current version
				# rem : it should be possible to have a real compare
				# if we remove . and - from version (or keep only numerics)
				if ( $version eq $cur_version ) {

					# ok
					Afick::Msg->info(
						"ok : last version of $cur_product ($version) installed"
					);
					$ret = 0;
				}
				else {

					# another version is available
					Afick::Msg->warning(
"another version of $cur_product is available : $version (current is $cur_version)"
					);
					$ret = 1;
				}
			}
		}
		else {

			# can not get url
			Afick::Msg->warning( 'can not get version from internet site : '
				  . $response->status_line() );

		}
	}
	return $ret;
}
##########################################################################
# date format for reports name
sub reports_date(@) {
	my @date = @_;    # as a return of localtime /gmtime

	return strftime( '%Y%m%d%H%M%S', @date );
}
##########################################################################
# date format for history, reports ....
sub history_date(@) {
	my @date = @_;    # as a return of localtime /gmtime

	my $datefmt = '%Y/%m/%d %H:%M:%S';
	return strftime( $datefmt, @date );
}
##########################################################################
sub get_time($;$) {
	my $epoch = shift @_;            # date in epoch format
	my $flag_utc = shift @_ || 0;    # if true return utc time, else local time

	return ($flag_utc) ? gmtime $epoch : localtime $epoch;
}
##########################################################################
# just create an empty file if does not exist
sub touch($) {
	my $name = shift @_;

	if ( !-f $name ) {
		## no critic (RequireCheckedOpen,RequireCheckedClose,RequireCheckedSyscalls)
		open my $fh_touch, '>', $name;
		close $fh_touch;
		## use critic
	}
	return;
}
##########################################################################
#replace \ by / (for windows)
sub reg_name($) {
	my $name = shift @_;

	if ( is_microsoft() ) {
		$name =~ s{\\}{/}g;
		return lc $name;
	}
	else {
		return $name;
	}
}
##########################################################################
# join all keys of an hash
# used in compare_hashkey
sub joinkey($) {
	my $rh_hash = shift @_;

	return join q{}, sort keys %{$rh_hash};
}
##########################################################################
# return true if the 2 hash have the same keys
sub compare_hashkey($$) {
	my $rh_hash1 = shift @_;
	my $rh_hash2 = shift @_;

	return ( joinkey($rh_hash1) eq joinkey($rh_hash2) );
}
##########################################################################
# convert an array to a hash
# used by diff_tab
sub array2hash($$) {
	my $ra_tab    = shift @_;
	my $separator = shift @_;

	my %h;
	foreach my $line ( @{$ra_tab} ) {
		if ( $line =~ m/(.*)$separator(.*)/ ) {
			my $key = $1;
			my $val = $2;
			$h{$key} = $val;
		}
	}
	return %h;
}
##########################################################################
# a tool to compare 2 arrays, containing lines such key=value
# the best way is to convert to hash, then compare keys
sub diff_tab($$$$;$$$) {
	my $ra_tab1   = shift @_;    # old tab
	my $ra_tab2   = shift @_;    # new tab
	my $separator = shift @_;    # separate kay and value, ex =
	my $comment   = shift @_;    # text to display on warnings
	my $rh_new    = shift @_;    # optionnal return hash of new entries
	my $rh_del    = shift @_;    # optionnal return hash of deleted entries
	my $rh_mod    = shift @_;    # optionnal return hash of changed entries

	# convert in hash
	my %t1 = array2hash( $ra_tab1, $separator );
	my %t2 = array2hash( $ra_tab2, $separator );

	return diff_hash( \%t1, \%t2, $comment, $rh_new, $rh_del, $rh_mod );
}
##########################################################################
# compare 2 hash
# return the number of changes
# the code may send the warnings it-self
# but can also return the hash of changes, in this case,
# the print has to be done by the caller
# ps : look at compare_hash for a simpler code
sub diff_hash($$$;$$$) {
	my $rh_h1   = shift @_;    # old hash
	my $rh_h2   = shift @_;    # new hash
	my $comment = shift @_;    # text to display on warnings
	my $rh_new  = shift @_;    # optionnal return hash of new entries
	my $rh_del  = shift @_;    # optionnal return hash of deleted entries
	my $rh_mod  = shift @_;    # optionnal return hash of changed entries

	my $nb_diff = 0;

	# cf perl cookbook 4.8
	foreach my $key ( keys %{$rh_h1} ) {
		if ( exists $rh_h2->{$key} ) {

			# same key : check val
			if ( $rh_h1->{$key} ne $rh_h2->{$key} ) {
				if ($rh_mod) {
					$rh_mod->{$key} = 1;
				}
				else {
					Afick::Msg->warning(
"$comment $key change : $rh_h1->{$key} -> $rh_h2->{$key}"
					);
				}
				$nb_diff++;
			}
		}
		else {

			# old key was suppressed
			if ($rh_del) {
				$rh_del->{$key} = 1;
			}
			else {
				Afick::Msg->warning(
					"$comment $key (" . $rh_h1->{$key} . ') was removed' );
			}
			$nb_diff++;
		}
	}
	foreach my $key ( keys %{$rh_h2} ) {
		if ( !exists $rh_h1->{$key} ) {

			# find a new key
			if ($rh_new) {
				$rh_new->{$key} = 1;
			}
			else {
				Afick::Msg->warning(
					"$comment $key (" . $rh_h2->{$key} . ') was added' );
			}
			$nb_diff++;
		}
	}

	return $nb_diff;
}
##########################################################################
# compare 2 perl hash
# return true if equal, else false
# ps : look at diff_hash to have more details
sub compare_hash($$) {
	my $rh_hash1 = shift @_;
	my $rh_hash2 = shift @_;

	# compare keys
	my $tst1 = compare_hashkey( $rh_hash1, $rh_hash2 );
	if ($tst1) {

		# same keys : compare values
		foreach my $key ( keys %{$rh_hash1} ) {
			return 0 if ( $rh_hash1->{$key} ne $rh_hash2->{$key} );
		}
		return 1;
	}
	else {
		return 0;
	}
}
##########################################################################
# compare 2 perl array
# return true if equal, else false
sub compare_array($$) {
	my $ra = shift @_;
	my $rb = shift @_;

	my $equals;
	if ( @{$ra} != @{$rb} ) {

		# not same size
		$equals = 0;
	}
	else {
		$equals = 1;
		for ( 0 .. @{$ra} ) {
			if (   ( ( !defined $ra->[$_] ) and ( defined $rb->[$_] ) )
				or ( ( defined $ra->[$_] ) and ( !defined $rb->[$_] ) ) )
			{
				$equals = 0;
				last;
			}
			elsif ( ( !defined $ra->[$_] ) and ( !defined $rb->[$_] ) ) {
				$equals = 1;
			}
			elsif ( $ra->[$_] ne $rb->[$_] ) {
				$equals = 0;
				last;
			}
		}
	}
	return $equals;
}
##########################################################################
# transform in octal for human
sub print_oct($) {
	my $number = shift @_;

	return sprintf '%lo', $number;
}
##########################################################################
# checksum read the file, so a classic open will change access time (atime)
# with O_NOATIME : it is not changed
# but this option is not portable : it seems to exist only on recent linux box
# (not on redhat 7.3/perl 5.6), ok on debian sarge, mandriva 2005/2006/2007)
# so we have to check it
{
	my $sysopen_flag;    # cache

	sub get_sysopen_flag(;$) {
		my $reset = shift @_;    # force clean cache (for tests)

		if ( ($reset) or ( !defined $sysopen_flag ) ) {

			# no critic (RequireCheckingReturnValueOfEval)
			eval {
				require Fcntl;    # force reload
				import Fcntl qw( O_NOATIME);

				# try to use O_NOATIME (import is not enough )
				$sysopen_flag = O_RDONLY | Fcntl::O_NOATIME();
			};
			if ($EVAL_ERROR) {
				$sysopen_flag = O_RDONLY;
				Afick::Msg->debug( 'can not import noatime', D2 );
			}
			else {
				Afick::Msg->debug( 'import noatime', D2 );
			}
		}
		return $sysopen_flag;
	}
}
#######################################################
# compute checksum on a file handle
sub fh_checksum($$$$) {
	my $ctx  = shift @_;    # checksum object
	my $name = shift @_;    # file name
	my $degraded =
	  shift @_;    # degraded mode : 0 for full file, else max checksum size
	my $fh_file = shift @_;    # file handle

	binmode $fh_file;
	my $buf_size = 65_536;     # buffer size
	if ($degraded) {

		Afick::Msg->debug(
			"(base_checksum) degraded checksum on $name : $degraded", D2 );

		# we just want to have checksum on first Max_checksum_size bytes
		my $buf;               # buffer
		my $lu;                # effective read count
		my $reste = $degraded; # size to read
		while ( $reste > $buf_size ) {
			$lu = read $fh_file, $buf, $buf_size;
			$ctx->add($buf);
			$reste -= $lu;

			#last if ($lu);
		}
		$lu = read $fh_file, $buf, $reste;
		$ctx->add($buf);
		$reste -= $lu;

		# check : $reste = 0
		Afick::Msg->warning(
"(base_checksum) pb checksum on file $name buf_size $buf_size limit $degraded"
		) if ( $reste != 0 );
	}
	else {

		# checksum on all file
		#$ctx->addfile($fh_file);
		# because I was reported some strange probleme on windows
		# I got and rewrite addfile method to suppress Carp::croak call
		my $n;
		my $buf = Afick::Constant->EMPTY;
		while ( $n = read $fh_file, $buf, $buf_size ) {
			$ctx->add($buf);
		}
		if ( !defined $n ) {
			Afick::Msg->warning(
				"(base_checksum) can not read $name for checksum: $ERRNO");
		}
	}
	close $fh_file or Afick::Msg->warning("can not close $name : $ERRNO");
	my $sum = $ctx->b64digest;
	return $sum;
}
#######################################################
# low-level checksum sub
# work on file name
sub base_checksum($$$$) {
	my $dig_type = shift @_;    # checksum name
	my $name     = shift @_;    # file name
	     # degraded mode : 0 for full file else max checksum size
	my $degraded     = shift @_;
	my $flag_symlink = shift @_;    # true if checksum on name

	my $ctx          = Digest->new($dig_type);
	my $sysopen_flag = get_sysopen_flag();
	my $sum;
	if ($flag_symlink) {

		# for symbolic links, check the change in pointed name
		# not in pointed file content
		my $link = readlink $name;
		$ctx->add($link);
		$sum = $ctx->b64digest;
		Afick::Msg->debug(
			"(base_checksum) checksum follow_symlink from $name to link", D2 );
	}
	elsif ( sysopen my $fh_file, $name, $sysopen_flag ) {
		$sum = fh_checksum( $ctx, $name, $degraded, $fh_file );
	}

	# can not use O_NOATIME, try without
	elsif ( ( $sysopen_flag ne O_RDONLY )
		and ( sysopen my $fh_file2, $name, O_RDONLY ) )
	{

		$sum = fh_checksum( $ctx, $name, $degraded, $fh_file2 );
		Afick::Msg->debug(
			"(base_checksum) forced checksum (no NOATIME) on $name", D2 );
	}
	else {
		if ( is_microsoft() ) {

			# because it is very common on windows to not allow administrator
			# with some acl
			Afick::Msg->debug(
"(base_checksum) can not open $name for checksum (mode $sysopen_flag): $ERRNO",
				D1
			);
		}
		else {

			# but on unix, it show a big problem
			Afick::Msg->warning(
"(base_checksum) can not open $name for checksum (mode $sysopen_flag): $ERRNO"
			);
		}
		$sum = 0;
	}
	return $sum;
}
##########################################################################
# md5sum :
# build a MD5 checksum on the given file
sub md5sum($$$) {
	my $name     = shift @_;  # file name
	my $degraded = shift @_;  # degraded mode 0 for full file else checksum size
	my $flag_symlink = shift @_;    # true if checksum on name

	return base_checksum( 'MD5', $name, $degraded, $flag_symlink );
}
##########################################################################
# sha1sum :
# build a sha1 checksum on the given file
sub sha1sum($$$) {
	my $name         = shift @_;    # file name
	my $degraded     = shift @_;
	my $flag_symlink = shift @_;    # true if checksum on name

	return base_checksum( 'SHA-1', $name, $degraded, $flag_symlink );
}
#######################################################
# sha256sum :
# build a sha256 checksum on the given file
sub sha256sum($$$) {
	my $name         = shift @_;    # file name
	my $degraded     = shift @_;
	my $flag_symlink = shift @_;    # true if checksum on name

	return base_checksum( 'SHA-256', $name, $degraded, $flag_symlink );
}
#######################################################
# sha512sum :
# build a sha512 checksum on the given file
sub sha512sum($$$) {
	my $name         = shift @_;    # file name
	my $degraded     = shift @_;
	my $flag_symlink = shift @_;    # true if checksum on name

	return base_checksum( 'SHA-512', $name, $degraded, $flag_symlink );
}
##########################################################################
# return a checksum in several format :
# internal
# hexa : md5sum/sha1sum compatible
sub print_digest($;$) {
	my $b64 = shift @_;                 # checksum
	my $base64_mode = shift @_ || 0;    # flag

	if ( $b64 eq '0' ) {

		# no checksum
		return 0;
	}
	elsif ($base64_mode) {

		# base64 (internal format)
		return $b64;
	}
	else {

		# for hexa (md5sum compatible)
		# cf MIME::Base64
		# Legal base64 data should be padded with one or two "="
		# characters to make its length a multiple of 4
		my $len = length($b64) % 4;
		my $pad = 4 - $len;
		$b64 .= q{=} x $pad if $pad;
		return unpack 'H*', MIME::Base64::decode($b64);
	}
}
##########################################################################
# import S_ macros and define others if needed (windows)
sub init_file_macro() {
	if ( is_microsoft() ) {

		require POSIX;
		import POSIX ':sys_stat_h';    # to get S_ constants

		# define some macros which are not in POSIX module,
		# and not defined in Fcntl module
		*S_ISSOCK = sub { return 0 }
		  if ( !defined &S_ISSOCK );
		*S_ISLNK = sub { return 0 }
		  if ( !defined &S_ISLNK );
		*S_ISBLK = sub { return 0 }
		  if ( !defined &S_ISBLK );
	}
	else {

		# unix/linux
		# get socket and link macros
		require Fcntl;
		import Fcntl ':mode';    # for file type macros
	}
	return;
}
##########################################################################
# because arg can be given in one or several options :
# --add toto1 --add toto2
# --add toto1,toto2
sub get_from_command_line(@) {
	my @arg = @_;

	my $comma = Afick::Constant->COMMA;
	## no critic (ProhibitParensWithBuiltins);
	return split /$comma/, join( $comma, @arg );
	## use critic;
}
#######################################################
# chroot subs
#######################################################
# check for chroot env (if directory exists)
# return code :
# 1 if ok
# 0 if problem
# -1 if no chroot
sub chroot_check() {

	my $ret;
	my $chroot = is_chroot_mode();
	if ($chroot) {
		if ( -d $chroot ) {

			# ok
			$ENV{'AFICK_CHROOT'} = reg_name($chroot);
			Afick::Msg->debug( "detect chroot to $chroot", D3 );
			$ret = 1;
		}
		else {

			# problem
			Afick::Msg->warning("remove bad chroot env : $ENV{'AFICK_CHROOT'}");
			delete $ENV{'AFICK_CHROOT'};
			$ret = 0;
		}
	}
	else {

		# no chroot defined
		$ret = -1;
	}
	return $ret;
}
#######################################################
# build real path from config and environment chroot
sub add_chroot($) {
	my $name = shift @_;

	# only apply chroot to relative path
	my $chroot = is_chroot_mode();
	if ( ($chroot) and ( is_chroot_line($name) ) ) {

		# remove first character
		$name =~ s{^@}{};

		Afick::Msg->debug( "add chroot $chroot to $name", D3 );
		$name = $chroot . q{/} . $name;
	}
	return $name;
}
#######################################################
# remove chroot from real to keep same as config
sub remove_chroot($) {
	my $name = shift @_;

	my $chroot = is_chroot_mode();
	if ($chroot) {
		$name =~ s{^$chroot/}{};
	}
	return $name;
}
#######################################################
# return human file type from a permission field
# for example field 2 of stat command
sub file_type_h($) {
	my $mode = shift @_;    # permissions

	my $type;

	# order of test is important for the first test !
	## no critic (ProhibitCascadingIfElse)
	if ( !defined $mode ) {
		$type = 'undef';
	}
	elsif ( S_ISSOCK($mode) ) {
		$type = 'socket';
	}
	elsif ( S_ISLNK($mode) ) {
		$type = 'symbolic_link';
	}
	elsif ( S_ISREG($mode) ) {
		$type = 'file';
	}
	elsif ( S_ISBLK($mode) ) {
		$type = 'block_device';
	}
	elsif ( S_ISDIR($mode) ) {
		$type = 'directory';
	}
	elsif ( S_ISCHR($mode) ) {
		$type = 'character_device';
	}
	elsif ( S_ISFIFO($mode) ) {
		$type = 'fifo';
	}
	elsif ( $mode == 0 ) {
		$type = 'no_type';
	}
	else {
		$type = 'unknown_type';
	}
	## use critic
	return $type;
}
#######################################################
init_file_macro();
1;
