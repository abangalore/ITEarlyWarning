#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# a general package for all is_* routines
# may also be merged in Gen.pm
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Tst;

use strict;
use warnings;

use English qw(-no_match_vars);
use base qw(Exporter);
use File::Basename;

## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );

$VERSION = '1.4';
@EXPORT =
  qw( &is_binary &is_posint &is_mail_adress &is_borned_int &is_nicevalue &is_hostname &is_plainfile &check_plainfile &is_directory
  &check_directory &is_anyfile &is_bidon &is_debug_level &is_url &is_name &is_op &is_linux &is_microsoft
  &is_macro_line &is_alias_line &is_directive_line &is_negsel_line &is_sel_line &is_equalsel_line &is_anysel_line &is_acl
  &is_sha &is_sha1 &is_sha256 &is_sha512  &is_fsroot &is_type &is_noval &is_perl_module
  &is_special_dir &is_list &is_chroot_line &is_chroot_mode &is_retention
  &test_dangling
);

# optional modules
##################
# Digest::SHA1
# Win32::FileSecurity

# other afick modules
#####################
use Afick::Constant;    # TRUE/FALSE
use Afick::Msg;         # for set_error

###############################################################################
# test for binaries values
# return 1/0 if good, else undef
sub is_binary($) {
	my $val = shift @_;

	## no critic (ProhibitFixedStringMatches)
	if ( !defined $val ) {
		Afick::Msg->set_error('not defined : not a binary value');
		return;
	}
	elsif ( $val =~ m/^(yes|true|on|1)$/i ) {
		return TRUE;
	}
	elsif ( $val =~ m/^(no|false|off|0)$/i ) {
		return FALSE;
	}
	else {
		Afick::Msg->set_error("$val is not a binary value");
		return;
	}
	## use critic
}
###############################################################################
# check if is a positive integer number
sub is_posint($) {
	my $val = shift @_;

	if ( $val =~ m/^\d+$/ ) {
		return $val;
	}
	else {
		Afick::Msg->set_error("$val is not a positive integer number");
		return;
	}
}
###############################################################################
# check if is an integer number in [min , max ] interval
# we assume 0 <= min <= max
sub is_borned_int($$$) {
	my $val = shift @_;
	my $min = shift @_;
	my $max = shift @_;

	if ( !defined is_posint($val) ) {
		return;
	}
	elsif ( ( $min <= $val ) and ( $val <= $max ) ) {
		return $val;
	}
	else {
		Afick::Msg->set_error(
			"$val is not an integer number in [$min - $max] interval");
		return;
	}
}
###############################################################################
# check if it looks like a nice value (man nice on unix)
# we just allow positives value (lower priority)
sub is_nicevalue($) {
	my $val = shift @_;

	# no critic (ProhibitMagicNumbers)
	return is_borned_int( $val, 0, 19 );
}
###############################################################################
# check if it looks like a email adress
sub is_mail_adress($) {
	my $val = shift @_;

	# a mail adress should contain the "at" character
	if ( $val =~ m/\S+\@\S+/ ) {
		return $val;
	}
	else {
		Afick::Msg->set_error("$val do not seems to be a mail adress");
		return;
	}
}
###############################################################################
# check if given value is a Fully Qualified Domain Name
sub is_hostname($) {
	my $val = shift @_;

	# a fqn name contains a name and a domain, so a dot
	if ( $val =~ m/^\w+[.][\w.]+$/ ) {
		return $val;
	}
	else {
		Afick::Msg->set_error("$val is not a hostname");
		return;
	}
}
###############################################################################
# check if a file exists
sub is_plainfile($) {
	my $val = shift @_;

	if ( -f $val ) {
		return $val;
	}
	else {
		Afick::Msg->set_error("$val plain file does not exist");
		return;
	}
}
###############################################################################
# check if a file exists
# and try to create it if not
sub check_plainfile($) {
	my $val = shift @_;

	if ( is_plainfile($val) ) {
		return $val;
	}
	elsif ( open my $fh_file, '>', $val ) {

		# create file
		## no critic (RequireCheckedClose,RequireCheckedSyscalls)
		close $fh_file;
		return $val;
	}
	else {
		Afick::Msg->set_error("can not create file $val : $ERRNO");
		return;
	}
}
###############################################################################
# check if a directory exists
sub is_directory($) {
	my $val = shift @_;

	if ( -d $val ) {
		return $val;
	}
	else {
		Afick::Msg->set_error("$val directory does not exist");
		return;
	}
}
###############################################################################
# check if a directory exists
# and try to create it if not
sub check_directory($) {
	my $val = shift @_;

	if ( is_directory($val) ) {
		return $val;
	}

	# no critic (ProhibitMagicNumbers)
	# 700 mask is for u=rwx
	elsif ( mkdir $val, oct 700 ) {

		# create directory
		return $val;
	}
	else {
		Afick::Msg->set_error("can not create directory $val : $ERRNO");
		return;
	}
}
###############################################################################
# check for any file or directory
sub is_anyfile($) {
	my $val = shift @_;

	# file or link
	if ( -e $val ) {
		return $val;
	}
	else {
		Afick::Msg->set_error("$val file does not exist");
		return;
	}
}
###############################################################################
# never return false (undef) : to be used if no checking available
sub is_bidon($) {
	my $val = shift @_;
	return $val;
}
###############################################################################
# check if it is debug level
sub is_debug_level($) {
	my $val = shift @_;

	if ( !defined is_posint($val) ) {
		return;
	}
	elsif ( Afick::Msg->is_valid_msg_level($val) ) {
		return $val;
	}
	else {
		Afick::Msg->set_error('bad debug level value');
		return;
	}
}
###############################################################################
# check if a valid url
# we allow any case, but return in upper case
sub is_url($) {
	my $val = uc shift @_;

	if ( Afick::Msg->is_valid_url($val) ) {
		return $val;
	}
	else {
		Afick::Msg->set_error("$val is not a valid url");
		return;
	}
	## use critic
}
###############################################################################
# check if a valid file name
sub is_name($) {
	my $val = shift @_;

	if ( $val =~ m/^\w+[^\/;]*$/ ) {
		return $val;
	}
	else {
		Afick::Msg->set_error("$val is not a valid name");
		return;
	}
}
###############################################################################
# not yet used
#sub is_format($) {
#	my $val = shift @_;
#
#	my %format = (
#		'txt'  => 1,
#		'html' => 2,
#		'xml'  => 3,
#	);
#
#	if ( exists $format{$val} ) {
#		return $val;
#	}
#	else {
#		Afick::Msg->set_error("$val is not a valid format");
#		return;
#	}
#}
###############################################################################
# test if a valid operator
sub is_op($) {
	my $op = shift @_;

	return ( $op =~ m/^[+-]$/ );
}
###############################################################################
# is it running on a linux os ?
sub is_linux() {
	return ( $OSNAME =~ m/linux/i );
}
###############################################################################
# is it running on microsoft os ?
sub is_microsoft() {
	return ( $OSNAME =~ m/^MSWin/i );
}
##########################################################################
# patterns for following config line tests
##########################################################################
#
my $_val_pattern     = '(\S+.*)';    # mandatory value
my $_val_pattern_opt = '(\S*.*)';    # optionnal value
## no critic (RequireInterpolationOfMetachars)
my $_macro_pattern =
  q{^} . Afick::Constant->MACRO . '\s+(\w+)\s+';    # @@define name val

# sel lines :
#   not negesel equalsel : begin with ! =
#   not directives alias : contain =
#   not macro : begin with @@
#   but @file is allowed
my $_sel_pattern    = '^([^=!\@][^=]+)$|^(\@[^=\@]+)$';
my $_chroot_pattern = '^\@([^\s\@])';                     # @file
## use critic
my $_alias_pattern = '^(\w+)\s*=\s*';                     # name = val
my $_directive_pattern =
  '^(\w+)\s*' . Afick::Constant->DIREC . '\s*';           # name := val
my $_negsel_pattern =
  q{^} . Afick::Constant->NEGSEL . '\s*' . $_val_pattern;    # ! name
my $_equalsel_pattern =
  q{^} . Afick::Constant->EQUSEL . '\s*' . $_val_pattern;    # = name val
my $_file_pattern1 = '^\"(.+)\"';                            # "name with space"
my $_file_pattern2 = '^([^\s\"]+)';                          # name
my $_fileval_pattern1 =
  $_file_pattern1 . '\s+' . $_val_pattern;    # "name with space" val
my $_fileval_pattern2 = $_file_pattern2 . '\s+' . $_val_pattern;    # name val

###############################################################################
# is the string a chroot pattern
sub is_chroot_line($) {
	my $ligne = shift @_;    # string to be tested

	if ( $ligne =~ m/$_chroot_pattern/ ) {
		return $1;
	}
}
###############################################################################
# if in chroot mode, return chroot path
# else false
sub is_chroot_mode() {
	if ( exists $ENV{'AFICK_CHROOT'} ) {
		return $ENV{'AFICK_CHROOT'};
	}
	else {
		return 0;
	}
}
#######################################################
# all test pattern return :
# an empty array is not match
# an array of 2 values if match
###############################################################################
# low-level sub, to be called by is_macro, is_alias ...
sub _test_pattern ($$) {
	my $ligne   = shift @_;    # string to be tested
	my $pattern = shift @_;    # motif pattern

	if ( $ligne =~ m/$pattern/ ) {

		#print "found $1 : $2\n";
		return ( $1, $2 );
	}
	else {
		return ();
	}
}
###############################################################################
# is config line a macro line ?
sub is_macro_line($;$) {
	my $ligne = shift @_;         # string to be tested
	my $noval = shift @_ || 0;    # for afickonfig, allow delete

	#print "is_macro ";
	if ($noval) {
		return _test_pattern( $ligne, $_macro_pattern . $_val_pattern_opt );
	}
	else {
		return _test_pattern( $ligne, $_macro_pattern . $_val_pattern );
	}
}
###############################################################################
# is config line an alias line ?
sub is_alias_line($;$) {
	my $ligne = shift @_;         # string to be tested
	my $noval = shift @_ || 0;    # for afickonfig, allow delete

	#print "is_alias ";
	if ($noval) {
		return _test_pattern( $ligne, $_alias_pattern . $_val_pattern_opt );
	}
	else {
		return _test_pattern( $ligne, $_alias_pattern . $_val_pattern );
	}
}
###############################################################################
# is config line a directive line ?
sub is_directive_line($;$) {
	my $ligne = shift @_;         # string to be tested
	my $noval = shift @_ || 0;    # for afickonfig, allow delete

	#print "is_directive ";
	if ($noval) {
		return _test_pattern( $ligne, $_directive_pattern . $_val_pattern_opt );
	}
	else {
		return _test_pattern( $ligne, $_directive_pattern . $_val_pattern );
	}
}
###############################################################################
# is it a file pattern (from a config line part)
sub _is_file($) {
	my $ligne = shift @_;    # string to be tested

	if ( $ligne =~ m/$_file_pattern1/o ) {

		#print "file pattern1 $1 : $2\n";
		return ( $1, $2 );
	}
	elsif ( $ligne =~ m/$_file_pattern2/o ) {

		#print "file pattern2 $1 : $2\n";
		return ( $1, $2 );
	}
	else {

		#print "pb file_pattern\n";
		return ();
	}
}
###############################################################################
# search for "file val" pattern
sub _is_fileval($;$) {
	my $ligne = shift @_;         # string to be tested
	my $noval = shift @_ || 0;    # for afickonfig, allow delete

	if ($noval) {
		return _is_file($ligne);
	}
	elsif ( $ligne =~ m/$_fileval_pattern1/o ) {

		#print "file pattern1 var1=$1 var2=$2\n";
		return ( $1, $2 );
	}
	elsif ( $ligne =~ m/$_fileval_pattern2/o ) {

		#print "file pattern2 var1=$1 var2=$2\n";
		return ( $1, $2 );
	}
	else {

		#print "pb file_pattern\n";
		return ();
	}
}
###############################################################################
# test if the given line is an afick config negative selection
sub is_negsel_line($) {
	my $ligne = shift @_;    # string to be tested

	#print "is_negsel ";
	my @ret = _test_pattern( $ligne, $_negsel_pattern );
	if (@ret) {
		return _is_file( shift @ret );
	}
	else {

		#print "pb negsel_pattern\n";
		return ();
	}
}
###############################################################################
# test if the given line is an afick config equal selection
sub is_equalsel_line($) {
	my $ligne = shift @_;    # string to be tested

	#print "is_equalsel ";
	my @ret = _test_pattern( $ligne, $_equalsel_pattern );
	if (@ret) {
		return _is_fileval( shift @ret );
	}
	else {
		return ();
	}
}
###############################################################################
# test if the given line is an afick config selection
sub is_sel_line($;$) {
	my $ligne = shift @_;         # string to be tested
	my $noval = shift @_ || 0;    # for afickonfig, allow delete

	#print "is_sel ";
	my @ret = _test_pattern( $ligne, $_sel_pattern );
	if (@ret) {
		return _is_fileval( $ligne, $noval );
	}
	else {
		return ();
	}
}
###############################################################################
# test if the given line is an afick config selection type (negative, equal or normal)
sub is_anysel_line($) {
	my $ligne = shift @_;    # string to be tested

	#print "is_anysel ";
	my @ret = ();
	foreach my $func ( \&is_sel_line, \&is_equalsel_line, \&is_negsel_line ) {
		@ret = &{$func}($ligne);
		last if (@ret);
	}
	return @ret;
}
##########################################################################
# return true if the given perl module is installed
sub is_perl_module($) {
	my $module = shift @_;
	## no critic (ProhibitStringyEval)
	eval " require $module ";
	return ($EVAL_ERROR) ? 0 : 1;
}
##########################################################################
# test if crypto functions exists
{

	# several perl module can provide checksum
	# Digest (seems to be in standard perl) provide all sha*
	# Digest::SHA1 (perl-Digest-SHA1) in afick <= 2.19
	# Digest::SHA (perl-Digest-SHA), not in standard

	# private value used as a cache, to avoid too many calls
	# use Digest module
	my $sha_exist;

	sub is_sha(;$) {
		my $reset = shift @_;    # force cache reset (for tests)
		if ( ($reset) or ( !defined $sha_exist ) ) {
			$sha_exist = is_perl_module('Digest');
		}
		return $sha_exist;
	}

	# sha-1 keeped it for compatiblity
	# but should be suppressed in further releases
	my $sha1_exist;

	sub is_sha1(;$) {
		my $reset = shift @_;    # force cache reset (for tests)
		if ( ($reset) or ( !defined $sha1_exist ) ) {
			if ( is_sha() ) {
				$sha1_exist = 1;
			}
			else {
				$sha1_exist = is_perl_module('Digest::SHA1');
			}
		}
		return $sha1_exist;
	}

	# sha-256
	sub is_sha256() {
		return is_sha();
	}

	# sha-512
	sub is_sha512() {
		return is_sha();
	}
}
#######################################################
# do we are at top of file-system
sub is_fsroot($) {
	my $name = shift @_;

	if ( is_microsoft() ) {
		return ( $name =~ m/^[[:alpha:]]:\/$/ );    # c:\
	}
	else {
		return ( $name eq SLASH );                  # /
	}
}
###############################################################################
# test if windows acl exists
{

	# just a cache to avoid too many calls
	my $acl_exist;

	sub is_acl(;$) {
		my $reset = shift @_;    # force cache reset (for tests)

		if ( ($reset) or ( !defined $acl_exist ) ) {
			if ( is_microsoft() ) {

				# no critic (RequireCheckingReturnValueOfEval)
				if ( is_perl_module('Win32::FileSecurity') ) {

					# acl exists
					$acl_exist = TRUE;
				}
				else {
					Afick::Msg->debug(
"perl module Win32::FileSecurity not found : $EVAL_ERROR",
						D1
					);

					# will work but without acl
					$acl_exist = FALSE;
				}
			}
			else {

				# no acl on unix
				$acl_exist = FALSE;
			}
		}
		return $acl_exist;
	}
}
###############################################################################
# low-level sub to check a file type with macros from Fcntl
# used to test suid files
sub is_type($$) {
	my $p    = shift @_;    # file permission, ex : 755 (octal)
	my $flag = shift @_;    # flag from Fcntl, ex : S_ISUID()

	return ( ( $p & $flag ) == $flag );
}

###############################################################################
# test if data is not defined or does not contain a value
sub is_noval($) {
	my $data = shift @_;

	return ( ( !defined $data ) or ( $data eq EMPTY ) );
}
###############################################################################
# return true if arg is . or ..
sub is_special_dir($) {
	my $dir = shift @_;

	return ( ( $dir eq q{.} ) or ( $dir eq q{..} ) );
}
###############################################################################
# test if is a list, the default separator is the comma
sub is_list($;$) {
	my $val = shift @_;             # string to test
	my $sep = shift @_ || COMMA;    # optionnal separator

	if ( $val =~ m/$sep/ ) {
		return $val;
	}
	else {
		Afick::Msg->set_error("$val is not a list");
		return;
	}
}
###############################################################################
# test if val is a period, should be in the format nS
# with n a number
# S a scale : y for year, m for month, w for week or d for day (default)
# ex : 1y  2m
# return the number of days else undef
sub is_retention($) {
	my $val = shift @_;

	my %scales = (
		'y' => 365,
		'm' => 31,
		'w' => 7,
		'd' => 1,
	);

	if ( $val =~ m/^(\d+)(\w?)$/ ) {
		my $n = $1;
		my $s = $2 || 'd';
		if ( exists $scales{$s} ) {
			return $n * $scales{$s};
		}
		else {
			Afick::Msg->set_error(
				"$val is not a retention (bad scale $s, should d, w, m or y)");
			return;
		}
	}
	else {
		Afick::Msg->set_error(
			"$val is not a retention (bad format, should be nS)");
		return;
	}
}
#######################################################
# to detect dangling links
# return true if is a dangling link
sub test_dangling($) {
	my $elem = shift @_;    # file or directory to scan

	my $whatlink = readlink $elem;
	return 0 if ( !defined $whatlink );
	my $abs_whatlink;

	# is the link an absolute path ?
	if ( $whatlink !~ m{^/} ) {

		# relative path
		my ( $fic, $rep, undef ) = fileparse($elem);
		$abs_whatlink = $rep . Afick::Constant->SLASH . $whatlink;
		Afick::Msg->debug(
			"(parcours2) abs_whatlink for $elem : $abs_whatlink ($whatlink)",
			D2 );
	}
	else {
		# absolute path
		$abs_whatlink = $whatlink;
	}

	if ( !-e $abs_whatlink ) {

		# keep real path for display
		return $whatlink;
	}
	else {
		return 0;
	}
}
###############################################################################
1;
