#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# a general package for all acl routines
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::WinAcl;

use strict;
use warnings;

use English qw(-no_match_vars);
use base qw(Exporter);
use File::Basename;

use Win32::FileSecurity;
use Afick::Msg;
use Afick::Tst;    # is_acl
use Afick::Report;

## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );

$VERSION = '0.1';
@EXPORT  = qw( &split_acl &winacl &hash_acl &compare_acl );

my $Sepacl = q{,};
#######################################################
# acl
#######################################################
# transform a window's acl
# from binary form in hashtable
# to human way for display
sub split_acl($) {
	my $acl = shift @_;    # windows acl

	my @tab_acl = split /$Sepacl/, $acl;
	my @text;
	foreach my $acl_item (@tab_acl) {
		my ( $sid, $mask ) = split /=/, $acl_item;
		$sid = lc $sid;
		next if ( !defined $mask );
		my @rights;
		Win32::FileSecurity::EnumerateRights( $mask, \@rights );
		push @text, "$sid=" . join $Sepacl, @rights;
	}
	return @text;
}
#######################################################
# get windows acl for a given file
sub winacl($$) {
	my $filename = shift @_;    # file name
	my $dbm      = shift @_;

	my $acl = 0;
	my %perm;
	if ( is_acl() ) {
		my @acl;

		# catch the error to avoid stop the program
		eval { Win32::FileSecurity::Get( $filename, \%perm ) };
		if ($EVAL_ERROR) {
			Afick::Msg->debug(
				"(winacl) can not get windows acl for $filename : $EVAL_ERROR",
				3
			);
		}
		else {
			while ( my ( $name, $mask ) = each %perm ) {
				$name =~ s/ /_/g;
				push @acl, "$name=$mask";
			}
			$acl = join $Sepacl, sort @acl;

	   # caution : acl may be big, too big for sdbm database :
	   # There are a number of limits on the size of the data that you can store
	   # in the SDBM file. The most important is that the length of a key, plus
	   # the length of its associated value, may not exceed 1008 bytes.
			if ( $dbm eq 'SDBM_File' ) {
				## no critic (ProhibitParensWithBuiltins)
				my $len = length($acl) + length($filename);
				if ( $len > 800 ) {
					Afick::Msg->warning(
						"(winacl) remove acl for $filename, was too long : $len"
					);

					# try to reduce length
					$acl = 'removed (too long)';
				}
			}
		}
	}
	return $acl;
}
#######################################################
# transform a windows acl from array (split_acl)
# to a hash, to allow a easy compare
sub hash_acl(@) {
	my @tab = @_;

	my %acl;
	foreach my $elem (@tab) {
		my ( $sid, $acl ) = split /=/, $elem;
		$acl{$sid} = $acl;
	}
	return %acl;
}
#######################################################
# compare 2 acl : show new, deleted, changed
sub compare_acl($$$) {
	my $acl_old = shift @_;    # old value from database
	my $acl_new = shift @_;    # new value from database
	my $report  = shift @_;    # Afick::Report object

	my %acl_old = hash_acl( split_acl($acl_old) );
	my %acl_new = hash_acl( split_acl($acl_new) );

	my $nb_change = 0;
	my $nb_delete = 0;
	my $nb_new    = 0;
	foreach my $key ( keys %acl_old ) {
		if ( exists $acl_new{$key} ) {
			if ( $acl_old{$key} ne $acl_new{$key} ) {

				# changed acl
				$report->report_detailed( "change acl $key",
					$acl_old{$key}, $acl_new{$key} );
				$nb_change++;
			}
			delete $acl_new{$key};
		}
		else {

			# deleted acl
			$report->report_detailed( "deleted acl $key", $acl_old{$key} );
			$nb_delete++;
		}
	}

	# we have deleted all common keys on acl_new
	# so we just have new acl now
	foreach my $key ( keys %acl_new ) {

		# new acl
		$report->report_detailed( "new acl $key", $acl_new{$key} );
		$nb_new++;
	}
	return ( $nb_new, $nb_delete, $nb_change );
}
#######################################################
1;
