#!/usr/bin/env perl
###############################################################################
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id: Msg.pm 3342 2014-11-12 12:25:09Z gerbier $
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this class is used to read and analyse afick logs
#  is used in
#  	afick_format,
#  	afick_learn,  ok2
#  	afick_archive ok2
#  	afick-tk      ok2
#  	webmin module
#
###############################################################################
# history
# 1.0 : (2015) first code
###############################################################################
package Afick::Log;

use strict;
use warnings;

use English '-no_match_vars';
use POSIX qw(strftime);

# optional modules
###################

# other afick modules
#####################
use Afick::Msg;
use Afick::Constant;

use base qw(Exporter);
## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );
$VERSION = '1.1';

##################
# classe variables
##################

my $Sep      = PIPE;
my $Sep_meta = quotemeta $Sep;

###################
# methods
#######################################################
# constructor
sub new($) {
	my $class = shift @_;

	my $self = bless {}, $class;

	# instance attributes

	# meta-data : configuration
	%{ $self->{'config'} } = ();

	# meta-data : run
	%{ $self->{'run'} } = ();

	# warnings
	@{ $self->{'warnings'} } = ();

	# data
	%{ $self->{'data'} } = ();

	return $self;
}
########################################################
# metadata access
# will contains all running data, as
# date and time, afick version
sub get_run($) {
	my $self = shift @_;

	return %{ $self->{'run'} };
}
########################################################
# metadata access
# config contains afick config values for this run
# (config file may be overriden by command line options)
sub get_config($) {
	my $self = shift @_;

	return %{ $self->{'config'} };
}
########################################################
# data access : return types (new, deleted ...) list
sub get_data_types_k($) {
	my $self = shift @_;

	return keys %{ $self->{'data'} };
}
########################################################
# data : check if a given type exists in the log
sub exist_data_type($$) {
	my $self = shift @_;
	my $type = shift @_;    # ex new_directory

	return exists $self->{'data'}{$type};
}
########################################################
# data access : return file names for a given type
sub get_data_names_k($$) {
	my $self = shift @_;
	my $type = shift @_;    # ex changed_file

	return keys %{ $self->{'data'}{$type} };
}
########################################################
# data : check if the given name exists in type category
sub exist_data_name($$$) {
	my $self = shift @_;
	my $type = shift @_;    # ex deleted_directory
	my $name = shift @_;    # file name

	return exists $self->{'data'}{$type}{$name};
}
########################################################
# data access : return the list of fields for a given type and name
sub get_data_fields_k($$$) {
	my $self = shift @_;
	my $type = shift @_;
	my $name = shift @_;

	return keys %{ $self->{'data'}{$type}{$name} };
}
########################################################
# data : check if the field/name/type exists in log
sub exist_data_field($$$$) {
	my $self  = shift @_;
	my $type  = shift @_;    # ex new_file
	my $name  = shift @_;    # file name
	my $field = shift @_;    # field (md5, mtime ...)

	return exists $self->{'data'}{$type}{$name}{$field};
}
########################################################
# data access
# return the field value for a given type, filename and field
sub get_data_field($$$$) {
	my $self  = shift @_;
	my $type  = shift @_;
	my $name  = shift @_;
	my $field = shift @_;

	return $self->{'data'}{$type}{$name}{$field};
}
########################################################
# test if the given field contains 2 values or not
sub is_dual_field($$) {
	my $self  = shift @_;
	my $field = shift @_;

	return ( $field =~ m/$Sep_meta/ );
}
########################################################
# split the field into 2 values
sub split_dual_field($$) {
	my $self  = shift @_;
	my $field = shift @_;

	return split /$Sep_meta/, $field;
}
########################################################
# metadata access
# return warnings
sub get_warnings($) {
	my $self = shift @_;

	return @{ $self->{'warnings'} };
}
########################################################
# analyse a log from a filename
sub parse_file($) {
	my $self = shift @_;
	my $file = shift @_;

	my $ret;    # return code 1 if ok, 0 if problem
	if ( open my $fh, '<', $file ) {
		my @tab = <$fh>;
		$self->parse_array( \@tab );

		## no critic (RequireCheckedClose,RequireCheckedSyscalls)
		close $fh;
		$ret = 1;
	}
	else {
		Afick::Msg->warning( 'can not open ' . $file . ' : ' . $ERRNO );
		$ret = 0;
	}
	return $ret;
}

#################################################
# analyse metadata : run , config, warnings
sub _log_parser_metadata($$$$) {
	my $self    = shift @_;
	my $ligne   = shift @_;
	my $line_nb = shift @_;

	my $nb_pb = 0;
	## no critic (ProhibitCascadingIfElse,ProhibitEscapedMetacharacters)
# Afick (3.5) compare at 2015/04/16 16:36:40 with options (/sauvegarde/gerbier/projets/afick/branches/afick-3.5/essais/essai.conf):
	if ( $ligne =~
		m/^# Afick \((.*)\) (\w+) at (\S*) (\S*) with options \((.*)\)/ )
	{
		my $version = $1;
		my $action  = $2;
		my $date    = $3;
		my $time    = $4;
		my $config  = $5;
		$self->{'run'}{'version'}    = $version;
		$self->{'run'}{'action'}     = $action;
		$self->{'run'}{'date'}       = $date;
		$self->{'run'}{'time'}       = $time;
		$self->{'run'}{'configfile'} = $config;
	}

	# MD5 hash of /var/lib/afick/afick => b5fpLjCDevklUoKic45zTg
	elsif ( $ligne =~ m/^# MD5 hash of (.*) => (.*)/ ) {
		my $database = $1;
		my $md5      = $2;
		$self->{'run'}{'md5'} = $md5;
	}

	# user time : 37.4; system time : 4.43; real time : 147
	elsif ( $ligne =~
		m/^# user time : (.*); system time : (.*); real time : (\d+)/ )
	{
		$self->{'run'}{'user_time'} = $1;
		$self->{'run'}{'syst_time'} = $2;
		$self->{'run'}{'real_time'} = $3;
	}
	elsif ( $ligne =~ m/^# Hash database/ ) {

		# skip
		# todo in next release in run hash ?
	}
	elsif ( $ligne =~ m/^# ############################/ ) {

		# skip
	}
	elsif ( $ligne =~ m/# detailed changes/ ) {

		# skip
	}
	elsif ( $ligne =~ m/# summary/ ) {

		# skip
	}

	# last run on 2015/04/16 16:15:02 with afick version 3.5
	elsif ( $ligne =~ m/^# last run on (\S*) (\S*) with afick version (.*)/ ) {
		$self->{'run'}{'previous_run_date'}    = $1;
		$self->{'run'}{'previous_run_time'}    = $2;
		$self->{'run'}{'previous_run_version'} = $3;
	}

	# warn_dead_symlinks:=1
	elsif ( $ligne =~ m/^# (.*):=(.*)/ ) {

		# config parameters
		my $param = $1;
		my $value = $2;
		$self->{'config'}{$param} = $value;
	}
	else {
		# strange line
		Afick::Msg->warning("unknow metadata line $line_nb : $ligne");
		$nb_pb++;
	}
	return $nb_pb;
}

##################################################################
# analyse a log from an array
sub parse_array($$) {
	my $self   = shift @_;
	my $ra_log = shift @_;    # (input) contains log

	my %data;
	my $name;
	my $type;
	my $nb_pb = 0;

	my $line_nb = 0;
	foreach my $ligne ( @{$ra_log} ) {
		chomp $ligne;
		$line_nb++;

		Afick::Msg->debug( "$ligne", D3 );

		## no critic (ProhibitCascadingIfElse)
		if ( $ligne =~ m/^DEBUG/ ) {

			# skip
		}
		elsif ( $ligne =~ m/^WARNING: (.*)/ ) {
			push @{ $self->{'warnings'} }, $1;
		}
		elsif ( $ligne =~ m/^CRITICAL: (.*)/ ) {
			push @{ $self->{'warnings'} }, $1;
		}
		elsif ( $ligne eq EMPTY ) {

			# skip empty line
		}
		elsif ( $ligne =~ m/^#/ ) {

			# metadata
			$nb_pb += $self->_log_parser_metadata( $ligne, $line_nb );
		}

		# detailed part
		# #############

		# changed file : /sauvegarde/afick-3.5/essais/essai.conf
		elsif ( $ligne =~ m/^(\w+.*)\s+: (.*)/ ) {
			if (%data) {

				# store data
				my %d = %data;
				$self->{'data'}{$type}{$name} = \%d;
				Afick::Msg->debug( "store $name", D4 );

				# empty
				%data = ();
				$name = undef;

			}
			$type = $1;
			$name = $2;
			$type =~ s/\s+$//;
			$type =~ s/\s/_/g;

			Afick::Msg->debug( "find $type $name", D4 );
		}

		# atime : Thu Apr 16 16:15:02 2015     Thu Apr 16 16:36:40 2015
		elsif ( $ligne =~ m/^\t(\w+)\s+: (.*)\t(.*)/ ) {

			my $field = $1;
			my $old   = $2;
			my $new   = $3;

			# make a diff on warning and info ?
			# remove warning/info prefix (afick.pl /  sub display_changes)
			# because tools like afick_learn will not work
			$field =~ s/^w_//;
			$field =~ s/^i_//;

			if ( defined $name ) {

				#$data{'name'} = $name;
				$data{$field} = $old . PIPE . $new;
			}
			else {
				warn "data(2) without file name : $ligne\n";
				$nb_pb++;
			}
			Afick::Msg->debug("find field $field old=$old new=$new");
		}

		#         number of deleted files          : 8462
		#         linked_to                : coucou
		elsif ( $ligne =~ m/^\t(.*)\s+:\s(.*)/ ) {
			my $field = $1;
			my $old   = $2;
			$field =~ s/\s*$//g;
			$field =~ s/ /_/g;

			if ( defined $name ) {

				#$data{'name'} = $name;
				$data{$field} = $old;
			}
			else {
				warn "data(1) without file name : $ligne\n";
				$nb_pb++;
			}
		}
		else {
			# strange line
			warn "unknow log line $line_nb : $ligne\n";
			$nb_pb++;
		}

		if (%data) {

			# flush
			my %d = %data;
			$self->{'data'}{$type}{$name} = \%d;
		}
	}    # foreach

	return $nb_pb;
}
#######################################################################
# summary
sub stats($) {
	my $self = shift @_;

	Afick::Msg->info('---------- stats ----------------');
	foreach my $type ( $self->get_data_types_k() ) {
		my $nb = scalar $self->get_data_names_k($type);

		Afick::Msg->info("$type : $nb");
	}
	Afick::Msg->info('-------------------------------');
	return;

}
#######################################################################
1;
__END__

=head1 NAME

Afick::Log - a library for messages

=head1 DESCRIPTION


=head1 DIAGNOSTICS

=head1 USAGE

use Afick::Log;

my $log = Afick::Log->new();

$log->parse_file( $fic );
$log->parse_array( \@tab );

afick_format is a very good code

=head1 NOTES


=head1 OPTIONS

=head1 REQUIRED ARGUMENTS

=head1 EXIT STATUS

=head1 CONFIGURATION

=head1 DEPENDENCIES

Afick::Msg

=head1 INCOMPATIBILITIES

=head1 BUGS AND LIMITATIONS

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2015 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net

