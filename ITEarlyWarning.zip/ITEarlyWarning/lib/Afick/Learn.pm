#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# a general package for all learn* routines
# to be shared between afick_learn and afick_learn_tk
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Learn;

use strict;
use warnings;

use English qw(-no_match_vars);
use base qw(Exporter);
use File::Basename;

## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );

$VERSION = '1.0';
@EXPORT  = qw( &learn_version &learn_parse_log &learn_compute_changes
  &learn_unpack &learn_get_changes
);

# afick modules
#####################
use Afick::Constant;    # TRUE/FALSE
use Afick::Msg;         # for set_error
use Afick::Log;         #
use Afick::Cfg;         #

#############################################################
my @Changes;            # store all detected changes

sub learn_get_changes() {
	return \@Changes;
}
#############################################################
my $Sep = q{:};         # record separator for @Changes

sub learn_pack($$$$) {
	my $fname         = shift @_;
	my $oldrule_human = shift @_;
	my $newrule_human = shift @_;
	my $remove        = shift @_;

	return join $Sep, $fname, $oldrule_human, $newrule_human, $remove;
}

sub learn_unpack($) {
	my $change_record = shift @_;

	return split /$Sep/, $change_record;
}
#############################################################
# display version and exit
sub learn_version($) {
	my $version = shift @_;
	print "\n";
	print
"afick_learn : another file integrity checker learning tool\nversion $version\n";
	return;
}

#############################################################
# parse afick's log file
# search and return for modified (changed) items
sub learn_parse_log($) {
	my $rh_opt = shift @_;

	my %changes;    # hash of arrays

	my %search = ( 'changed' => 1, );

	my $log = Afick::Log->new();
	$log->parse_file( $rh_opt->{'log_file'} );

	foreach my $type ( sort $log->get_data_types_k() ) {
		## no critic (ProhibitStringySplit)
		my ( $style, undef ) = split q{_}, lc $type;

		#print "debug type=$type style=style\n";
		next unless exists $search{$style};
		foreach my $name ( sort $log->get_data_names_k($type) ) {
			foreach my $field ( sort $log->get_data_fields_k( $type, $name ) ) {
				push @{ $changes{$name} }, $field;
			}
		}
	}

	return %changes;
}
#############################################################
# remove detected fields from config files
sub learn_compute_changes($$) {
	my $rh_opt     = shift @_;
	my $rh_changes = shift @_;

	my $config_file = $rh_opt->{'config_file'};

	# read configuration
	my $config = Afick::Cfg->new($config_file);
	$config->read_configuration();
	my %rules = $config->rules();

	# hash from output to internal
	# todo : look @Field in afick.pl
	my %id = (
		'md5'      => '5',
		'device'   => 'd',
		'inode'    => 'i',
		'filemode' => 'p',
		'links'    => 'n',
		'uid'      => 'u',
		'gid/acl'  => 'g',
		'filesize' => 's',
		'blocs'    => 'b',
		'atime'    => 'a',
		'mtime'    => 'm',
		'ctime'    => 'c',
		'sha'      => '[126]',
	);

	# hash from output to alias syntax
	my %id2 = (
		'md5'      => 'md5',
		'device'   => 'd',
		'inode'    => 'i',
		'filemode' => 'p',
		'links'    => 'n',
		'uid'      => 'u',
		'gid/acl'  => 'g',
		'filesize' => 's',
		'blocs'    => 'b',
		'atime'    => 'a',
		'mtime'    => 'm',
		'ctime'    => 'c',
		'sha'      => 'sha',
	);

	# analyse
	foreach my $f ( sort keys %{$rh_changes} ) {

		# do not change rules on control files
		next if ( $config->is_control($f) );

		# get rule
		my $scan;    # rule for f file
		my $ff;      # f parent
		if ( exists $rules{$f} ) {

			# f exists in config file
			$ff   = $f;
			$scan = $config->to_scan($f);
			if ($scan) {
				Afick::Msg->debug("(compute_changes) config $f rule = $scan");
			}
			else {
				# should not possible but ...
				Afick::Msg->warning(
					"(compute_changes) can not find rule for $f");
				next;
			}
		}
		else {
			# f is a child ; find parent
			( $ff, $scan ) = $config->get_parent($f);
			if ($ff) {
				Afick::Msg->debug(
					"(compute_changes) find parent $ff for $f : $scan");
			}
			else {
				Afick::Msg->warning(
					"(compute_changes) can not find parent for $f");
				next;
			}
		}
		my $oldrule_human = $config->decode_alias($scan);

		# build new aliase
		my $newrule = $scan;
		my $remove;
		foreach my $r ( @{ $rh_changes->{$f} } ) {
			if ( exists $id{$r} ) {
				my $alias = $id{$r};
				$newrule =~ s/$alias//;
				$remove .= q{-} . $id2{$r};    # for output only
			}
			else {
				Afick::Msg->warning("(compute_changes) problem on alias $r");
			}
		}

		my $newrule_human;
		if ( !$newrule ) {

			# empty rule : exclude (negative selection)
			$newrule_human = Afick::Constant->NEGSEL;
		}
		else {
			# change internal format to config format
			my $newrule2 = $config->decode_alias($newrule);
			$newrule_human = "$newrule2";
		}
		my $change_record =
		  learn_pack( $f, $oldrule_human, $newrule_human, $remove );
		Afick::Msg->debug($change_record);
		push @Changes, $change_record;

	}    # foreach
	return;
}
###############################################################################
1;
