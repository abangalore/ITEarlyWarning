#!/usr/bin/env perl
###############################################################################
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this class is used for all afick messages (stdout/stderr, syslog, file ...)
#
# rem : do not mix instances call and class methods calls
#
###############################################################################
# history
# 1.1 : (2010) first code
# 1.2 : (2011-09) message level for all type of messages
# 1.3 : (2010-10) fix destroy problem
###############################################################################
package Afick::Msg;

use strict;
use warnings;

use English '-no_match_vars';
use POSIX qw(strftime);

# optional modules
###################
# Sys::Syslog

# other afick modules
#####################
use Afick::Constant;

use base qw(Exporter);
## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );
$VERSION = '1.4';
@EXPORT  = qw( Critical Warning Info D1 D2 D3 D4);

# the Readonly module is not available everywhere
# (example : activeperl), so we use constant pragma
## no critic (ProhibitConstantPragma,ProhibitEmptyQuotes,ProhibitNoisyQuotes,Capitalization)
# exported constants : message levels
use constant {
	Critical => -2,    # critical message level
	Warning  => -1,    # warning message level
	Info     => 0,     # info message level
	D1       => 1,     # debug message level (low debug)
	D2       => 2,     # debug message level (intermediate)
	D3       => 3,     # debug message level (intermediate)
	D4       => 4,     # full debug message level
};

# internal constants
use constant {
	Progres => 'progress',    # header for progress
	Comment => '#',           # header for comments
};
## use critic

##################
# classe variables
##################
my $Msg_level      = Info;      # message level
my $Verbose        = FALSE;     # set verbose (is equivalent to full debug)
my $Report_url     = 'STDOUT';  # where to send messages (stdout/stderr/nothing)
my $Report_syslog  = FALSE;     # true to send message to syslog
my $Progress       = FALSE;     # true to print progress messages
my $Archive_df     = undef;     # file descriptor to write to
my $Error_msg      = EMPTY;     # store a message
my $Delayed_buffer = EMPTY;     # buffer to store delayed comments
my $Quiet = FALSE;    # quiet mode : only print comments if some warnings exists

my $Nb_instance = 0;  # count object instances (for destroy)
my $Id_instance = 0;  # instance id (to follow destroy order)
###################
# methods
#######################################################
# constructor
sub new($) {
	my $class = shift @_;

	$Nb_instance++;

	# instance attributes
	my $self = {};
	$self->{'id'} = $Id_instance++;

	return bless $self, $class;
}
#######################################################
# methods over $Msg_level
# this will act as message filter
# very similar to syslog use
#######################################################
# return message level
sub get_msg_level($) {
	my $self = shift @_;

	return $Msg_level;
}

#------------------------------------------------------
# set message level
# return true if set is done
sub set_msg_level($$) {
	my $self  = shift @_;
	my $entry = shift @_;    # constants : D4 to Critical

	# valididity
	if ( Afick::Msg->is_valid_msg_level($entry) ) {
		$Msg_level = $entry;
		return TRUE;
	}
	else {
		return FALSE;
	}
}

#------------------------------------------------------
# return maximum message level
sub get_max_msg_level($) {
	my $self = shift @_;

	return D4;
}

#------------------------------------------------------
# is entry a valid message level ?
sub is_valid_msg_level($$) {
	my $self  = shift @_;
	my $entry = shift @_;    # message level

	return (  ( $entry >= Critical )
		  and ( $entry <= $self->get_max_msg_level() ) );
}
#######################################################
# methods over $Verbose
# this is an (old) method which act as full debug
#######################################################
# return verbose state
sub get_verbose($) {
	my $self = shift @_;

	return $Verbose;
}

#------------------------------------------------------
# set verbose state
# arg is not tested, but any value can act as true/false
sub set_verbose($$) {
	my $self = shift @_;
	$Verbose = shift @_;    # boolean

	return;
}

#######################################################
# methods over $Quiet
# this will use to delay (bufferize) info and debug output
# until a warning/critical message is sent
# ! do not use this feature in debug mode !
#######################################################
# return quiet state
sub get_quiet($) {
	my $self = shift @_;

	return $Quiet;
}

#------------------------------------------------------
# set quiet state
# ! arg is not tested, but any value can act as true/false
sub set_quiet($$) {
	my $self = shift @_;
	$Quiet = shift @_;    # boolean

	# will flush
	if ( !$Quiet ) {
		$self->_flush_comments();
	}
	return;
}
#######################################################
# methods over $Report_url
#######################################################
# return report_url value
sub get_report_url($) {
	my $self = shift @_;

	return $Report_url;
}

#------------------------------------------------------
# test for valid values
sub is_valid_url($$) {
	my $self  = shift @_;
	my $value = shift @_;    # see below

	# authorized values
	# ps : STDOUT and STDERR must be in upper case
	# because report sub use them as special file handler
	my %ok = (
		'NULL'   => 1,
		'STDOUT' => 1,
		'STDERR' => 1,
	);
	return ( exists $ok{$value} );
}

#------------------------------------------------------
# set report_url value
sub set_report_url($$) {
	my $self  = shift @_;
	my $value = uc shift @_;    # see below

	my $ret;
	if ( $self->is_valid_url($value) ) {
		$Report_url = $value;
		$ret        = TRUE;
	}
	else {
		$ret = FALSE;
	}
	return $ret;
}
#######################################################
# methods over $Report_syslog : syslog use
#######################################################
# return Report_syslog state
sub get_syslog($) {
	my $self = shift @_;

	return $Report_syslog;
}

#------------------------------------------------------
# set Report_syslog state
sub set_syslog($$) {
	my $self       = shift @_;
	my $new_syslog = shift @_;    # boolean

	my $old_syslog = $Report_syslog;

	# just do something if state change
	if ( $old_syslog != $new_syslog ) {
		$Report_syslog = $new_syslog;
		if ($Report_syslog) {
			$self->_open_syslog();
		}
		else {
			$self->_close_syslog();
		}
	}
	else {
		$self->debug( 'no syslog change', D4 );
	}
	return;
}

#------------------------------------------------------
# open syslog traffic
sub _open_syslog($) {
	my $self = shift @_;

	# no critic (RequireCheckingReturnValueOfEval)
	eval { require Sys::Syslog };
	if ($EVAL_ERROR) {

		# can not use syslog
		# so reset to false
		$Report_syslog = FALSE;
		$self->warning(
"can not use syslog : perl module Sys::Syslog not found : $EVAL_ERROR"
		);
	}
	else {

		# ok : open syslog
		import Sys::Syslog;
		openlog( 'afick', 'ndelay', 'user' );
		$self->debug( 'open_syslog', D4 );
	}
	return;
}

#------------------------------------------------------
# close syslog traffic
sub _close_syslog($) {
	my $self = shift @_;

	closelog();
	$self->debug( 'close_syslog', D4 );
	return;
}

#------------------------------------------------------
# write on syslog
# rem : called from DESTROY
sub _my_syslog($$$) {
	my $self     = shift @_;
	my $priority = shift @_;    # 'info', 'notice', warning', ...
	my $text     = shift @_;

	return unless $Report_syslog;

	# replace tab by space
	$text =~ s/\t/        /g;

	syslog( $priority, $text );
	return;
}
#######################################################
# reporting methods
#######################################################
# return true if the message should be filtered
sub _is_msg_filtered($$) {
	my $self      = shift @_;
	my $msg_level = shift @_;    # message level

	return ( ( !$Verbose ) and ( $msg_level > $self->get_msg_level() ) );
}

#------------------------------------------------------
sub _add_buffer($$) {
	my $self = shift @_;
	my $text = shift @_;

	# store comments in a buffer
	if ( $Delayed_buffer eq EMPTY ) {

		# first line
		$Delayed_buffer = $text;
	}
	else {

		# not empty
		$Delayed_buffer .= LF . $text;
	}
	return;
}

#------------------------------------------------------
# flush info buffer
sub _flush_comments($) {
	my $self = shift @_;

	if ($Delayed_buffer) {

		# send delayed comments (report will add a linefeed)
		$self->report( $Delayed_buffer, Info );

		$Delayed_buffer = EMPTY;
	}
	return;
}

#------------------------------------------------------
# for critical report and exit
## no critic (RequireFinalReturn)
sub my_die($$) {
	my $self = shift @_;
	my $text = shift @_;

	# nota : die will be done in report sub
	$self->report( "CRITICAL: $text", Critical, 'warning', 'die' );

}
## use critic (RequireFinalReturn)

#------------------------------------------------------
# report a problem
sub warning($$) {
	my $self = shift @_;
	my $text = shift @_;

	$self->report( "WARNING: $text", Warning, 'warning', 'STDERR' );
	return;
}

#------------------------------------------------------
# report an info
sub info($$) {
	my $self = shift @_;
	my $text = shift @_;

	my $msg = Comment . " $text";
	if ( $self->get_quiet() ) {
		$self->_add_buffer($msg);
	}
	else {

		# immediatly print comments
		$self->report( $msg, Info );
	}
	return;
}

#------------------------------------------------------
# report debugging message
sub debug($$;$) {
	my $self  = shift @_;
	my $text  = shift @_;
	my $level = shift @_;    # optionnal level

	if ( !defined $level ) {
		$level = $self->get_max_msg_level();
	}

	my $msg = "DEBUG$level: $text";
	if ( $self->get_quiet() ) {
		$self->_add_buffer($msg);
	}
	else {
		$self->report( $msg, $level );
	}
	return;
}

#------------------------------------------------------
# blank lines are used as separator in afick report
sub crlf($) {
	my $self = shift @_;

	# because report add a line feed on each line
	my $msg = EMPTY;
	if ( $self->get_quiet() ) {
		$self->_add_buffer($msg);
	}
	else {
		$self->report( $msg, Info );
	}
	return;
}

#------------------------------------------------------
# send all kind of messages with a line feed
# to all configured destinations
# (may be archive, syslog, output/stderr)
sub report($$$;$$) {
	my $self            = shift @_;
	my $text            = shift @_;
	my $level           = shift @_;               # message level
	my $syslog_priority = shift @_ || 'notice';
	my $url             = shift @_;               # STDOUT / STDERR/ NULL

	if ( $self->_is_msg_filtered($level) ) {
		return;
	}

	if ( !defined $url ) {
		$url = $self->get_report_url();
	}

	# if report is called from warning, my_die ...
	if ( ( $level < Info ) and $self->get_quiet() ) {
		$self->set_quiet(FALSE);
	}

	# add line feed
	$text .= LF;

	# progress messages are not sent to files/syslog
	if ( !$self->_is_progress($text) ) {

		# 1 archive
		$self->_write_archive($text);

		# 2 syslog
		$self->_my_syslog( $syslog_priority, $text );
	}

	# 3 output
	## no critic (TestingAndDebugging);
	# because url is not a file handler
	no strict 'refs';
	if ( $url eq 'die' ) {
		## no critic (RequireCarping)
		die $text;
	}
	elsif ( $url ne 'NULL' ) {
		print {$url} $text;
	}
	## use critic

	return;
}
########################################################
# progress : used by gui to show currently scanned file
########################################################
# report afick progress (currently scanned file)
sub progress($$) {
	my $self = shift @_;

	if ($Progress) {
		$self->report( Progres . " @_", Info );
	}
	return;
}

#------------------------------------------------------
# return true if this text a progress text
sub _is_progress($$) {
	my $self = shift @_;
	my $text = shift @_;

	return ( index( $text, Progres ) == 0 );
}

#------------------------------------------------------
# set progress state
sub set_progress($$) {
	my $self = shift @_;
	$Progress = shift @_;    # boolean

	return;
}

#------------------------------------------------------
# return progress state
sub get_progress($) {
	my $self = shift @_;

	return $Progress;
}
#######################################################
# in debug mode 4, display call stack
# like a debugger
sub showstack($) {
	my $self = shift @_;

	my $i = 0;
	while ( my @rslt = caller $i ) {
		$self->debug(
"Frame $i: package $rslt[0] file $rslt[1] line $rslt[2] call $rslt[3]",
			D4
		);
		$i++;
	}
	return;
}
#######################################################
# this methods allow to track subroutine use
# just have to insert Afick::Msg->debug_begin() and Afick::Msg->debug_end()
#######################################################
# to get full info from caller line
sub _get_caller($) {
	my $self = shift @_;

	#my $level = shift @_ || 1;
	my $level = 1;

	my (
		undef, $filename, $line, undef, undef,
		undef, undef,     undef, undef, undef
	) = caller $level++;
	my (
		undef, undef, undef, $subroutine, undef,
		undef, undef, undef, undef,       undef
	) = caller $level;
	$subroutine = $subroutine || 'main';
	return "${subroutine}($filename $line)";
}

#------------------------------------------------------
# to be used to track subroutine use begin
# use debug level 4
sub debug_begin($;$) {
	my $self = shift @_;
	my $text = shift @_ || EMPTY;    # optionnal text

	$self->debug( 'begin ' . $self->_get_caller() . " $text", D4 );
	return;
}

#------------------------------------------------------
# to be used to track subroutine use end
# use debug level 4
sub debug_end($;$) {
	my $self = shift @_;
	my $text = shift @_ || EMPTY;    # optionnal text

	$self->debug( 'end ' . $self->_get_caller() . " $text", D4 );
	return;
}
######################################################
# for archive (log file)
# rem : close file is done by DESTROY
######################################################
# open or close archive file
# return file name on open success
sub set_archive($$$) {
	my $self        = shift @_;
	my $archive_dir = shift @_;    # directory to write to
	my $date        = shift @_;    # in epoch

	my $iret;

	$self->debug( '(set_archive)', D3 );
	if ($archive_dir) {

		# call for open
		if ( $self->is_archive() ) {

			# already opened archive
			$self->debug( 'already closed archive', D4 );
			$iret = FALSE;
		}
		elsif ( !-d $archive_dir ) {
			$Archive_df = undef;
			$self->warning(
				"(open_archive) archive directory $archive_dir does not exist"
			);
			$iret = FALSE;
		}
		else {

			# convert date in human syntax
			my @date = localtime $date;

			# open archive file
			my $archive_file =
			  $archive_dir . '/afick.' . strftime( '%Y%m%d%H%M%S', @date );

			## no critic (RequireBriefOpen)
			if ( !open $Archive_df, '>', $archive_file ) {
				$Archive_df = undef;
				$self->warning(
"(open_archive) can not open archive file $archive_file : $ERRNO"
				);
				$iret = FALSE;
			}
			else {
				$self->debug( "(open_archive) file $archive_file", D1 );
				$iret = $archive_file;
			}
		}
	}
	elsif ( $self->is_archive() ) {

		# call for close
		$iret = $self->_close_archive();
	}
	else {

		# already closed archive
		$self->debug( 'already closed archive', D4 );
		$iret = FALSE;
	}
	return $iret;
}

#------------------------------------------------------
# rem : called from DESTROY
sub _close_archive($) {
	my $self = shift @_;

	my $iret = close $Archive_df;
	$Archive_df = undef;    # must be before debug
	return $iret;
}

#------------------------------------------------------
# true is file descriptor is set
sub is_archive($) {
	my $self = shift @_;

	return $Archive_df;
}

#------------------------------------------------------
# write to archive file
sub _write_archive($$) {
	my $self = shift @_;
	my $text = shift @_;

	print {$Archive_df} $text if ( $self->is_archive() );
	return;
}
########################################################
# this code is used to store/retrieve an error message
########################################################
# store an error
sub set_error($$) {
	my $self  = shift @_;
	my $error = shift @_;

	$Error_msg = $error;
	return;
}

#------------------------------------------------------
# reset the message
sub reset_error($) {
	my $self = shift @_;

	$Error_msg = EMPTY;
	return;
}

#------------------------------------------------------
# return and reset the message
sub get_error($) {
	my $self = shift @_;

	my $msg = $Error_msg;
	$self->reset_error();
	return $msg;
}
########################################################
sub DESTROY($) {
	my $self = shift @_;

	$Nb_instance--;
	$self->debug( 'destroy Msg instance ' . $self->{'id'}, D4 );

	if ( $Nb_instance == 0 ) {

		# close file handle only on last instance destroy
		# (or a destroy will modify others instances)

		# 1 archive
		if ( $self->is_archive() ) {
			$self->_close_archive();
		}

		# 2 syslog
		# test must be done here and not in _close_syslog
		# because of set_syslog code ( true to false)
		if ( $self->get_syslog() ) {
			$self->_close_syslog();
		}
	}
	return;
}
########################################################
1;
__END__

=head1 NAME

Afick::Msg - a library for messages

=head1 DESCRIPTION

the idea is very similar to syslog : have a generic lib
for messages of different level, which may be sent to different
media (output, file, syslog ...)

=head1 DIAGNOSTICS

=head1 USAGE

use Afick::Msg;

Afick::Msg->warning('warning message');

=head1 NOTES

there should be only one config in a program
this can be done :
- with instance (and instance attribute) in a singleton class (be careful with is)
- with class variables (which allow also class methods) : this is the recommended method

so the rule is to use a global instance in each program.

=head1 OPTIONS

=head1 REQUIRED ARGUMENTS

=head1 EXIT STATUS

=head1 CONFIGURATION

=head1 DEPENDENCIES

Afick::Constant

=head1 INCOMPATIBILITIES

=head1 BUGS AND LIMITATIONS

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2011 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net

