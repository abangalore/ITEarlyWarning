#!/usr/bin/perl -w 
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classe contains all "plugins" : code to read and analyse database
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Plugins;

use strict;
use warnings;

use English qw(-no_match_vars);

use Exporter;
use base qw(Exporter);

## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );

$VERSION = 0.1;
@EXPORT  = qw( &stat_secu &stat_size &stat_ext &stat_date
  &print_dbm &export_csv);

use Afick::Msg;
use Afick::Gen;
use Afick::Tst;
use Afick::Backend;

##############################################################
# plugins
##############################################################
# common code to init a plugin
sub init_plugin($$$$) {
	my $backend      = shift @_;
	my $config       = shift @_;    # Cfg object
	my $date_ref_hum = shift @_;
	my $comment      = shift @_;

	$backend->open_database( $config, $comment, $date_ref_hum,
		main::get_afick_version() );

	# add database controls
	main::auto_control_prepdb();

	# check if afick was changed
	main::auto_control_check();

	return;
}
##############################################################
# generic display sub to be called by stat_secu
sub _display_group($$@) {
	my $backend = shift @_;
	my $text    = shift @_;
	my @group   = @_;

	Afick::Msg->info( "$text : " . scalar @group );
	foreach my $key (@group) {
		my $rec = $backend->get($key);
		Afick::Msg->report(
			$rec->file_type() . " $key"
			  . $rec->sep()
			  . $rec->display('filemode'),
			Afick::Msg->Info
		);
	}

	return;
}
#######################################################
# display info on specific 'dangerous' files from database
# suid / sgid files
# world / group write
# uid / gid orphans
sub stat_secu($$$) {
	my $backend      = shift @_;
	my $config       = shift @_;    # Cfg object
	my $date_ref_hum = shift @_;

	init_plugin( $backend, $config, $date_ref_hum, 'stat_secu' );

	my @suid;
	my @sgid;
	my @gwrite;
	my $gwriteflag = oct 20;
	my @world;
	my $worldflag = oct 2;
	my @uid_orphan;
	my @gid_orphan;

	# get uid and gid
	#################
	my ( %uid, %gid );
	if ( !is_microsoft() ) {
		while ( my ( $name, undef, $uid ) = getpwent ) {
			$uid{$uid} = $name;
		}

		while ( my ( $name, undef, $gid ) = getgrent ) {
			$gid{$gid} = $name;
		}
	}

	# analyse datas
	################
	# use of filterdb is much longer
	# and I have problems with test of symbolic links
	#@world = filterdb( '(filemode & 02) and  ! (filemode & S_IFLNK) ');
	#@gwrite = filterdb( '(filemode & 020) and  ! (filemode & S_IFLNK)');
	#@suid   = filterdb( 'filemode & S_ISUID ');
	#@sgid   = filterdb( 'filemode & S_ISGID ');

	# so just a classic loop
	foreach my $key ( sort $backend->getkeys() ) {
		my $rec = $backend->get($key);

		my $fmode = $rec->filemode();
		next if ( Afick::Gen::S_ISLNK($fmode) );
		if ( $fmode & $worldflag ) {
			push @world, $key;
		}
		if ( $fmode & $gwriteflag ) {
			push @gwrite, $key;
		}
		if ( is_type( $fmode, Afick::Gen::S_ISUID() ) ) {
			push @suid, $key;
		}
		if ( is_type( $fmode, Afick::Gen::S_ISGID() ) ) {
			push @sgid, $key;
		}
		if ( !is_microsoft() ) {
			if ( !exists $uid{ $rec->uid() } ) {
				push @uid_orphan, $key;
			}
			if ( !exists $gid{ $rec->gid() } ) {
				push @gid_orphan, $key;
			}
		}
	}    # foreach

	# display
	_display_group( $backend, 'suid files',            @suid );
	_display_group( $backend, 'sgid files',            @sgid );
	_display_group( $backend, 'group writables files', @gwrite );
	_display_group( $backend, 'world writables files', @world );
	if ( !is_microsoft() ) {
		_display_group( $backend, 'orphan uid', @uid_orphan );
		_display_group( $backend, 'orphan gid', @gid_orphan );
	}

	$backend->close_database($config);
	return;
}
#######################################################
# display an histogram of file sizes
sub stat_size($$$) {
	my $backend      = shift @_;
	my $config       = shift @_;    # Cfg object
	my $date_ref_hum = shift @_;

	init_plugin( $backend, $config, $date_ref_hum, 'stat_size' );

	# analyse datas
	my %size;
	foreach my $key ( $backend->getkeys() ) {
		my $rec   = $backend->get($key);
		my $fmode = $rec->filemode();

		next if ( Afick::Gen::S_ISLNK($fmode) );
		my $size = $rec->filesize();
		my $l = $size ? length $size : 0;
		if ( exists $size{$l} ) {
			$size{$l}++;
		}
		else {
			$size{$l} = 1;
		}
	}

	# results
	Afick::Msg->info('size interval : number of files');
	foreach my $elem ( sort { $a <=> $b } keys %size ) {

		#Afick::Msg->info("size 10**$elem : $size{$elem}");
		if ( $elem == 0 ) {
			Afick::Msg->info("0 :  $size{$elem}");
		}
		else {
			Afick::Msg->info(
				sprintf '%d-%d : %d',
				10**( $elem - 1 ),
				10**($elem) - 1,
				$size{$elem}
			);
		}
	}

	$backend->close_database($config);
	return;
}
#######################################################
# display a list of suffixes ordered by number
# (mainly for windows)
sub stat_ext($$$) {
	my $backend      = shift @_;
	my $config       = shift @_;    # Cfg object
	my $date_ref_hum = shift @_;

	init_plugin( $backend, $config, $date_ref_hum, 'stat_ext' );

	# analyse datas
	my %ext;
	foreach my $key ( $backend->getkeys() ) {

		# search for suffix
		if ( $key =~ m/[.](\w+)$/ ) {
			my $suffix = $1;
			if ( exists $ext{$suffix} ) {
				$ext{$suffix}++;
			}
			else {
				$ext{$suffix} = 1;
			}
		}
	}

	# results
	foreach my $key ( sort { $ext{$a} <=> $ext{$b} } keys %ext ) {
		Afick::Msg->info("$key : $ext{$key} ");
	}

	$backend->close_database($config);
	return;
}
#############################################################
# display a list of files ordered by date change
# will show mtime / ctime /atime
sub stat_date($$$) {
	my $backend      = shift @_;
	my $config       = shift @_;    # Cfg object
	my $date_ref_hum = shift @_;

	init_plugin( $backend, $config, $date_ref_hum, 'stat_date' );

	# analyse datas
	my %dates;
	foreach my $key ( $backend->getkeys() ) {

		my $rec = $backend->get($key);

		# get mtime
		my $mdate = $rec->mtime();
		$dates{"mtime $key"} = $mdate if ($mdate);
		my $cdate = $rec->ctime();
		$dates{"ctime $key"} = $cdate if ($cdate);
		my $adate = $rec->atime();
		$dates{"atime $key"} = $adate if ($adate);
	}

	# results
	foreach my $key ( sort { $dates{$a} <=> $dates{$b} } keys %dates ) {
		my $date  = $dates{$key};
		my $hdate = localtime $date;
		Afick::Msg->info("$date ($hdate) $key");
	}

	$backend->close_database($config);
	return;
}
#######################################################
# export the database in csv format
sub export_csv($$$) {
	my $backend      = shift @_;
	my $config       = shift @_;    # Cfg object
	my $date_ref_hum = shift @_;

	my $configfile = $config->get_configfile();

	# to avoid info lines
	$config->set_directive( 'quiet', 1 );

	init_plugin( $backend, $config, $date_ref_hum, 'export_csv' );

	# titles
	my @titles;
	push @titles, Afick::Object->sort_fields();
	my $comma = Afick::Constant->COMMA;
	my $title = join $comma, map { "\"$_\"" } @titles;
	print "$title\n";

	# data
	foreach my $key ( sort $backend->getkeys() ) {
		my $rec = $backend->get($key);
		my @tab = $rec->to_csv();

		# add quotes and comma
		my $out = join $comma, map { "\"$_\"" } @tab;
		print "$out\n";
	}

	$backend->close_database($config);
	return;
}
#######################################################
# TODO : to be recoded remove get_id / tab2hash
# a sub to return files which match the given filter
# to be used by print_dbm
sub filterdb($$) {
	my $backend = shift @_;
	my $filter  = shift @_;

	my @result;

	#my $rhash;
	my $item;

	# for filter, use the perl cookbook, tips 1.18
	# function alias to access data
	#my @list = keys %{ main::get_id(undef) };
	#push @list, 'name';        # add name
	#push @list, 'filetype';    # add name
	my @list = Afick::Object->fields();

	# avoid warning on second call for redefine functions
	## no critic (TestingAndDebugging);
	no warnings 'redefine';

	# build function on item for filter
	foreach my $id (@list) {
		no strict 'refs';
		## no critic (ProhibitDoubleSigils)
		*$id = sub () { $item->{$id} };
	}
	## use critic

	my $code = 'sub my_filter { ' . $filter . '}';
	## no critic (StringyEval);
	## no critic (ProhibitMismatchedOperators,ProhibitUnlessBlocks)
	unless ( eval $code . 1 ) {
		Afick::Msg->warning("(filterdb) error in filter $filter : $EVAL_ERROR");
	}
	foreach my $key ( sort $backend->getkeys() ) {
		$item = $backend->get($key);

		#$rhash = tab2hash($key);
		if ( my_filter() ) {
			push @result, $key;
		}
	}
	return @result;
}
#######################################################
# print the database content
sub print_dbm($$$;$) {
	my $backend      = shift @_;
	my $config       = shift @_;    # Cfg object
	my $date_ref_hum = shift @_;
	my $filter       = shift @_;    # optionnal filter

	my $configfile = $config->get_configfile();
	init_plugin( $backend, $config, $date_ref_hum, 'print_dbm' );

	# display print format
	my $sep = Afick::Object->sep();
	Afick::Msg->info( 'format : ' . join $sep, Afick::Object->sort_fields() );

	if ($filter) {

		my @res = filterdb( $backend, $filter );
		my $nb = 0;
		foreach my $key (@res) {
			my $rec = $backend->get($key);
			Afick::Msg->report( $rec->display_all(), Afick::Msg->Info );
			$nb++;
		}
		Afick::Msg->info( 'number of file : ' . $nb . " for filter '$filter'" );
	}
	else {

		# ??? change to have same format as other ?
		foreach my $key ( sort $backend->getkeys() ) {
			my $rec = $backend->get($key);
			Afick::Msg->report( $rec->display_all(), Afick::Msg->Info );
		}
		Afick::Msg->info( 'number of file : ' . scalar $backend->getkeys() );
	}
	$backend->close_database($config);
	return;
}
##########################################################################
1;
