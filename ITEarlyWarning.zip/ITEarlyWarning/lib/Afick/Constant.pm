#!/usr/bin/env perl
###############################################################################
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this package contains generic constants
###############################################################################
package Afick::Constant;

use strict;
use warnings;

use English '-no_match_vars';

use base qw(Exporter);
## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );

$VERSION = '1.1';
@EXPORT =
  qw( COMMA EMPTY LF PIPE SPACE TRUE FALSE SLASH STAR PLUS QUOTE DQUOTE NEGSEL EQUSEL MACRO DIREC Strict_perm );

## no critic (ProhibitConstantPragma,RequireInterpolationOfMetachars)
use constant {
	TRUE  => 1,
	FALSE => 0,

	COMMA  => q{,},
	EMPTY  => q{},
	LF     => "\n",
	PIPE   => q{|},
	SPACE  => q{ },
	SLASH  => q{/},
	STAR   => q{*},
	PLUS   => q{+},
	QUOTE  => q{'},
	DQUOTE => q{"},

	# config file grammar elements
	NEGSEL => q{!},
	EQUSEL => q{=},
	MACRO  => q{@@define},
	DIREC  => q{:=},

	Strict_perm => oct 600,
};
## use critic

########################################################
1;
__END__

=head1 NAME

Afick::Constant - generic constants

=head1 USAGE

  use Afick::Constant;

  my $boolean = TRUE;
  my $separator = COMMA;

=head1 DESCRIPTION

defines generic constants for use in all code.

=head1 NOTES

 other way to implement this exists 
 
method 1
  our $TOTO = 'toto';
but this are not really constants

method 2
 a better way will be to use Readonly module
but the Readonly module is not installed by default
and I do not want to add install dependencies 

=head1 OPTIONS

=head1 DIAGNOSTICS

=head1 EXIT STATUS

=head1 REQUIRED ARGUMENTS

=head1 CONFIGURATION

=head1 INCOMPATIBILITIES

=head1 DEPENDENCIES

constant module
The Readonly is probably better but is not 

=head1 BUGS AND LIMITATIONS

barewords don't interpolate (perldoc -m constant).

=head1 SEE ALSO

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2011 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net
