#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classes implements aliases config elements
#
# the list is dynamic : new aliases may be defined in config file
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Aliases;

use strict;
use warnings;

use English qw(-no_match_vars);

use Afick::Constant;
use Afick::Msg;
use Afick::Tst;
use Afick::Gen;

our $VERSION = '1.1';

## no critic (ProhibitMixedCaseVars)
# alias pre-defined values
my %Alias_def = (

	# unitary values
	'a' => 'a',    # atime
	'b' => 'b',    # blocks
	'c' => 'c',    # ctime
	'd' => 'd',    # device
	'g' => 'g',    # gid
	'i' => 'i',    # inode
	'm' => 'm',    # mtime

	#	'h'    => '5',              # md5 hash by default (compatibility)
	'md5'    => '5',    # md5 hash
	'sha1'   => '1',    # sha1
	'sha256' => '6',    # sha-256
	'sha512' => '2',    # sha-512
	'n'      => 'n',    # number of links
	'p'      => 'p',    # permissions
	'u'      => 'u',    # uid
	's'      => 's',    # size

	# real aliases (combined values)
	'all' => 'pdinugsbmc5',    # all except a
	'R'   => 'pdinugsmc5',     # aide compatibility
	'L'   => 'pdinug',         # aide compatibility
	'P'   => 'ugpsn5',
	'E'   => SPACE,            # aide compatibility
);
my %Reverse_aliases_def = reverse %Alias_def;

###############################################################
# constuctor
sub new($) {
	my $classe = shift @_;

	my $self = {};
	bless $self, $classe;
	$self->_init();
	return $self;
}

###############################################################
sub _init($) {
	my $self = shift @_;

	%{ $self->{'aliases'} } = %Alias_def;
	return;
}

###############################################################
# return a hash containing all aliases
sub aliases($) {
	my $self = shift @_;

	# do not return a reference to avoid exterrnal to modify internal data
	return %{ $self->{'aliases'} };
}
###############################################################
# populate an object from an hash get from aliases method
# rem : used in afickonfig
sub populate($$) {
	my $self     = shift @_;
	my $rh_alias = shift @_;

	foreach my $key ( keys %{$rh_alias} ) {
		next if ( $self->is_def_alias($key) );
		$self->set_alias( $key, $self->decode_alias( $rh_alias->{$key}, 1 ) );
	}

	return;
}
###############################################################
# return true if the given key is a default alias
sub is_def_alias($$) {
	my $self = shift @_;
	my $key  = shift @_;

	return ( exists $Alias_def{$key} );
}
###############################################################
# return true if the given key is an existing alias
sub is_alias($$) {
	my $self = shift @_;
	my $key  = shift @_;

	return ( exists $self->{'aliases'}{$key} );
}
###############################################################
# return the value of the given alias key
sub get_alias($$) {
	my $self = shift @_;
	my $key  = shift @_;

	if ( $self->is_alias($key) ) {
		return $self->{'aliases'}{$key};
	}
	else {
		return;
	}
}
###############################################################
# delete aliases is possible :
# - on not default alias
# - if allow_undef is true
# - if data is empty
sub set_alias($$$;$) {
	my $self        = shift @_;
	my $key         = shift @_;
	my $data        = shift @_;
	my $allow_undef = shift @_ || 0;    # if true, allow to delete an alias

	if ( $self->is_def_alias($key) ) {

		# nothing is allowed on default alias
		Afick::Msg->warning("can not modify default alias $key");
		return 0;
	}
	elsif ( is_noval($data) ) {

		# delete data
		if ( $self->check_alias( $data, $allow_undef ) ) {

			# allowed
			if ( $self->is_alias($key) ) {
				delete $self->{'aliases'}{$key};
				Afick::Msg->debug( "delete alias $key", D3 );
				return 1;
			}
			else {
				Afick::Msg->warning("can not delete unknown $key alias");
				return 0;
			}
		}
		else {

			# we do not allow alias change : allow_undef must be enabled
			Afick::Msg->warning("can not delete $key alias (not allowed)");
			return 0;
		}
	}
	elsif ( my $ret = $self->check_alias($data) ) {

		# we will use ret instead data, because of binary values
		# we allow 'yes' in file, but the internal value is 1 for example
		$self->{'aliases'}{$key} = $ret;
		Afick::Msg->debug( "set alias $key to $ret", D3 );
		return 1;
	}
	else {

		# not a valid data
		Afick::Msg->warning( "$data is not a valid value for an alias : "
			  . Afick::Msg->get_error() );
		return 0;
	}
}
###############################################################
# test if a valid attribute
# return decoded value (alias -> attributes) or undef
sub _test_alias_attribute($$) {
	my $self = shift @_;
	my $val  = shift @_;

	return (
		exists( $self->{'aliases'}{$val} )
		? $self->{'aliases'}{$val}
		: undef
	);
}
##########################################################################
# apply an attribute on chain
sub _apply_alias_attribute($$$$) {
	my $self      = shift @_;
	my $begin     = shift @_;    # begin of resolved chain
	my $op        = shift @_;    # operator
	my $attribute = shift @_;    # attribute to add/subtract

	if ( $op eq q{+} ) {

		# test duplicate
		if ( $begin =~ m/$attribute/ ) {

			# error (duplicate) , could also skip this attribute
			Afick::Msg->set_error("found duplicate $attribute ($begin)");
			return;
		}
		else {

			# ok : u+p -> up
			$begin .= $attribute;
		}
	}
	else {

		# negative operator
		if ( $begin =~ s/$attribute// ) {

			# ok : we remove it
		}
		else {
			Afick::Msg->set_error("can not remove $attribute from $begin");
			return;
		}
	}
	return $begin;
}
##########################################################################
# can keep only one sha checksum,
# try to keep the most secure one available
sub _check_checksum($$) {
	my $self = shift @_;
	my $real = shift @_;

	# sha-512
	if ( $real =~ m/2/ ) {
		if ( is_sha512() ) {

			# keep it, remove others sha
			$real =~ s/6//;
			$real =~ s/1//;
			return $real;
		}
		else {

			# sha-512 not available, try sha-256
			$real =~ s/2/6/;
			Afick::Msg->warning(
				"sha-512 checksum not available on $real : replaced by sha-256"
			);
		}
	}

	# sha-256
	if ( $real =~ m/6/ ) {
		if ( is_sha256() ) {

			# keep it, remove others sha
			$real =~ s/1//;
			return $real;
		}
		else {

			# sha-256 not available, try sha-1
			$real =~ s/6/1/;
			Afick::Msg->warning(
				"sha-256 checksum not available on $real : replaced by sha-1");
		}
	}

	# sha-1
	if ( $real =~ m/1/ ) {
		if ( is_sha1() ) {

			# available : keep it
			return $real;
		}
		elsif ( $real =~ m/5/ ) {

			# sha1 not available, remove it
			$real =~ s/1//;
			Afick::Msg->warning(
				"sha1 checksum not available on $real : removed");
		}
		else {

			# sha1 not available, replaced by md5
			$real =~ s/1/5/;
			Afick::Msg->warning(
				"sha1 checksum not available on $real : replaced by md5");
		}
	}

	return $real;
}
##########################################################################
# check alias syntaxe
# can resolv in base attribute if resolv is 1
# else just check operator syntaxe
# the problem is with afickonfig : when checking arg, we do not know all
# alias defined in config file
#
# warning : this version stop at first error
#   and do not try to skip bad elements
sub check_alias($$;$) {
	my $self        = shift @_;
	my $var         = shift @_;  # alias to be resolved, ex 'u+g+n+p', 'all - m'
	my $allow_undef = shift @_;

	if ( is_noval($var) ) {
		if ($allow_undef) {
			return 1;
		}
		else {
			Afick::Msg->set_error('missing alias value');
			return;
		}
	}

	remove_all_spaces( \$var );

	my @tab = split /\b/, $var;

	# first attribute
	my $first = shift @tab;

	# test resolution
	my $masq = $self->_test_alias_attribute($first);
	if ( !defined $masq ) {
		Afick::Msg->set_error("$first is not a valid attribute");
		return;
	}

	while ( my $op = shift @tab ) {

		if ( is_op($op) ) {
			my $next = shift @tab;
			if ( !defined $next ) {
				Afick::Msg->set_error('missing last attribute');
				return;
			}
			my $next2 = $self->_test_alias_attribute($next);
			if ( defined $next2 ) {
				$masq = $self->_apply_alias_attribute( $masq, $op, $next2 );
				return if ( !defined $masq );
			}
			else {
				Afick::Msg->set_error("$next is not a valid attribute");
				return;
			}
		}
		else {
			Afick::Msg->set_error("$op should be the operator + or -");
			return;
		}
	}

	# test for checksum :
	$masq = $self->_check_checksum($masq);

	Afick::Msg->debug( "(check_alias) $var -> $masq", D4 );
	return $masq;
}
################################################################
# revert an internal masq to a config syntaxe as unitary elements
# ex : all ->  p+d+i+n+u+g+s+b+m+c+md5
sub _decode_alias_unit($$) {
	my $self = shift @_;
	my $masq = shift @_ || q{};

	# problem : convert 5 to md5 :
	# - split line in tab
	# - map to reverse aliases
	# - concatenete with +
	## no critic (ProhibitStringySplit)
	return join q{+}, map { $Reverse_aliases_def{$_} } split q{}, $masq;
}
################################################################
# revert an internal masq to a config syntaxe
# ps : we do not test if the internal masq is valid or not
sub decode_alias($$;$) {
	my $self         = shift @_;
	my $masq         = shift @_;
	my $flag_unitary = shift @_ || 0;

	if ($flag_unitary) {
		return $self->_decode_alias_unit($masq);
	}
	else {

		# just to avoid compute the reverse on each call
		my %reverse_aliases = reverse %{ $self->{'aliases'} };

		if ( exists $reverse_aliases{$masq} ) {

			# pre-defined alias (ex : all)
			return $reverse_aliases{$masq};
		}
		else {

			# custom alias
			return $self->_decode_alias_unit($masq);
		}
	}
}
################################################################
# print aliases in info mode (all or just modified alias)
# with config syntaxe
sub print_aliases($$) {
	my $self = shift @_;
	my $all  = shift
	  @_;  # if true print all aliases, else only not default (so added aliases)

	foreach my $key ( sort keys %{ $self->{'aliases'} } ) {
		if ( ($all) || ( !$self->is_def_alias($key) ) ) {

			Afick::Msg->info(
				"$key=" . $self->decode_alias( $self->{'aliases'}{$key}, 1 ) );
		}
	}
	return;
}
###############################################################
1;
