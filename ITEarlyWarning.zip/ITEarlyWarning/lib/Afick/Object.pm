#!/usr/bin/perl -w 
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classes implements data and methods about a file
# as seen for afick
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Object;

use strict;
use warnings;

use English qw(-no_match_vars);

use Afick::Gen;    # file_type_h get_time
use Afick::Tst;    # is_acl
use Afick::Msg;

our ($VERSION);
$VERSION = '0.1';

# database internal separator
# for join
## no critic(ProhibitConstantPragma)
use constant Sep => q{|};
## use critic

# for split
my $Sepmeta = quotemeta Sep;

# value give the order for display
my %Fields = (
	'filetype' => 0,     # computed file type
	'name'     => 1,     # file name
	'md5'      => 2,     # md5 checksum
	'device'   => 3,     # device ident
	'inode'    => 4,     # inode number
	'filemode' => 5,     # file mode  (type and permissions)
	'links'    => 6,     # number of links
	'uid'      => 7,     # numeric user ID of file's owner
	'gid'      => 8,     # numeric group ID of file's owner
	'filesize' => 9,     # file size in bytes
	'blocs'    => 10,    # actual number of system-specific blocks allocated
	'atime'    => 11,    # last access time in seconds since the epoch
	'mtime'    => 12,    # last modify time in seconds since the epoch
	'ctime'    => 13,    # inode change time in seconds since the epoch
	'sha'      => 14,    # sha checksum
	'acl'      => 15,    # acl
);

my $Utc_time = 0;        # store flag on class data

###############################################################
# constuctor
sub new($) {
	my $classe = shift @_;

	my $self = {};
	bless $self, $classe;
	$self->_init();
	return $self;
}

###############################################################
# initialize all fields
sub _init($) {
	my $self = shift @_;

	foreach my $field ( $self->fields() ) {
		$self->$field(0);
	}
	return;
}
###############################################################
# to be used as class method
sub set_utc_time($$) {
	my $self     = shift @_;
	my $utc_time = shift @_;    # a binary value

	$Utc_time = $utc_time;

	return;
}
###############################################################
sub get_utc_time($) {
	my $self = shift @_;

	return $Utc_time;
}
###############################################################
# build accessors (cf design patterns)
## no critic (ProhibitNoStrict)
no strict 'refs';
foreach my $field ( keys %Fields ) {
	*{$field} = sub : lvalue {
		my $self = shift @_;

		if (@_) {
			$self->{$field} = shift @_;    # set
			return;
		}
		else {
			return $self->{$field};        # get
		}
	};
}
use strict 'refs';
###############################################################
# return list of internal fields names
# no order
sub fields($) {
	my $self = shift @_;

	return keys %Fields;
}
###############################################################
# return the the list of internal fields sorted
sub sort_fields($) {
	my $self = shift @_;

	my @list = sort { $Fields{$a} <=> $Fields{$b} } keys %Fields;
	return @list;
}
###############################################################
# old database separator
sub sep($) {
	return Sep;
}
###############################################################
# get file_type from database
sub file_type ($) {
	my $self = shift @_;

	my $mode = $self->filemode();
	return file_type_h($mode);
}
###############################################################
#sub is_lnk($) {
#	my $self = shift @_;
#
#	return Afick::Gen::S_ISLNK( $self->filemode() );
#}
###############################################################
# old internal data flat storage format :
#   0          1       2      3       4      5    6
# $md5_sum, $device, $inode, $mode, $link, $uid, $gid,
#  7       8      9       10      11       12
# $size, $bloc, $atime, $mtime, $ctime, $sha1_sum, 0;
#
# fill data from database old flat storage format
# (read old database record : Afick::Backend->get)
sub from_oldflat($$$) {
	my $self = shift @_;
	my $key  = shift @_;    # file name
	my $dat  = shift @_;    # old flat storage format

	# clear data
	$self->_init();

	my $sep = $self->sep();
	Afick::Msg->warning("empty data for $key") if ( !$dat );
	Afick::Msg->warning("bad format for $key : $dat")
	  unless ( $dat =~ m/$sep/ );

	my @data = split /$Sepmeta/, $dat;

	$self->md5( $data[0] );
	$self->device( $data[1] );
	$self->inode( $data[2] );
	$self->filemode( $data[3] );
	$self->links( $data[4] );
	$self->uid( $data[5] );
	$self->gid( $data[6] );
	$self->filesize( $data[7] );
	$self->blocs( $data[8] );
	$self->atime( $data[9] );
	$self->mtime( $data[10] );
	$self->ctime( $data[11] );
	$self->sha( $data[12] );

	$self->filetype( $self->file_type() );
	$self->name($key);
	return;
}

# --------------------------------------------------
# export data to old flat format
sub to_oldflat() {
	my $self = shift @_;

	my @tab = (
		$self->md5(),   $self->device(), $self->inode(), $self->filemode(),
		$self->links(), $self->uid(),    $self->gid(),   $self->filesize(),
		$self->blocs(), $self->atime(),  $self->mtime(), $self->ctime(),
		$self->sha(),   0,
	);
	return join Sep, @tab;
}

###############################################################
# initialise from a hash (file_info sub)
sub from_hash($$$) {
	my $self = shift @_;
	my $r_h  = shift @_;

	# clear data
	$self->_init();

	foreach my $key ( keys %{$r_h} ) {
		if ( exists $Fields{$key} ) {

			$self->$key( $r_h->{$key} );
		}
		else {
			Afick::Msg->warning("unknown key $key");
		}
	}

	$self->filetype( $self->file_type() );
	return;
}

# ----------------------------------------------------------
# return a hash
sub to_hash($) {
	my $self = shift @_;

	my %h;
	foreach my $field ( $self->fields() ) {
		$h{$field} = $self->{$field};
	}
	return %h;
}

# return a sorted array
# of data in human format
sub to_csv($) {
	my $self = shift @_;

	my @tab;
	foreach my $field ( $self->sort_fields() ) {
		push @tab, $self->display($field);
	}
	return @tab;
}

###############################################################
# print all fields as raw data
sub debug($) {
	my $self = shift @_;

	foreach my $field ( $self->fields() ) {
		print "$field = " . $self->$field() . "\n";
	}
	return;
}
###############################################################
# convert a field from database in a human way
sub display($$) {
	my $self = shift @_;
	my $elem = shift @_;    # field id

	## no critic (ProhibitCascadingIfElse)
	if ( $elem eq 'device' ) {

		# device is in hexa, ex 309 == major 3, minor 9 == /dev/hda9
		return sprintf '%lx', $self->device();
	}
	elsif ( $elem eq 'filemode' ) {

		# perm is in octal
		return print_oct( $self->filemode() );
	}

	elsif ( ( $elem eq 'acl' ) and is_acl() ) {

		# gid on windows are acl
		## no critic (ProhibitNoisyQuotes)
		return join ';', Afick::WinAcl::split_acl( $self->acl() );
	}
	elsif ( $elem eq 'md5' ) {
		return print_digest( $self->md5() );
	}
	elsif ( $elem eq 'sha' ) {
		return print_digest( $self->sha() );
	}
	elsif (( $elem eq 'atime' )
		or ( $elem eq 'mtime' )
		or ( $elem eq 'ctime' ) )
	{

		# dates
		if ( $self->$elem() ) {
			my $date = get_time( $self->$elem(), $self->get_utc_time() );
			return $date;
		}
		else {
			return 0;
		}
	}
	else {
		return $self->$elem();
	}
	## use critic
}
#######################################################
# display_all
# convert in a human way all the record
# looks like internal storage
sub display_all($) {
	my $self = shift @_;

	my $output = join Sep, $self->to_csv();

	return $output;
}
#######################################################
1;
