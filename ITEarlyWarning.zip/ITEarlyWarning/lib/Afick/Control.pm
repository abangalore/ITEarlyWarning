#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classe is designed to read/write database ctr file
# - the ctr file is written after closing database
# - the ctr file is read after configuration load, before database open
#   and check is done
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Control;

use strict;
use warnings;

use English qw(-no_match_vars);

#use Data::Dumper;

use Afick::Backend;
use Afick::Msg;
use Afick::Gen;    # md5sum
use Afick::Constant;

use base qw(Exporter);
## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );
$VERSION = '1.0';

## no critic (ProhibitConstantPragma)
use constant Control_ext => '.ctr';    # database control file

###############################################################
# constuctor
sub new($$) {
	my $classe   = shift @_;
	my $database = shift @_;           # database file name

	my $self = {};
	bless $self, $classe;
	$self->_init($database);
	return $self;
}

###############################################################
sub _init($) {
	my $self     = shift @_;
	my $database = shift @_;

	$self->{'database'} = $database;
	$self->{'control'}  = $database . Control_ext;
	return;
}
########################################################
# return control file name
sub get_ctr($) {
	my $self = shift @_;

	return $self->{'control'};
}
###############################################################
# return true if control file exists and is not empty
sub exists_ctr() {
	my $self = shift @_;

	return ( -s $self->get_ctr() );
}
###############################################################
# create control file if not exist and restrict access
sub strict_ctr() {
	my $self = shift @_;

	if ( !$self->exists_ctr() ) {
		touch( $self->get_ctr() );
	}
	chmod Afick::Constant->Strict_perm, $self->get_ctr();
	return;
}
###############################################################
# read control file
sub read_control($) {
	my $self = shift @_;

	my $control_file = $self->get_ctr();
	my ( $oldchecksum, $old_version, $run_date, $dbm );
	## no critic (RequireBriefOpen)
	if ( open my $fh_control, '<', $control_file ) {

		my $line1 = <$fh_control>;
		if ( $line1 =~ m/#format=/ ) {

			# new format

			# read
			my @ctr_data = <$fh_control>;
			chomp @ctr_data;

			my %old_directives;

			# analyse
			foreach my $elem (@ctr_data) {
				## no critic (ProhibitCascadingIfElse)
				if ( $elem =~ m/#checksum=(.*)/ ) {
					$oldchecksum = $1;
				}
				elsif ( $elem =~ m/#version=(.*)/ ) {
					$old_version = $1;
				}
				elsif ( $elem =~ m/#date=(.*)/ ) {
					$run_date = $1;
				}
				elsif ( $elem =~ m/#database_type=(.*)/ ) {
					$dbm = $1;
				}
				elsif ( $elem =~ m/(.*):=(.*)/ ) {

					# this is a directive
					#Afick::Msg->debug("read ctr $1 : $2", 4);
					$old_directives{$1} = $2;
				}
				else {
					Afick::Msg->warning(
						"(control) bad line $elem in control file $control_file"
					);
				}
			}
			%{ $self->{'old_directives'} } = %old_directives;
		}
		else {

			# old format
			$oldchecksum = $line1;
			chomp $oldchecksum;
			$old_version = <$fh_control>;
			chomp $old_version if ( defined $old_version );
			$run_date = <$fh_control>;
			chomp $run_date if ( defined $run_date );
			$dbm = 'SDBM_File';    # default

			Afick::Msg->warning(
				"(control) your control file $control_file is in old format");
		}
		close $fh_control
		  or Afick::Msg->warning(
			"(control) can not close control file $control_file : $ERRNO");

		$self->{'oldchecksum'} = $oldchecksum;
		$self->{'old_version'} = $old_version;
		$self->{'run_date'}    = $run_date;
		$self->{'dbm'}         = $dbm;

		return 1;    # ok
	}
	else {
		Afick::Msg->warning(
			"(control) can not read control file $control_file : $ERRNO");
		return 0;
	}
}
########################################################
sub get_dbm() {
	my $self = shift @_;

	return $self->{'dbm'};
}
########################################################
sub get_run_date() {
	my $self = shift @_;

	return $self->{'run_date'};
}
########################################################
sub get_old_version() {
	my $self = shift @_;

	return $self->{'old_version'};
}
########################################################
# some directives to be filtered
sub filter_directives($$) {
	my $self          = shift @_;
	my $rh_directives = shift @_;

	# not meaningfull
	delete $rh_directives->{'debug'};
	delete $rh_directives->{'verbose'};

	# to fix bug with release < 3.5.2
	$rh_directives->{'exclude_re'} =~ s/^\s+//;
	$rh_directives->{'exclude_suffix'} =~ s/^\s+//;
	$rh_directives->{'exclude_prefix'} =~ s/^\s+//;

	return;
}
########################################################
# check database integrity from control file info
sub check_control($$$) {
	my $self             = shift @_;
	my $backend          = shift @_;
	my $rh_newdirectives = shift @_;

	my $dbm = $self->get_dbm();
	$backend->test_dbm($dbm);
	$backend->set_database( $self->{'database'} );

	# check if database exists
	my $fulldatabase = $backend->get_database_fullname();
	if ( $backend->exists_database() ) {
		Afick::Msg->debug( "(check_control) database $fulldatabase exists",
			D4 );
	}
	else {
		Afick::Msg->my_die("can not find database : $fulldatabase");
	}

	# database checksum control
	my $newchecksum = md5sum( $fulldatabase, 0, 0, );
	if ( $self->{'oldchecksum'} ne $newchecksum ) {
		Afick::Msg->my_die(
			"(check_control) internal change in afick database $fulldatabase (bad checksum)");
	}
	else {
		Afick::Msg->debug(
			"(check_control) checksum on database $fulldatabase ok", D4 );
	}

	# directives control
	$self->filter_directives($rh_newdirectives);
	if ( exists $self->{'old_directives'} ) {
		my %old_directives = %{ $self->{'old_directives'} }; # from read_control
		$self->filter_directives( \%old_directives );

		#print Dumper(\%old_directives);
		#print Dumper($rh_newdirectives);

		diff_hash( \%old_directives, $rh_newdirectives,
			'(control) directives' );
	}

	# date control ?
	# warning if last run is too late ?
	# compute difference between @Date and $run_date
	return;
}
#######################################################
# write database checksum for next run
sub write_control ($$$$$$) {
	my $self             = shift @_;
	my $checksum         = shift @_;    # database checksum
	my $version          = shift @_;    # afick version
	my $date             = shift @_;    # date of run
	my $dbm              = shift @_;    # database type (Storable, GDBM ...)
	my $rh_newdirectives = shift @_;    # directives

	my $control_file = $self->get_ctr();

	if ( open my $fh_control, '>', $control_file ) {

		#old format
		#print $fh_control "$checksum". LF;               # database checksum
		#print $fh_control "$Version" .LF;                # afick version
		#print $fh_control strftime( $Datefmt, @Date ) . LF;    # date of run

		# new format
		print {$fh_control} '#format=2' . Afick::Constant->LF;
		print {$fh_control} "#checksum=$checksum"
		  . Afick::Constant->LF;    # database checksum
		print {$fh_control} "#version=$version"
		  . Afick::Constant->LF;    # afick version
		print {$fh_control} "#date=$date" . Afick::Constant->LF;   # date of run
		print {$fh_control} '#database_type=' . $dbm
		  . Afick::Constant->LF;    # database type

		# directives
		$self->filter_directives($rh_newdirectives);
		foreach my $dir ( sort keys %{$rh_newdirectives} ) {
			print {$fh_control} "$dir:=$rh_newdirectives->{$dir}\n";
		}

		close $fh_control
		  or Afick::Msg->warning(
"(write_control) can not close in control file $control_file : $ERRNO"
		  );

		# restrict permissions
		$self->strict_ctr();
	}
	else {
		Afick::Msg->warning(
"(write_control) can not write in control file $control_file : $ERRNO"
		);
	}
	return;
}
#######################################################
1;
