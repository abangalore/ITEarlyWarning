#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classe implements Directives configuration
# directives elements will change core afick behavior
#
# the list is static,
# but may be set
# - from configuration file
# - from command line options
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Directives;

use strict;
use warnings;

use English qw(-no_match_vars);

use Afick::Constant;
use Afick::Msg;
use Afick::Tst;
use Afick::Gen;

our $VERSION = '1.6';

# default values for directives
# warning : any change in list should also change %ck_directive below
my %Directives_def = (
	'allow_overload'     => 1,        # allow rules overload
	'allow_relativepath' => 0,        # allow relative path for afick
	'archive'            => EMPTY,    # path to archive directory
	'database'           => EMPTY,    # path to database name
	'debug'              => 0,        # debuging level from 0 (none) to 4 (full)
	'exclude_prefix'     => EMPTY,    # list of prefix to exclude
	'exclude_suffix'     => EMPTY,    # list of suffix to exclude
	'exclude_re'         => EMPTY,    # list of regular expression to exclude
	'follow_symlinks'    => 0,        # do checksum on link or on name
	'history'            => EMPTY,    # path to history file
	'ignore_case'        => 0,        # ignore filename case ?
	'max_checksum_size'  => 0,        # max file size for a complete checksum
	'only_suffix'        => EMPTY,    # list of file suffix to only search for
	'report_full_newdel' => 0,        # report new and del directories contents
	'report_context'     => 0,        # report context attribute (not in masq)
	'report_url'         => 'STDOUT', # output device
	'report_summary'     => 1,        # report summary of changes
	'report_syslog'      => 0,        # report to syslog or not
	'running_files'      => 0,        # show changed files during scan
	'quiet'              => 0,        # quiet mode
	'timing'             => 0,        # show cpu statistics
	'utc_time'           => 0,    # display dates in utc (else in local time)
	'verbose'            => 0,    # an alias for debug = 4 (deprecated)
	'warn_dead_symlinks' => 0,    # warn about dead symlink
	'warn_missing_file' =>
	  0,    # report about files in configuration file, but not installed
);

my $Sep_exclude_re = q{;};     # separator for exclude_re
my $Sep_exclude    = SPACE;    # separator for all other exclude_*

###############################################################
# constuctor
sub new($) {
	my $classe = shift @_;

	my $self = {};
	bless $self, $classe;
	$self->_init();
	return $self;
}

###############################################################
# initialize attributes
sub _init($) {
	my $self = shift @_;

	# directives
	%{ $self->{'directives'} } = %Directives_def;

	# keep track if set or not
	%{ $self->{'initialized'} } = ();
	return;
}
###############################################################
# return a hash containing all directives
sub directives($) {
	my $self = shift @_;

	# do not return a reference to avoid external to modify internal data
	return %{ $self->{'directives'} };
}
###############################################################
# return true if the given key is a valid directive
sub is_directive($$) {
	my $self = shift @_;
	my $key  = shift @_;

	return ( exists $Directives_def{$key} );
}
###############################################################
# reset given directive key to default value
sub reset_directive($$) {
	my $self = shift @_;
	my $key  = shift @_;

	if ( $self->is_directive($key) ) {

		# do not use set_directive to avoid all tests
		$self->_set_directive( $key, $Directives_def{$key}, 0 );
		return 1;
	}
	else {
		return 0;
	}
}
###############################################################
# return true if the given directive key contains a default value
# ps : we do not test if key is a directive
sub is_def_directive($$) {
	my $self = shift @_;
	my $key  = shift @_;

	return ( $self->{'directives'}{$key} eq $Directives_def{$key} );
}
###############################################################
# return the value of the given directive key
sub get_directive($$) {
	my $self = shift @_;
	my $key  = shift @_;

	if ( $self->is_directive($key) ) {
		return $self->{'directives'}{$key};
	}
	else {
		return;
	}
}
###############################################################
# ref to control functions
my %ck_directive = (
	ignore_case        => \&is_binary,
	report_full_newdel => \&is_binary,
	running_files      => \&is_binary,
	timing             => \&is_binary,
	verbose            => \&is_binary,
	warn_dead_symlinks => \&is_binary,
	warn_missing_file  => \&is_binary,
	follow_symlinks    => \&is_binary,
	allow_overload     => \&is_binary,
	allow_relativepath => \&is_binary,
	quiet              => \&is_binary,
	report_summary     => \&is_binary,
	report_context     => \&is_binary,
	utc_time           => \&is_binary,

	max_checksum_size => \&is_posint,

	archive => \&check_directory,
	history => \&check_plainfile,

	debug         => \&is_debug_level,
	report_url    => \&is_url,
	report_syslog => \&is_binary,
	database      => \&is_bidon,

	exclude_suffix => \&is_bidon,
	exclude_prefix => \&is_bidon,
	exclude_re     => \&is_bidon,
	only_suffix    => \&is_bidon,
);

# to be called by test_macros to check this hash key match %Directives_def keys
## no critic (ProhibitUnusedPrivateSubroutines)
sub _check_hash() {
	return compare_hashkey( \%ck_directive, \%Directives_def );
}
###############################################################
# check if the data is valid for the given directive key
sub check_directive($$$$) {
	my $self        = shift @_;
	my $key         = shift @_;
	my $data        = shift @_;
	my $allow_undef = shift @_;

	if ( exists $ck_directive{$key} ) {
		if ( is_noval($data) ) {

			# special case for afickonfig to delete values
			if ($allow_undef) {
				return 1;
			}
			else {
				Afick::Msg->set_error('missing directive value');
				return;
			}
		}
		else {
			return &{ $ck_directive{$key} }($data);
		}
	}
	else {
		Afick::Msg->set_error("$key is not a directive keyword");
		return;
	}

}
###############################################################
# test directive key and configure Afick::Msg
sub _maj_msg($$$) {
	my $self = shift @_;
	my $key  = shift @_;
	my $data = shift @_;

	my %h_msg = (
		'debug'         => \&Afick::Msg::set_msg_level,
		'verbose'       => \&Afick::Msg::set_verbose,
		'quiet'         => \&Afick::Msg::set_quiet,
		'report_syslog' => \&Afick::Msg::set_syslog,
		'report_url'    => \&Afick::Msg::set_report_url,
	);

	if ( exists $h_msg{$key} ) {

		# cf perlmonks 62737
		Afick::Msg->debug( "(_maj_msg) set $key to $data", D3 );
		my $ref = $h_msg{$key};

		# call class method, not instance method
		# my $instance = Afick::Msg->new();
		my $instance = 'Afick::Msg';
		$ref->( $instance, $data );
		return 1;
	}
	else {
		return 0;
	}
}
###############################################################
# internal low_level sub
# called by set_directives, reset_directives
sub _set_directive($$$$) {
	my $self   = shift @_;
	my $key    = shift @_;
	my $val    = shift @_;
	my $setdir = shift @_;    # true from set_directives

	$self->_maj_msg( $key, $val );
	$self->{'directives'}{$key} = $val;
	if ($setdir) {

		# set_directives
		$self->{'initialized'}{$key} = 1;
	}
	elsif ( $self->is_initialized($key) ) {

		# reset_directives
		delete $self->{'initialized'}{$key};
	}
	else {
		# should never append
		Afick::Msg->debug( "(_set_directive) bad key $key", D3 );
		return 0;
	}

	return 1;
}
###############################################################
# return true if the key is already initialized
# is used to avoid overload command line config by config file
sub is_initialized($$) {
	my $self = shift @_;
	my $key  = shift @_;

	return exists $self->{'initialized'}{$key};
}
###############################################################
# change directive key to data
sub set_directive($$$) {
	my $self = shift @_;
	my $key  = shift @_;
	my $data = shift @_;

	Afick::Msg->debug( "(set_directive) key $key value $data", D4 );

	if ( $self->is_directive($key) ) {
		my $ret = $self->check_directive( $key, $data, 0 );
		if ( defined $ret ) {

			# we will use ret instead data, because of binary values
			# we allow 'yes' in file, but the internal value is 1 for example
			if ( $key =~ m/^exclude_re/ ) {
				if ( $self->{'directives'}{$key} ) {
					$self->{'directives'}{$key} .= $Sep_exclude_re . $ret;
				}
				else {
					# first
					$self->{'directives'}{$key} = $ret;
				}
			}
			elsif ( $key =~ m/^exclude/ ) {
				if ( $self->{'directives'}{$key} ) {
					$self->{'directives'}{$key} .= $Sep_exclude . $ret;
				}
				else {
					# first
					$self->{'directives'}{$key} = $ret;
				}
			}
			elsif ( $self->is_initialized($key) ) {

				# already initialized directive
				Afick::Msg->debug("already initialized directive $key");
				return 0;
			}
			else {
				$self->_set_directive( $key, $ret, 1 );
			}
			return 1;
		}
		else {

			# not a valid data
			Afick::Msg->warning(
				"$data is not a valid value for $key directive : "
				  . Afick::Msg->get_error() );
			return 0;
		}
	}
	else {

		# not a valid directive
		Afick::Msg->warning("$key is not a valid directive");
		return 0;
	}
}
################################################################
# print directives in info mode (all or just modified directives)
# with config syntaxe
sub print_directives($$) {
	my $self = shift @_;
	my $all  = shift @_;    # if true print all directive, else only not default

	foreach my $key ( sort keys %Directives_def ) {
		if ( ($all) || ( !$self->is_def_directive($key) ) ) {
			Afick::Msg->info(
				$key . Afick::Constant->DIREC . $self->{'directives'}{$key} );
		}
	}
	return;
}
################################################################
# to allow overload of directives by command line arguments
# if using same key names
# key which are not directives are silently ignored
sub overload_directives($$) {
	my $self   = shift @_;
	my $rh_opt = shift @_;    # hash key -> data

	foreach my $key ( keys %{$rh_opt} ) {
		if ( $self->is_directive($key) ) {
			$self->set_directive( $key, $rh_opt->{$key} );
		}
	}
	return;
}
###############################################################
# check consistency between directives
sub check_consistency($) {
	my $self = shift @_;

	my $nb_pbs = 0;

	# ignore_case
	if ( ( !is_microsoft() ) and ( $self->get_directive('ignore_case') ) ) {
		Afick::Msg->warning('ignore_case is dangerous');
		$nb_pbs++;
	}

	# report media
	if (    ( $self->get_directive('report_url') eq 'NULL' )
		and ( !$self->get_directive('report_syslog') ) )
	{
		# use Afick::Msg->warning will be unuseful
		warn "no report media, check report_url and report_syslog directives\n";
		$nb_pbs++;
	}

	return $nb_pbs;
}
###############################################################
# to allow overload of directives by command line arguments
# with a translation table for keys
# key which are not directives are silently ignored
# translation table just need to contain translation keys
# ex : dead_symlinks as command line, warn_dead_symlinks here as internal
#sub overload_directives_trans($$$) {
#	my $self    = shift @_;
#	my $r_opt   = shift @_;    # hash key -> data
#	my $r_trans = shift @_;    # translation hash
#
#	foreach my $key ( keys %{$r_opt} ) {
#		if ( $self->is_directive($key) ) {
#			$self->set_directive( $key, $r_opt->{$key} );
#		}
#		elsif ( exists $r_trans->{$key} ) {
#			$self->set_directive( $r_trans->{$key}, $r_opt->{$key} );
#		}
#	}
#	return;
#}
###############################################################
# patterns
################################################################
sub _make_regex($$$$;$) {
	my $self         = shift @_;
	my $config       = shift @_;
	my $prefix_regex = shift @_;
	my $suffix_regex = shift @_;
	my $separator    = shift @_ || SPACE;

	my @tab = split $separator, $config;
	if (@tab) {
		return $prefix_regex . join( PIPE, map { "$_" } @tab ) . $suffix_regex;
	}
	else {
		return EMPTY;
	}
}
#######################################################
sub make_patterns($) {
	my $self = shift @_;

	my $onlySufx = $self->get_directive('only_suffix');
	my $onlySufxPat;
	if ($onlySufx) {
		$onlySufxPat =
		  $self->_make_regex( $onlySufx, '\.(', ')$', $Sep_exclude );
		Afick::Msg->debug( "OnlySufx=$onlySufx SufxPat=$onlySufxPat", D2 );
	}
	else {
		$onlySufxPat = EMPTY;
	}
	$self->{'onlySufxPat'} = $onlySufxPat;

	# compute patterns for exclude
	# suffix
	my $sufx = $self->get_directive('exclude_suffix');
	my $sufxPat;
	if ($sufx) {
		$sufxPat = $self->_make_regex( $sufx, '\.(', ')$', $Sep_exclude );
		Afick::Msg->debug( "Sufx=$sufx SufxPat=$sufxPat", D2 );
	}
	else {
		$sufxPat = EMPTY;
	}
	$self->{'sufxPat'}         = $sufxPat;
	$self->{'nb_exclude_sufx'} = 0;

	# prefix
	my $prefx = $self->get_directive('exclude_prefix');
	my $prefxPat;
	if ($prefx) {
		$prefxPat = $self->_make_regex( $prefx, '^(', ')', $Sep_exclude );
		Afick::Msg->debug( "Prefx=$prefx PrefxPat=$prefxPat", D2 );
	}
	else {
		$prefxPat = EMPTY;
	}
	$self->{'prefxPat'}         = $prefxPat;
	$self->{'nb_exclude_prefx'} = 0;

	# general regex
	my $exclude_re = $self->get_directive('exclude_re');
	my $exRePat;
	if ($exclude_re) {
		$exRePat = $self->_make_regex( $exclude_re, '(', ')', $Sep_exclude_re );
		Afick::Msg->debug( "Exclude_re=$exclude_re ExRePat=$exRePat", D2 );
	}
	else {
		$exRePat = EMPTY;
	}
	$self->{'exRePat'}       = $exRePat;
	$self->{'nb_exclude_re'} = 0;
	return;
}
################################################################
sub test_only_suffix($$) {
	my $self = shift @_;
	my $fic  = shift @_;

	my $onlySufxPat = $self->{'onlySufxPat'};
	if ( -d $fic ) {

		# we have to recurse on directories
		return 1;
	}
	elsif ( ($onlySufxPat) and ( $fic =~ m/$onlySufxPat/o ) ) {
		Afick::Msg->debug( "found only suffix ($1) in $fic", D2 );
		return 1;
	}
	else {
		return 0;
	}
}
################################################################
# used to exclude suffixes
sub test_exclude_suffix($$) {
	my $self = shift @_;
	my $fic  = shift @_;

	my $sufxPat = $self->{'sufxPat'};
	if ( ($sufxPat) and ( $fic =~ m/$sufxPat/o ) ) {
		Afick::Msg->debug( "found excluded suffix ($1) in $fic", D2 );
		$self->{'nb_exclude_sufx'}++;
		return 1;
	}
	else {
		return 0;
	}
}
################################################################
# used to exclude prefixes
sub test_exclude_prefix($$) {
	my $self = shift @_;
	my $fic  = shift @_;

	my $prefxPat = $self->{'prefxPat'};
	if ( ($prefxPat) and ( $fic =~ m/$prefxPat/o ) ) {
		Afick::Msg->debug( "found excluded prefix ($1) in $fic", D2 );
		$self->{'nb_exclude_prefx'}++;
		return 1;
	}
	else {
		return 0;
	}
}
################################################################
# used to exclude regex
sub test_exclude_re($$) {
	my $self = shift @_;
	my $fic  = shift @_;

	my $exRePat = $self->{'exRePat'};
	if ( ($exRePat) and ( $fic =~ m/$exRePat/o ) ) {
		Afick::Msg->debug( "found excluded regular ($1) in $fic", D2 );
		$self->{'nb_exclude_re'}++;
		return 1;
	}
	else {
		return 0;
	}
}
################################################################
sub nb_exclude_sufx($) {
	my $self = shift @_;

	return $self->{'nb_exclude_sufx'};
}
################################################################
sub nb_exclude_prefx($) {
	my $self = shift @_;

	return $self->{'nb_exclude_prefx'};
}
################################################################
sub nb_exclude_re($) {
	my $self = shift @_;

	return $self->{'nb_exclude_re'};
}
###############################################################
1;
