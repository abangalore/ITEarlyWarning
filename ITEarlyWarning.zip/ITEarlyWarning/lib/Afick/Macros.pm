#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classe implements Macros config elements
# macros are config element to be used by batch scripts :
# afick_cron and afick_planning
#
# the list is static
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Macros;

use strict;
use warnings;

use English qw(-no_match_vars);

use Afick::Constant;
use Afick::Msg;
use Afick::Tst;
use Afick::Gen;

our $VERSION = '1.2';

# when changing keys, do not forget to change also keys in %ck_macro
# default values
my %Macros_def = (
	'LINES' =>
	  1000,    # truncate the result sended by mail to this number of lines
	'MAILTO'   => EMPTY,    # mail adress to send cron job result
	'MAILHOST' => EMPTY,    # mail server to send the mail
	'MAILAUTH' => EMPTY,    # mail authentification
	'REPORT'   => 1,        # = 1 to enable reports, =0 to disable report
	'VERBOSE'  => 0
	, # =1 to have one mail by run, =0 to have a mail only if changes are detected
	'NICE'  => 18,       # nice value (priority of the job) (unix)
	'BATCH' => 1,        # = 1 to allow cron job, = 0 to suppress cron job
	'MOUNT' => EMPTY,    # a file system to mount before the scan
	'ARCHIVE_RETENTION' => 0,    # archive retention period

	# nagios
	'NAGIOS'                  => EMPTY,
	'NAGIOS_SERVER'           => EMPTY,
	'NAGIOS_CONFIG'           => EMPTY,
	'NAGIOS_CHECK_NAME'       => EMPTY,
	'NAGIOS_CRITICAL_CHANGES' => EMPTY,
	'NAGIOS_NSCA'             => EMPTY,
);

###############################################################
# constuctor
sub new($) {
	my $classe = shift @_;

	my $self = {};
	bless $self, $classe;
	$self->_init();
	return $self;
}
################################################################
# initialise object with default values
sub _init($) {
	my $self = shift @_;

	%{ $self->{'macros'} } = %Macros_def;
	return;
}
################################################################
# return a hash containing all macros
sub macros($) {
	my $self = shift @_;

	# do not return a reference to avoid external program modify internal data
	return %{ $self->{'macros'} };
}
###############################################################
# return true if the given key is a valid macros
sub is_macro($$) {
	my $self = shift @_;
	my $key  = shift @_;    # ex : LINES

	return ( exists $Macros_def{$key} );
}
###############################################################
# reset given macros key to default value
sub reset_macro($$) {
	my $self = shift @_;
	my $key  = shift @_;

	if ( $self->is_macro($key) ) {
		return $self->set_macro( $key, $Macros_def{$key} );
	}
	else {
		return 0;
	}
}
###############################################################
# return true if the given macros key contains a default value
# ps : we do not test if key is a macros
sub is_def_macro($$) {
	my $self = shift @_;
	my $key  = shift @_;

	return ( $self->{'macros'}{$key} eq $Macros_def{$key} );
}
###############################################################
# return the value of the given macro key
sub get_macro($$) {
	my $self = shift @_;
	my $key  = shift @_;

	if ( $self->is_macro($key) ) {
		return $self->{'macros'}{$key};
	}
	else {
		return;
	}
}
###############################################################
my %ck_macro = (
	'LINES'             => \&is_posint,
	'MAILTO'            => \&is_mail_adress,
	'MAILHOST'          => \&is_hostname,
	'MAILAUTH'          => \&is_list,
	'REPORT'            => \&is_binary,
	'VERBOSE'           => \&is_binary,
	'NICE'              => \&is_nicevalue,
	'BATCH'             => \&is_binary,
	'MOUNT'             => \&is_directory,
	'ARCHIVE_RETENTION' => \&is_retention,

	# nagios
	'NAGIOS'                  => \&is_binary,
	'NAGIOS_SERVER'           => \&is_hostname,
	'NAGIOS_CONFIG'           => \&is_anyfile,
	'NAGIOS_CHECK_NAME'       => \&is_name,
	'NAGIOS_CRITICAL_CHANGES' => \&is_posint,
	'NAGIOS_NSCA'             => \&is_anyfile,
);

## no critic (ProhibitUnusedPrivateSubroutines)
# to be called by test_macros to check this hash key match %Macros_def keys
sub _check_hash() {
	return compare_hashkey( \%ck_macro, \%Macros_def );
}
## use critic
###############################################################
# check if the data is valid for the given macro key
# return undef if not valid
# else return data
# if allow_undef is set, allows empty data
sub check_macro($$$$) {
	my $self        = shift @_;
	my $key         = shift @_;
	my $data        = shift @_;
	my $allow_undef = shift @_;

	if ( exists $ck_macro{$key} ) {
		if ( ( !defined $data ) or ( $data eq EMPTY ) ) {

			if ($allow_undef) {

				# special case for afickonfig to delete values
				return 1;
			}
			elsif ( $data eq $Macros_def{$key} ) {

				# default keys are allways ok
				return 1;
			}
			else {
				Afick::Msg->set_error("missing macro $key value");
				return;
			}
		}
		else {

			# call validation function upon data
			return &{ $ck_macro{$key} }($data);
		}
	}
	else {
		Afick::Msg->set_error("$key is not a valid macro keyword");
		return;
	}
}
###############################################################
# change macro key to data
sub set_macro($$$) {
	my $self = shift @_;
	my $key  = shift @_;
	my $data = shift @_;

	if ( $self->is_macro($key) ) {
		my $ret = $self->check_macro( $key, $data, 0 );
		if ( defined $ret ) {

			# we will use ret instead data, because of binary values
			# we allow 'yes' in file, but the internal value is 1 for example
			$self->{'macros'}{$key} = $ret;
			return 1;
		}
		else {

			# not a valid data
			Afick::Msg->warning( "$data is not a valid value for $key macro : "
				  . Afick::Msg->get_error() );
			return 0;
		}
	}
	else {

		# not a valid macro
		Afick::Msg->warning("$key is not a valid macro");
		return 0;
	}
}
################################################################
# print macro in info mode (all or just modified macro)
# with config syntaxe
sub print_macros($$) {
	my $self = shift @_;
	my $all  = shift @_;    # if true print all macros, else only not default

	foreach my $key ( sort keys %Macros_def ) {
		if ( ($all) || ( !$self->is_def_macro($key) ) ) {
			## no critic (RequireInterpolationOfMetachars)
			Afick::Msg->info(
				Afick::Constant->MACRO . " $key " . $self->{'macros'}{$key} );
		}
	}
	return;
}
################################################################
# to allow overload of macros by command line arguments
sub overload_macros($$) {
	my $self   = shift @_;
	my $rh_opt = shift @_;

	foreach my $key ( keys %{$rh_opt} ) {
		if ( $self->is_macro($key) ) {
			$self->set_macro( $key, $rh_opt->{$key} );
		}
	}
	return;
}
###############################################################
1;
