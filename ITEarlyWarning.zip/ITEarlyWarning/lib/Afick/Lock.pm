#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classe is designed to implement a very simple file locking system
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Lock;

use strict;
use warnings;

use English qw(-no_match_vars);

use base qw(Exporter);
## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );
$VERSION = '1.2';
@EXPORT  = qw( );

# optional modules
# ###################

# other afick modules
# #####################
use Afick::Constant;
use Afick::Msg;

my $lock_ext = '.lock';    # suffix for lock file

###############################################################
# constructor
sub new($) {
	my $classe = shift @_;

	my $self = {};
	bless $self, $classe;
	$self->_init();
	return $self;
}

###############################################################
# reset internal variables
sub _init($) {
	my $self = shift @_;

	$self->{'base_name'} = undef;    # file to be locked
	$self->{'lock_name'} = undef;    # associated lock file
	return;
}
################################################################
sub _build_lock_file($$) {
	my $self = shift @_;
	my $name = shift @_;             # base name to lock

	return $name . $lock_ext;
}
################################################################
sub basename($) {
	my $self = shift @_;

	return $self->{'base_name'};
}
################################################################
# lock a file
# exit if a file is already locked (do not wait)
# the goal is to avoid any access during a database write (init or update)
#
# database type (SDBM, GDBM) do not offer a common generic way to lock
# and using a classic flock on the database is not compatible with GDBM
# (which need a specific code, see DB_File doc)
# so the last way is to use a temporary file : .lock
#
# to avoid leaving a lock when the program ends, we use DESTROY
#
# another way may be use semaphores : IPC::Semaphore
# but it does not seems to exist on windows
###############################################################
sub mylock($$) {
	my $self = shift @_;
	my $name = shift @_;    # base name to lock

	# rem : we do not test if $name exists,
	# because we lock before creating database

	if ( $self->is_lock() ) {
		Afick::Msg->warning(
			'(mylock) object already lock file ' . $self->{'lock_name'} );
		return FALSE;
	}
	elsif ( $self->can_lock($name) ) {

		# ok : no lock on $name
		my $lock_name = $self->_build_lock_file($name);

		# create a dummy empty file
		if ( open my $fh_lock, '>', $lock_name ) {

			## no critic (RequireCheckedClose,RequireCheckedSyscalls)
			close $fh_lock;
			Afick::Msg->debug( "lock $name", D3 );
			$self->{'lock_name'} = $lock_name;
			$self->{'base_name'} = $name;
			return TRUE;
		}
		else {
			Afick::Msg->warning("(mylock) can not open $name : $ERRNO");
			return FALSE;
		}
	}
	else {
		Afick::Msg->warning("(mylock) already locked $name");
		return FALSE;
	}
}
################################################################
# unlock a file
sub unlock($) {
	my $self = shift @_;

	my $iret;
	if ( $self->is_lock() ) {

		my $base_name = $self->basename();
		my $lock_name = $self->{'lock_name'};

		# remove temporary file
		unlink $lock_name;
		Afick::Msg->debug( "unlock $base_name", D3 );

		# clear internal data
		$self->_init();
		$iret = TRUE;
	}
	else {
		# do nothing
		Afick::Msg->debug( '(unlock) : not locked', D3 );
		$iret = FALSE;
	}
	return $iret;
}
################################################################
# return true if the current object is already locked
# be careful : two objects may try to lock the same file !
sub is_lock($) {
	my $self = shift @_;

	return ( defined $self->{'lock_name'} );
}
################################################################
# return true if the given file is already locked
# this may be called as class method
sub can_lock($$) {
	my $self = shift @_;
	my $name = shift @_;    # filename to lock

	my $lock_name = $self->_build_lock_file($name);
	return ( !-f $lock_name );
}
################################################################
# ensure the lock file is removed at end of object
sub DESTROY($) {
	my $self = shift @_;

	if ( $self->is_lock() ) {
		$self->unlock();
	}
	return;
}
################################################################
1;
__END__

=head1 NAME

Afick::Lock

=head1 DESCRIPTION

=head1 DIAGNOSTICS

=head1 USAGE

use Afick::Lock;

my $lock = Afick::Lock->new();

$lock->mylock('foo');

$lock->unlock();

$lock->can_lock('foo');

$lock->is_lock();

=head1 OPTIONS

=head1 REQUIRED ARGUMENTS

=head1 EXIT STATUS

=head1 CONFIGURATION

=head1 DEPENDENCIES

=head1 INCOMPATIBILITIES

=head1 BUGS AND LIMITATIONS

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2002 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net

