#!/usr/bin/perl -w 
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id: Backend.pm 1940 2010-07-21 14:16:27Z gerbier $
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classe is used to store data on disk in a database
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Backend;

use strict;
use warnings;

use English qw(-no_match_vars);
use Fcntl qw( :DEFAULT );

# other afick modules
#####################
use Afick::Constant;
use Afick::Msg;
use Afick::Tst;
use Afick::Gen;    # touch
use Afick::Control;
use Afick::Lock;
use Afick::Report;    # print_env, print_last
use Afick::Object;

use base qw(Exporter);
## no critic (ProhibitAutomaticExportation)
our ( $VERSION, @EXPORT, );
$VERSION = '1.0';

# no critic (ProhibitConstantPragma)

# this list is sorted from best choice to the worse
# rem NDBM and ODBM can not be used because they
# do not implement exist method
my @list_dbm = qw(Storable GDBM_File SDBM_File DB_File );

my %h_database_ext = (
	Storable  => '.db',
	GDBM_File => Afick::Constant->EMPTY,
	SDBM_File => '.pag',
	DB_File   => Afick::Constant->EMPTY,
);
my %h_database_idx = (
	Storable  => Afick::Constant->EMPTY,
	GDBM_File => Afick::Constant->EMPTY,
	SDBM_File => '.dir',
	DB_File   => Afick::Constant->EMPTY,
);
###############################################################
# constuctor
sub new($) {
	my $classe = shift @_;

	my $self = {};
	bless $self, $classe;
	$self->_init();
	return $self;
}

###############################################################
# set default values
sub _init($) {
	my $self = shift @_;

	$self->{'dbm'}          = undef;    # database classe (ex : GDBM_File)
	$self->{'database'}     = undef;    # database name (without extension)
	$self->{'hashfile'}     = undef;    # internal tied hash to database
	$self->{'configfile'}   = undef;    # config file name
	$self->{'lock'}         = undef;    # Afick::Lock
	$self->{'ctr'}          = undef;    # Afick::Control
	$self->{'update'}       = undef;    # true if rw database or false if ro
	$self->{'version'}      = undef;    # afick version
	$self->{'date_ref_hum'} = undef;    # ref date for run
	     # $self->{'oldflat'}      = 0;        # count old records
	return;
}
#######################################################
# the goal is to find the best available database
# code inspired by AnyDBM_File
sub get_best_dbm($) {
	my $self = shift @_;

	foreach my $mod (@list_dbm) {
		if ( is_perl_module($mod) ) {
			Afick::Msg->debug( "(get_best_dbm) the best dbm found is $mod",
				D2 );
			import $mod;
			return $mod;
		}
	}
	Afick::Msg->my_die(
		'(get_best_dbm) No DBM package was successfully found or installed');

	# dummy return
	return;
}
#######################################################
# called in init mode
sub search_best_dbm($) {
	my $self = shift @_;

	my $dbm = $self->get_best_dbm();
	$self->{'dbm'} = $dbm;
	return $dbm;
}
#######################################################
# called in compare/update mode
# test for a database type
sub test_dbm($$) {
	my $self = shift @_;
	my $dbm  = shift @_;

	# 1) is dbm in list of tested backend
	my $found = 0;
	foreach my $mod (@list_dbm) {
		if ( $mod eq $dbm ) {
			$found = 1;
			last;
		}
	}
	if ( !$found ) {
		Afick::Msg->my_die("(test_dbm) unknown database $dbm module");
	}

	# 2) is dbm available on the system
	if ( is_perl_module($dbm) ) {

		# ok : available
		import $dbm;
		$self->{'dbm'} = $dbm;
	}
	else {
		Afick::Msg->my_die("(test_dbm) database $dbm is not available");
	}

	# 3) is there a better dbm available ?
	my $best_dbm = $self->get_best_dbm();
	if ( $best_dbm ne $dbm ) {
		Afick::Msg->warning(
			"(test_dbm) a better database is available : $best_dbm");
	}
	return;
}
#######################################################
sub get_dbm() {
	my $self = shift @_;

	return $self->{'dbm'};
}
#######################################################
# database suffixes
sub get_database_ext($) {
	my $self = shift @_;

	my $dbm = $self->get_dbm();
	if ( defined $dbm ) {
		return exists( $h_database_ext{$dbm} )
		  ? $h_database_ext{$dbm}
		  : Afick::Constant->EMPTY;
	}
	else {
		return Afick::Constant->EMPTY;
	}
}

sub get_database_idx($) {
	my $self = shift @_;

	my $dbm = $self->get_dbm();
	if ( defined $dbm ) {
		return exists( $h_database_idx{$dbm} )
		  ? $h_database_idx{$dbm}
		  : Afick::Constant->EMPTY;
	}
	else {
		return Afick::Constant->EMPTY;
	}
}
########################################################
# give database name
sub set_database($$) {
	my $self     = shift @_;
	my $database = shift @_;

	$self->{'database'} = $database;
	return;
}
########################################################
sub get_database($) {
	my $self = shift @_;

	return $self->{'database'};
}
########################################################
# return database full name with suffix
sub get_database_fullname($) {
	my $self = shift @_;

	return $self->get_database() . $self->get_database_ext();
}
########################################################
# return database index full name with suffix
sub get_database_index($) {
	my $self = shift @_;

	my $suffix = $self->get_database_idx();

	return $suffix
	  ? $self->get_database() . $suffix
	  : Afick::Constant->EMPTY;
}
########################################################
sub exists_database() {
	my $self = shift @_;

	return ( -f $self->get_database_fullname() );
}
########################################################
# return list of database files
sub list_database_control() {
	my $self = shift @_;

	my @list;

	# control file should be added in Control.pm

	# database
	push @list, $self->get_database_fullname();

	# database index if exists
	my $database_idx = $self->get_database_idx();
	if ($database_idx) {
		push @list, $self->get_database_index();
	}

	# for security : restrict perm on database files
	foreach my $fic (@list) {
		chmod Strict_perm, $fic;
	}
	return @list;
}
#######################################################
# create a new database (empty the existing one if exists)
sub create_database_init($$$$) {
	my $self         = shift @_;
	my $config       = shift @_;    # Cfg object
	my $date_ref_hum = shift @_;
	my $version      = shift @_;

	my $configfile = $config->get_configfile();
	my $database   = $config->get_directive('database');

	# store for close_database
	$self->{'version'}      = $version;
	$self->{'date_ref_hum'} = $date_ref_hum;

	# get best dbm
	my $dbm = $self->search_best_dbm();
	$self->set_database($database);

	my $database_fullname = $self->get_database_fullname();

	if ( -f $database_fullname ) {
		Afick::Msg->warning(
'(create) init on an already existing database : changes will be lost'
		);
	}

	# create control file
	my $ctr = Afick::Control->new($database);
	$ctr->strict_ctr();

	# lock then open database to solve problems with GDBM
	$self->{'lock'} = Afick::Lock->new();
	if ( !$self->{'lock'}->mylock($database_fullname) ) {
		Afick::Msg->my_die(
			"(create) : database $database_fullname already locked");
	}

	## no critic (ProhibitTies,ProhibitParensWithBuiltins)
	# delete all previous data
	my %hashfile = ();
	if ( $dbm eq 'Storable' ) {
		touch($database_fullname);
		chmod Afick::Constant->Strict_perm, $database_fullname;
	}
	else {
		tie(
			%hashfile, $dbm, $database,
			O_RDWR | O_CREAT,
			Afick::Constant->Strict_perm
		  )
		  or Afick::Msg->my_die(
			"(create) : can not open database $dbm $database : $ERRNO");
	}

	$self->{'hashfile'} = \%hashfile;

	# open report
	Afick::Report->print_env( 'init', $config, $dbm, $date_ref_hum, $version );
	Afick::Msg->debug( '(create) begin', 1 );

	return;
}
#######################################################
# open database with a tie on dbm database
# in ro/rw mode
sub open_database($$$$$) {
	my $self         = shift @_;
	my $config       = shift @_;    # Afick::Cfg object
	my $action       = shift @_;    # action (update, compare), for info
	my $date_ref_hum = shift @_;
	my $version      = shift @_;

	# store for close_database
	$self->{'version'}      = $version;
	$self->{'date_ref_hum'} = $date_ref_hum;

	my $database = $config->get_directive('database');

	# read control file
	my $ctr = Afick::Control->new($database);
	$ctr->read_control();
	my $dbm = $ctr->get_dbm();

	# check security
	my %directives = $config->directives();
	$ctr->check_control( $self, \%directives );

	# test database perm and restrict if necessary
	my $database_fullname = $self->get_database_fullname();
	my $database_index    = $self->get_database_index();
	my $mode              = ( stat $database_fullname )[2];
	if ( $mode != Afick::Constant->Strict_perm ) {
		chmod Afick::Constant->Strict_perm, $database_fullname;
		chmod Afick::Constant->Strict_perm, $database_index
		  if ( -e $database_index );
		my $mode_human = print_oct($mode);
		my $new_mode   = print_oct( Afick::Constant->Strict_perm );
		Afick::Msg->debug(
"(open_database) restrict permission on $database from $mode_human to $new_mode",
			1
		);
	}

	# lock
	$self->{'lock'} = Afick::Lock->new();

	## no critic (ProhibitTies)
	# open database in adequate mode
	if ( $dbm eq 'Storable' ) {
		$self->{'hashfile'} = retrieve($database_fullname);

		if ( $action eq 'update' ) {
			if ( !$self->{'lock'}->mylock($database_fullname) ) {
				Afick::Msg->my_die(
					"(update) : database $database_fullname already locked");
			}
		}
	}
	elsif ( $action eq 'update' ) {
		if ( !$self->{'lock'}->mylock($database_fullname) ) {
			Afick::Msg->my_die(
				"(update) : database $database_fullname already locked");
		}
		## no critic (ProhibitParensWithBuiltins)
		my %hashfile;
		tie( %hashfile, $dbm, $database, O_RDWR, Afick::Constant->Strict_perm )
		  or Afick::Msg->my_die(
			"(update) : can not open database $dbm $database : $ERRNO");
		$self->{'hashfile'} = \%hashfile;
		$action = 'update' if ( !$action );
	}
	else {

		# if we work on read-only media, can not lock a file
		## no critic (ProhibitParensWithBuiltins)
		my %hashfile;
		tie( %hashfile, $dbm, $database, O_RDONLY,
			Afick::Constant->Strict_perm )
		  or Afick::Msg->my_die("can not open $dbm $database : $ERRNO");
		$self->{'hashfile'} = \%hashfile;
		$action = 'compare' if ( !$action );
	}

	# open report
	Afick::Msg->debug( "begin $action", 1 );
	Afick::Report->print_env( $action, $config, $dbm, $date_ref_hum, $version );
	Afick::Report->print_last( $ctr->get_run_date(), $ctr->get_old_version() );

	return $action;
}
#######################################################
# to be called at end of scan to display informations on database
# and write control file
sub end_report($$) {
	my $self   = shift @_;
	my $config = shift @_;    # Afick::Cfg object

	# Generate a MD5 for the dbm file.
	my $sum = md5sum( $self->get_database_fullname(), 0, 0 );
	my $database = $self->{'database'};

	my $DIESE = q{#};
	Afick::Msg->info( $DIESE x 65 );
	Afick::Msg->info("MD5 hash of $database => $sum");

	my $ctr        = Afick::Control->new($database);
	my %directives = $config->directives();
	$ctr->write_control( $sum, $self->{'version'}, $self->{'date_ref_hum'},
		$self->get_dbm(), \%directives )
	  if ( $self->is_update() );
	return;
}
#######################################################
# close database and unlock if necessary
sub close_database($$) {
	my $self   = shift @_;
	my $config = shift @_;    # Afick::Cfg object

	# 1 untie / write
	if ( $self->{'dbm'} eq 'Storable' ) {
		if ( $self->is_update() ) {

			#$self->rewrite() if ( $self->{'oldflat'} );
			store( $self->{'hashfile'}, $self->get_database_fullname() );
		}
		else {
			Afick::Msg->debug( 'no need to save database', 2 );
		}
	}
	else {
		untie %{ $self->{'hashfile'} };
	}

	# 2 unlock
	if ( $self->{'lock'}->is_lock() ) {
		$self->{'lock'}->unlock();
	}

	# 3 control file
	$self->end_report($config);

	return;
}
#######################################################
# update
#######################################################
sub set_update($$) {
	my $self  = shift @_;
	my $value = shift @_;

	$self->{'update'} = $value;

	return;
}

#------------------------------------------------------
sub is_update($) {
	my $self = shift @_;

	return $self->{'update'};
}
#######################################################
# data access : hashfile
#######################################################
# in this release, keep old storage format
# but get method return an Afick::Object
# and set take an Afick::Object as input
sub get($$) {
	my $self = shift @_;
	my $key  = shift @_;

	if ( exists $self->{'hashfile'}->{$key} ) {
		my $data = $self->{'hashfile'}->{$key};

		#Afick::Msg->info( "Object::get $key ref " . ref $data );

		#if ( $data->isa('Afick::Object' ) ) {
		#	# should be a ref to Afick::Object
		#	return $data;
		#}
		#else {
		#$self->{'oldflat'}++;

		# a simple object : old format
		# transform to Afick::Object
		my $rec = Afick::Object->new();
		$rec->from_oldflat( $key, $data );
		return $rec;

		#}
	}
	else {
		# key not found
		Afick::Msg->debug("key $key not found in database");
		return;
	}
}

#------------------------------------------------------
# set a new value for the given key
## no critic (ProhibitAmbiguousNames)
sub set($$$) {
	my $self = shift @_;
	my $key  = shift @_;
	my $data = shift @_;

	# only record data in update/init mode
	if ( $self->is_update() ) {

		#Afick::Msg->info( "Object::set $key ref " . ref $data );
		if ( $data->isa('Afick::Object') ) {

			# should be a ref to Afick::Object
			#$self->{'hashfile'}->{$key} = $data;

			# convert to old flat
			my $data_flat = $data->to_oldflat();
			$self->{'hashfile'}->{$key} = $data_flat;
		}
		else {
			# transform old flat format to Afick::Object
			# my $rec = Afick::Object->new();
			# $rec->from_oldflat( $key, $data );
			# $self->{'hashfile'}->{$key} = $rec;
			# Afick::Msg->warning("receive data for $key in old flat format");

			$self->{'hashfile'}->{$key} = $data;
		}
	}
	return;
}
## use critic
#------------------------------------------------------
# return all keys (for a foreach loop)
sub getkeys($$) {
	my $self = shift @_;

	return keys %{ $self->{'hashfile'} };
}

#------------------------------------------------------
# test if an entry exists
sub exist($$) {
	my $self = shift @_;
	my $key  = shift @_;

	return exists $self->{'hashfile'}->{$key};
}

#------------------------------------------------------
# delete an entry
sub del($$) {
	my $self = shift @_;
	my $key  = shift @_;

	delete $self->{'hashfile'}->{$key};
	return;
}
################################################################
# used to change storage format
# force rewrite all records
#sub rewrite($) {
#	my $self = shift @_;
#
#	foreach my $key ( $self->getkeys() ) {
#		my $item = $self->get();
#		$self->set($item);
#	}
#	return;
#}
################################################################
1;
