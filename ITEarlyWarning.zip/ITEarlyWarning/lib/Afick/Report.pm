#!/usr/bin/perl -w 
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id: Cfg.pm 1572 2009-04-02 12:27:27Z gerbier $
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classes implement the afick report function
# could be a set of function, but maybe add also data
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Report;

use strict;
use warnings;

use Afick::Msg;
use Afick::Constant;

our ($VERSION);
$VERSION = '1.0';

use English qw(-no_match_vars);

###############################################################
# constuctor
sub new($) {
	my $classe = shift @_;

	my $self = bless {}, $classe;

	$self->_init();
	return $self;
}

###############################################################
# configure initial data
sub _init($) {
	my $self = shift @_;

	# finded : keep a record of scanned files
	%{ $self->{'finded'} } = ();

	# dangling : list of dangling files
	%{ $self->{'dangling'} } = ();

	return;
}
#######################################################
# finded
#######################################################
sub set_finded($$) {
	my $self = shift @_;
	my $name = shift @_;

	$self->{'finded'}->{$name} = 1;

	return;
}

#------------------------------------------------------
sub is_finded($$) {
	my $self = shift @_;
	my $name = shift @_;

	return exists $self->{'finded'}->{$name};
}

#------------------------------------------------------
sub nb_finded($) {
	my $self = shift @_;

	return scalar keys %{ $self->{'finded'} };
}
#######################################################
# dangling
#######################################################
sub set_dangling($$$) {
	my $self  = shift @_;
	my $name  = shift @_;
	my $value = shift @_;

	$self->{'dangling'}->{$name} = $value;

	return;
}

#------------------------------------------------------
sub get_dangling($$$) {
	my $self = shift @_;
	my $name = shift @_;

	return $self->{'dangling'}->{$name};
}

#------------------------------------------------------
sub keys_dangling($) {
	my $self = shift @_;

	return keys %{ $self->{'dangling'} };
}

#------------------------------------------------------
sub nb_dangling($) {
	my $self = shift @_;

	return scalar keys %{ $self->{'dangling'} };
}
#######################################################
# print run conditions
sub print_env($$$$$$) {
	my $self         = shift @_;
	my $action       = shift @_;    # ex init, update ...
	my $config       = shift @_;    # Afick::Cfg
	my $dbm          = shift @_;    # database type
	my $date_ref_hum = shift @_;    # date of run
	my $version      = shift @_;    # afick version

	Afick::Msg->info(
		    "Afick ($version) $action at $date_ref_hum with options ("
		  . $config->get_configfile()
		  . '):' );

	# only show set directives
	$config->print_directives(0);

	# and dbm as pseudo-directive
	Afick::Msg->info( 'dbm' . Afick::Constant->DIREC . $dbm );
	return;
}
#######################################################
# print last run date and version
sub print_last($$$) {
	my $self        = shift @_;
	my $run_date    = shift @_;    # last scan date
	my $old_version = shift @_;    # afick old version

	if ( defined $run_date ) {
		Afick::Msg->info( 'last run on '
			  . $run_date
			  . ' with afick version '
			  . $old_version );
	}
	return;
}
#######################################################
# high-level sub for detailed messages
sub report_detailed($$$;$) {
	my $self  = shift @_;
	my $field = shift @_;    # field name
	my $val1  = shift @_;    # old value
	my $val2  = shift @_;    # new value (optionnal)

	my $txt = "\t$field\t\t : $val1";
	$txt .= "\t$val2" if ( defined $val2 );

	Afick::Msg->report( $txt, Afick::Msg->Info );
	return;
}
#######################################################
# to be added : print_new, print_deleted, print_changed ...
#######################################################
1;
