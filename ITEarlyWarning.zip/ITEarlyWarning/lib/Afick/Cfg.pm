#!/usr/bin/env perl
###############################################################################
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this classes implement the afick configuration
# - read / write config file
# - contains all parameters :
# 	+ macro/alias/directives are stored by heritance
# 	+ rules depends upon alias and are stored by it-self
###############################################################################
# I use special naming for references :
# $r_name : for a ref to scalar
# $rh_name : for a ref to hashes
# $ra_name : for a ref to array

package Afick::Cfg;

use strict;
use warnings;

use English qw(-no_match_vars);
use File::Basename;        # for dirname
use File::Glob ':glob';    # for jokers
use Cwd 'abs_path';

use Afick::Constant;
use Afick::Msg;
use Afick::Tst;
use Afick::Gen;
use Afick::Aliases;
use Afick::Directives;
use Afick::Macros;

our $VERSION = 1.2;

# heritage multiple
# is possible because methods and data are differents
## no critic (ProhibitExplicitISA)
use vars qw( @ISA );
@ISA = qw( Afick::Aliases Afick::Directives Afick::Macros );

###############################################################
# constuctor
sub new($;$) {
	my $classe = shift @_;
	my $config = shift @_;    # config file name

	my $self = bless {}, $classe;

	# for multi-heritence, have to call all _init
	# perl cookbook 13.10
	my $init_sub = '_init';
	for my $par (@ISA) {

		# test of parent module will insure the _init method exists
		#if ( $par->can($init_sub) ){
		## no critic (ProhibitNoisyQuotes)
		my $meth = $par . '::' . $init_sub;
		$self->$meth();

		#}
	}

	$self->_init($config);
	return $self;
}
###############################################################
# configure initial data
sub _init($;$) {
	my $self   = shift @_;
	my $config = shift @_;    # config file name

	# configuration file
	if ($config) {
		$self->set_configfile($config);
	}
	else {
		$self->{'configfile'} = _get_default_config();
	}

	# list of files to scan (in same order as config file)
	@{ $self->{'rules_byorder'} } = ();

	# files -> masq or 0 to stop scan
	%{ $self->{'rules_toscan'} } = ();

	# list of internal files (which can not be excluded)
	%{ $self->{'rules_control'} } = ();

	# list of "equal" selection :
	# only this inode
	%{ $self->{'rules_onlythis'} } = ();

	# list of "equal" selection
	# only this directory and it's content, without subdir
	%{ $self->{'rules_onlydir'} } = ();

	# file mode
	$self->{'filemode'} = 0;

	# clean mode
	$self->{'cleanmode'} = 0;

	# if not of heritance we should write here something like
	#$self->{'macros'} = Afick::Macros->new();
	#$self->{'directives'} = Afick::Directives->new();
	#$self->{'aliases'} = Afick::Aliases->new();
	# but the problem will be external access to data

	# in epoch format
	$self->{'dateref'} = $BASETIME;

	return;
}
###############################################################
# configfile
###############################################################
# return default config file according operating system
# environment variable
sub _get_default_config() {
	my $default_config_file;

	if ( exists $ENV{'AFICK_CONFIG'} ) {
		$default_config_file = $ENV{'AFICK_CONFIG'};
	}
	elsif ( is_microsoft() ) {
		$default_config_file = 'windows.conf';
	}
	elsif ( -r '/etc/afick.conf' ) {
		$default_config_file = '/etc/afick.conf';
	}
	else {
		$default_config_file = 'afick.conf';
	}

	return ( -r $default_config_file ) ? $default_config_file : EMPTY;
}
###############################################################
# get config file name
sub get_configfile($) {
	my $self = shift @_;

	return $self->{'configfile'};
}

#--------------------------------------------------------------
# config file for control
sub get_config_control($) {
	my $self = shift @_;

	my $configfile = $self->get_configfile();

	$configfile = lc $configfile
	  if ( $self->get_directive('ignore_case') );
	$configfile = to_abspath($configfile)
	  if ( !$self->get_directive('allow_relativepath') );

	return $configfile;
}
###############################################################
# set config file name
sub set_configfile($$) {
	my $self     = shift @_;
	my $filename = shift @_;    # new config file name

	if ( -r $filename ) {
		$self->{'configfile'} = $filename;
		return 1;
	}
	else {
		return;
	}
}
################################################################
# return program reference time
sub get_dateref($) {
	my $self = shift @_;

	return $self->{'dateref'};
}
################################################################
# same in a human format
sub get_dateref_h($) {
	my $self = shift @_;

	return history_date( get_time( $self->get_dateref() ) );
}
################################################################
# cleanmode property
sub get_cleanmode($) {
	my $self = shift @_;

	return $self->{'cleanmode'};
}

#--------------------------------------------------------------
sub set_cleanmode($$) {
	my $self = shift @_;
	my $mode = shift @_;

	$self->{'cleanmode'} = $mode;
	return;
}
################################################################
# read/write config file
################################################################
# open and read full configuration file
# return false if there is a problem
sub _read_config($) {
	my $self = shift @_;

	my $configfile = $self->get_configfile();
	if ( !$configfile ) {
		Afick::Msg->set_error('(read_config) no config file');
		return;
	}
	elsif ( open my $fh_config, '<', $configfile ) {
		my @config;
		while ( my $ligne = <$fh_config> ) {

			# normalize config line
			chomp $ligne;
			remove_trailing_spaces( \$ligne );
			push @config, $ligne;
		}
		close $fh_config
		  or Afick::Msg->set_error(
			"(read_config) can not close $configfile : $ERRNO");

		return @config;
	}
	else {
		Afick::Msg->set_error(
			"(_read_config) can not open $configfile : $ERRNO");
	}
	return;
}
################################################################################
# write to a config file
sub _write_config($$) {
	my $self      = shift @_;
	my $ra_config = shift @_;    # array containing config lines

	my $configfile = $self->get_configfile();
	if ( open my $fh_config, '>', $configfile ) {
		foreach my $ligne ( @{$ra_config} ) {
			print {$fh_config} $ligne . "\n";
		}
		close $fh_config
		  or Afick::Msg->set_error("can not close $configfile : $ERRNO");
		return 1;
	}
	else {
		Afick::Msg->set_error("can not write to $configfile : $ERRNO");
		return;
	}
}
################################################################
# used by read_configuration
# to display warnings
sub config_warning($$$$;$) {
	my $state   = shift @_;           # action set
	my $line    = shift @_;           # line content
	my $line_id = shift @_;           # line number
	my $type    = shift @_;           # object type
	my $text    = shift @_ || q{};    # optionnal text

	chomp $text;
	Afick::Msg->warning("$state bad config $type $line (line $line_id) $text");
	return;
}
##########################################################################
# check duplicate for aliases, macros, directives
sub _check_duplicate($$$$) {
	my $self    = shift @_;
	my $key     = shift @_;           # key to be tested
	my $rh_find = shift @_;           # hash file containing already seen keys
	my $kind    = shift @_;           # macro, alias, directive

	Afick::Msg->debug( "(_check_duplicate) $key", D3 );

	if ( ( $kind eq 'directive' ) && ( $key =~ m/^exclude/ ) ) {

		# allow multi_lines for some directives : exclude*
		return 0;
	}
	elsif ( exists $rh_find->{$key} ) {
		my $line = $rh_find->{$key};
		Afick::Msg->set_error("found duplicate $kind $key with line $line");
		return 1;
	}
	else {

		# ok
		# rem : adding key to hash file is done by _add_key, after all tests
		return 0;
	}
}
################################################################
# add key to already seen keys
sub _add_key($$$;$) {
	my $self    = shift @_;
	my $key     = shift @_;         # key to be tested
	my $rh_find = shift @_;         # hash file containing already seen keys
	my $line_id = shift @_ || 0;    # config file line number

	$rh_find->{$key} = $line_id;
	return;
}
################################################################
# expand config line : treat jokers, and split into <[files] attribute flagdir>
sub _trait_rule_line ($$) {
	my $self   = shift @_;
	my $ra_ret = shift @_;    # receive array with line split : name attribute

	my $name      = @{$ra_ret}[0];
	my $attribute = @{$ra_ret}[1];

	my $ignore_case = $self->get_directive('ignore_case');

	# if ignore_case change all names
	$name = lc $name if ($ignore_case);

	# for compatibility with old syntax
	$attribute = 'all' if ( !$attribute );

	# Afick::Msg->debug("$name -> $attribute", D1);

	my @files;
	my $flagdir;    # true if is a directory

	# expand jokers if exists
	## no critic (ProhibitEscapedMetacharacters)
	if ( $name =~ m/[\*\?]/ ) {
		@files = glob $name;
		Afick::Msg->debug( "(trait_line) expand $name in @files", D2 );
		if ($ignore_case) {
			foreach (@files) {
				$_ = lc;
			}
		}
	}    # jokers

	# test for root
	elsif ( is_fsroot($name) ) {
		$flagdir = 1;
		push @files, $name;
	}
	elsif ( $name =~ m{/$} ) {

		# remove trailing /
		$name =~ s{/$}{};
		$flagdir = 1;
		push @files, $name;
	}
	else {
		$flagdir = 0;
		push @files, $name;
	}
	push @files, $attribute, $flagdir;
	return @files;
}
################################################################
# generic code to work on a bad line
# if in clean mode
# change the line : (comment it)
# or just warn
sub _trait_line_error($$$$$) {
	my $self    = shift @_;
	my $r_line  = shift @_;    # ref to line content
	my $line_id = shift @_;    # line number
	my $missing = shift @_;    # true if missing file
	my $type    = shift @_;    # object type

	if ( $self->get_cleanmode() ) {
		config_warning( 'fix', ${$r_line}, $line_id, $type,
			Afick::Msg->get_error() );

		# comment bad line in @config (line is a ref to config)
		${$r_line} = '# ' . ${$r_line};
	}
	elsif ($missing) {
		if ( $self->get_directive('warn_missing_file') ) {
			config_warning( 'skip', ${$r_line}, $line_id, $type,
				Afick::Msg->get_error() );
		}
		else {

			# only debug
			Afick::Msg->debug(
"skipped config file selection ${$r_line} (line $line_id): missing file",
				D2
			);
		}
	}
	else {

		# just skip the line and send a warning
		config_warning( 'skip', ${$r_line}, $line_id, $type,
			Afick::Msg->get_error() );
	}
	return;
}
################################################################
# check and set macros lines
# return the number of errors
sub _read_configuration_macro($$$$$) {
	my $self    = shift @_;
	my $ra_ret  = shift @_;    # array returned by is_macro_line pattern test
	my $rh_seen = shift @_;    # ref to hash for duplicates test
	my $r_line  = shift @_;    # ref to line content
	my $line_id = shift @_;    # line number

	my $key = shift @{$ra_ret};
	my $val = shift @{$ra_ret};

	if ( !$self->is_macro($key) ) {

		# error : bad key
		$self->_trait_line_error( $r_line, $line_id, 0, 'macro' );
		return 1;
	}
	elsif ( $self->_check_duplicate( $key, $rh_seen, 'macro' ) ) {

		# error : duplicate macro
		$self->_trait_line_error( $r_line, $line_id, 0, 'macro' );
		return 1;
	}
	elsif ( !( my $ret2 = $self->set_macro( $key, $val, 0 ) ) ) {

		# error : bad value
		$self->_trait_line_error( $r_line, $line_id, 0, 'macro' );
		return 1;
	}
	else {

		# ok : good macro line
		Afick::Msg->debug( "(config file) found macro $key : $ret2 ($val)",
			D2 );
		$self->_add_key( $key, $rh_seen, $line_id );
		return 0;
	}
}
################################################################
# check and set directive lines
# return 1 if the line is bad
sub _read_configuration_directive($$$$$) {
	my $self    = shift @_;
	my $ra_ret  = shift @_;   # array returned by is_directive_line pattern test
	my $rh_seen = shift @_;   # hash of already seen directives
	my $r_line  = shift @_;   # config line
	my $line_id = shift @_;   # config line number

	my $key = shift @{$ra_ret};
	my $val = shift @{$ra_ret};
	remove_trailing_spaces( \$val );

	## no critic (ProhibitCascadingIfElse)
	if ( !$self->is_directive($key) ) {

		# error : bad key
		$self->_trait_line_error( $r_line, $line_id, 0, 'directive' );
		return 1;
	}
	elsif ( $self->_check_duplicate( $key, $rh_seen, 'directive' ) ) {

		# error : duplicate directive
		$self->_trait_line_error( $r_line, $line_id, 0, 'directive' );
		return 1;
	}
	elsif ( $self->is_initialized($key)
		&& ( $key !~ m/^exclude/ ) )
	{

		# this special case is to allow command line directive to be set before
		# read_configuration and not be overload by read_configuration
		Afick::Msg->debug( "(config file) skip directive $key : already set",
			D2 );
		return 0;
	}
	elsif ( !( my $ret2 = $self->set_directive( $key, $val ) ) ) {

		# error can not set value
		$self->_trait_line_error( $r_line, $line_id, 0, 'directive' );
		return 1;
	}
	else {

		# ok : good directive line
		Afick::Msg->debug( "(config file) found directive $key : $ret2 ($val)",
			D2 );
		$self->_add_key( $key, $rh_seen, $line_id );
		return 0;
	}
}
################################################################
# check and set alias lines
# return 1 if the line is bad
sub _read_configuration_alias($$$$$) {
	my $self    = shift @_;
	my $ra_ret  = shift @_;    # array returned by is_alias_line pattern test
	my $rh_seen = shift @_;    # hash of already seen aliases
	my $r_line  = shift @_;    # config line
	my $line_id = shift @_;    # config line number

	my $key = shift @{$ra_ret};
	my $val = shift @{$ra_ret};
	remove_all_spaces( \$val );

	# do not test about is_alias because list key is not fixed
	if ( $self->_check_duplicate( $key, $rh_seen, 'alias' ) ) {

		# error : duplicate alias
		$self->_trait_line_error( $r_line, $line_id, 0, 'alias' );
		return 1;
	}
	elsif ( !( my $ret2 = $self->set_alias( $key, $val, 0 ) ) ) {

		# error : bad value
		$self->_trait_line_error( $r_line, $line_id, 0, 'alias' );
		return 1;
	}
	else {

		# ok : good alias line
		Afick::Msg->debug( "(config file) found alias $key : $ret2 ($val)",
			D2 );
		$self->_add_key( $key, $rh_seen, $line_id );
		return 0;
	}
}
################################################################
# check and set negatives rules lines
# return 1 if the line is bad
sub _read_configuration_negsel($$$$$) {
	my $self    = shift @_;
	my $ra_ret  = shift @_;    # array returned by is_negsel_line pattern test
	my $rh_seen = shift @_;    # hash of already seen directives
	my $r_line  = shift @_;    # config line
	my $line_id = shift @_;    # config line number

	my @files = $self->_trait_rule_line($ra_ret);
	pop @files;                # ignore flagdir
	pop @files;                # ignore attribute

	my $nb_total_err = 0;
	my $attribute    = 0;      # for delete
	my $control      = 0;
	my $only         = 0;
	foreach my $elem (@files) {
		my $chroot_elem = add_chroot($elem);
		$nb_total_err +=
		  $self->addrule( $chroot_elem, $attribute, $control, $rh_seen, $r_line,
			$line_id, $only );
	}
	return $nb_total_err;
}
################################################################
# check and set equal rules lines
# return 1 if the line is bad
sub _read_configuration_equalsel($$$$$) {
	my $self    = shift @_;
	my $ra_ret  = shift @_;    # array returned by is_negsel_line pattern test
	my $rh_seen = shift @_;    # hash of already seen directives
	my $r_line  = shift @_;    # config line
	my $line_id = shift @_;    # config line number

	my @files     = $self->_trait_rule_line($ra_ret);
	my $flagdir   = pop @files;
	my $attribute = pop @files;

	my $nb_total_err = 0;
	my $control      = 0;
	my $only         = ($flagdir) ? 2 : 1;
	foreach my $elem (@files) {

		my $chroot_elem = add_chroot($elem);
		if ( is_directory($chroot_elem) ) {
			$nb_total_err +=
			  $self->addrule( $chroot_elem, $attribute, $control, $rh_seen,
				$r_line, $line_id, $only );
		}
		else {

			# error : an equal selection must be set on a directory name
			$self->_trait_line_error( $r_line, $line_id, 0, 'neg rule' );
			$nb_total_err += 1;
		}
	}
	return $nb_total_err;
}
################################################################
# check and set rules lines
# return 1 if the line is bad
sub _read_configuration_sel($$$$$) {
	my $self    = shift @_;
	my $ra_ret  = shift @_;    # array returned by is_negsel_line pattern test
	my $rh_seen = shift @_;    # hash of already seen directives
	my $r_line  = shift @_;    # config line
	my $line_id = shift @_;    # config line number

	my @files = $self->_trait_rule_line($ra_ret);
	pop @files;                # ignore flagdir
	my $attribute = pop @files;

	my $nb_total_err = 0;
	my $control      = 0;
	my $only         = 0;
	foreach my $elem (@files) {
		my $chroot_elem = add_chroot($elem);
		$nb_total_err +=
		  $self->addrule( $chroot_elem, $attribute, $control, $rh_seen, $r_line,
			$line_id, $only );
	}
	return $nb_total_err;
}
################################################################
# read and parse configuration file
sub read_configuration($;$) {
	my $self = shift @_;
	my $clean = shift @_ || 0;    # if true, clean config file from bad lines

	$self->set_cleanmode($clean);
	Afick::Msg->debug_begin();

	my @config = $self->_read_config();
	if ( !@config ) {
		Afick::Msg->my_die( Afick::Msg->get_error() );
	}

	my $configfile = $self->get_configfile();

	# control chroot
	chroot_check();

	Afick::Msg->debug(
		"-------- begin of config file $configfile -------------", D1 );

	my %seen_macros;        # already seen macro
	my %seen_directives;    # already seen directives
	my %seen_aliases;       # already seen aliases
	my %seen_rules;         # already seen rules
	my $nb_pbs  = 0;        # number of problem (bad lines)
	my $line_id = 0;        # line counter
  LOOP: foreach my $line (@config) {
		$line_id++;

		# clean line
		next LOOP unless length $line;    # skip blank lines
		next LOOP if ( $line =~ m/^#/ );  # skip comments

		# remove trailing slash
		# done in _trait_rule_line
		#$linerule =~ s{/$}{};

		# environment variables check
		# something like ${xxx}
		my $linerule = $line;
		## no critic (ProhibitEscapedMetacharacters)
		if ( $linerule =~ m/(.*)\$\{([^}]+)\}(.*)/ ) {
			if ( exists $ENV{$2} ) {

				# just replace on fly
				my $expand = $ENV{$2};
				$linerule = $1 . $expand . $3;
				Afick::Msg->debug(
"expand $2 into $expand in config file $line (line $line_id)",
					D2
				);
			}
			else {
				$nb_pbs++;
				Afick::Msg->set_error("found unset environment variable $2");
				$self->_trait_line_error( \$line, $line_id, 0, 'env' );
			}
		}

		# normalise directory separators
		#  but just on files (selection lines)
		#  because exclude_re can use \x patterns
		$linerule = reg_name($linerule);

		Afick::Msg->debug( "config line = $line", D4 );

		my @ret;
		## no critic (ProhibitCascadingIfElse)
		if ( @ret = is_directive_line($line) ) {
			Afick::Msg->debug( "detect directive line $line", D3 );
			$nb_pbs +=
			  $self->_read_configuration_directive( \@ret, \%seen_directives,
				\$line, $line_id );
		}
		elsif ( @ret = is_macro_line($line) ) {
			Afick::Msg->debug( "detect macro line $line", D3 );
			$nb_pbs +=
			  $self->_read_configuration_macro( \@ret, \%seen_macros, \$line,
				$line_id );
		}
		elsif ( @ret = is_alias_line($line) ) {
			Afick::Msg->debug( "detect alias line $line", D3 );
			$nb_pbs +=
			  $self->_read_configuration_alias( \@ret, \%seen_aliases, \$line,
				$line_id );
		}
		elsif ( @ret = is_negsel_line($linerule) ) {
			Afick::Msg->debug( "detect negative rule line $line ($linerule)",
				D3 );
			$nb_pbs +=
			  $self->_read_configuration_negsel( \@ret, \%seen_rules, \$line,
				$line_id );
		}
		elsif ( @ret = is_equalsel_line($linerule) ) {
			Afick::Msg->debug( "detect equal rule line $line ($linerule)", D3 );
			$nb_pbs +=
			  $self->_read_configuration_equalsel( \@ret, \%seen_rules, \$line,
				$line_id );
		}
		elsif ( @ret = is_sel_line($linerule) ) {
			Afick::Msg->debug( "detect rule line $line ($linerule)", D3 );
			$nb_pbs +=
			  $self->_read_configuration_sel( \@ret, \%seen_rules, \$line,
				$line_id );
		}
		else {
			Afick::Msg->warning(
				"skipped config file $line (line $line_id) : unknown line type"
			);
			$nb_pbs++;
			$self->_trait_line_error( \$line, $line_id, 0, 'unknown' );
		}
	}    # end LOOP

	# do we have to rewrite config file (clean mode) ?
	if ( $clean and $nb_pbs ) {
		$self->_write_config( \@config );
	}

	$nb_pbs += $self->check_consistency();

	# build exclude patterns
	$self->make_patterns();

	# add control on afick internals
	# it is very important to add control files after rules from config file
	# as control files will overload any bad rules from config file
	# and allow_overload is not tested here
	$self->_auto_control_prepare();

	# debug
	$self->print_directives() if Afick::Msg->get_msg_level();

	Afick::Msg->debug( '-------- end of config file -------------', D1 );
	return $nb_pbs;
}
################################################################
# for compatibility with old code from afick-common
sub get_configuration($$$$$$$) {
	my $self          = shift @_;
	my $config        = shift @_;    # config file name
	my $rh_macro      = shift @_;    # result : hash of macros
	my $rh_alias      = shift @_;    # result : hash of aliases
	my $rh_directives = shift @_;    # result : hash of directives
	my $rh_rules      = shift @_;    # result : hash or rules
	my $rh_only       = shift @_;    # result : hash of only

	$self->set_configfile($config);
	$self->read_configuration();

	%{$rh_macro}      = $self->macros();
	%{$rh_alias}      = $self->aliases();
	%{$rh_directives} = $self->directives();
	%{$rh_rules}      = $self->rules();
	%{$rh_only}       = $self->rules_only();

	return;
}
################################################################
# print some type of configuration
sub print_config($$$$$$) {
	my $self           = shift @_;
	my $flag_directive = shift @_;    # true to print directives
	my $flag_macro     = shift @_;    # true to print macros
	my $flag_alias     = shift @_;    # true to print aliases
	my $flag_rule      = shift @_;    # true to print rules
	my $flag_all =
	  shift @_; # true to print all config, else print only changes from default

	if ($flag_directive) {
		$self->print_directives($flag_all);
	}

	if ($flag_macro) {
		$self->print_macros($flag_all);
	}

	if ($flag_alias) {
		$self->print_aliases($flag_all);
	}

	if ($flag_rule) {
		$self->print_rules();
	}

	return;
}
################################################################
# rules
################################################################
# add a rule (any type : neg, equal, regular)
sub addrule($$$$$$$$) {
	my $self      = shift @_;
	my $name      = shift @_;    # full path name
	my $attribute = shift @_;    # (config format) or 0 for negative rule
	my $control   = shift @_;    # if true, can not be excluded
	my $rh_seen   = shift @_;    # for duplicates
	my $r_line    = shift @_;    # ref to line
	my $line_id   = shift @_;    # config line number
	my $only      = shift @_;    # flag for equal selections
	                             # 0 now
	                             # 1 onlythis
	                             # 2 onlydir

	# control files are not checked for duplicates
	if ($control) {

		# all files should be normalized
		$name = reg_name($name);
		$self->{'rules_control'}{$name} = 1;
	}
	elsif ( $self->_check_duplicate( $name, $rh_seen, 'rule' ) ) {
		if ( $self->get_directive('allow_overload') ) {

			# ok : this is allowed
			Afick::Msg->debug( "(addrule) allow_overload $name", D3 );
		}
		else {

			# error
			Afick::Msg->set_error("(addrule) allow_overload problem on $name");
			$self->_trait_line_error( $r_line, $line_id, 0, 'rule' );
			return 1;
		}
	}

	# check if file exists
	if ( !is_anyfile($name) ) {

		Afick::Msg->debug( "(addrule) $name does not exist", D3 );
		$self->_trait_line_error( $r_line, $line_id, 1, 'rule' );
		return 1;
	}

	if ($attribute) {

		# check if attribute syntaxe is ok
		my $masq = $self->check_alias($attribute);
		if ($masq) {

			if ( $only == 1 ) {
				$self->{'rules_onlythis'}{$name} = $only;
			}
			elsif ( $only == 2 ) {
				$self->{'rules_onlydir'}{$name} = $only;
			}

			$self->_add_key( $name, $rh_seen, $line_id );
			push @{ $self->{'rules_byorder'} }, $name;
			$self->{'rules_toscan'}{$name} = $masq;
			Afick::Msg->debug( "(addrule) add $name ($masq)", D3 );

			return 0;
		}
		else {
			Afick::Msg->set_error("(addrule) bad masq for $name ($attribute)");
			$self->_trait_line_error( $r_line, $line_id, 0, 'rule' );
			return 1;
		}
	}
	else {

		# to be removed
		$self->_add_key( $name, $rh_seen, $line_id );
		$self->add_negrule($name);
		return 0;
	}
}
################################################################
# add a negative rule/ exception (do not monitor)
sub add_negrule($$) {
	my $self = shift @_;
	my $name = shift @_;    # full path to file

	push @{ $self->{'rules_byorder'} }, $name;
	$self->{'rules_toscan'}{$name} = 0;
	Afick::Msg->debug( "(addrule) add exception $name", D3 );
	return 0;
}
################################################################
# return all hash
sub rules() {
	my $self = shift @_;

	return %{ $self->{'rules_toscan'} };
}

#--------------------------------------------------------------
# return undef if the key is not in the rule list
# else return the masq ( may be 0 for an exception)
sub to_scan($) {
	my $self = shift @_;
	my $key  = shift @_;    # file name

	if ( exists $self->{'rules_toscan'}{$key} ) {
		return $self->{'rules_toscan'}{$key};
	}
	else {
		return;
	}
}

#--------------------------------------------------------------
# get masq for a file
sub get_masq($$$) {
	my $self = shift @_;
	my $key  = shift @_;    # file name
	my $masq = shift @_;    # herited masq

	# is there a special masq ?
	if ( defined $self->to_scan($key) ) {
		$masq = $self->to_scan($key);

		Afick::Msg->debug( "(parcours) change masq to $masq for $key", D2 );
	}
	elsif ( !$masq ) {

		# heritage, set to all by default (ex : -l action)
		$masq = $self->get_alias('all');
		Afick::Msg->debug( "(parcours) masq set to all for $key", D2 );
	}
	else {
		# heritage : keep herited masq
	}
	return $masq;
}

#--------------------------------------------------------------
# to get the inherited masq
sub get_parent($$) {
	my $self = shift @_;
	my $fic  = shift @_;    # file name

	my %rules = $self->rules();    # rules defined in config file
	                               # get masq from parents
	my ( $masq, $parent ) = rech_parent( $fic, \%rules );
	if ( defined $masq ) {

		Afick::Msg->debug( "scan option for file $fic : $masq", D2 );
		return ( $parent, $masq );
	}
	else {
		Afick::Msg->warning("can not scan $fic : no rules found");
		return;
	}
}

#--------------------------------------------------------------
# return true is key is an exception rule (!)
sub is_exception($) {
	my $self = shift @_;
	my $key  = shift @_;    # file name

	#	  if ( ( exists $self->{'rules_toscan'}{$key} )
	#		  && ( $self->{'rules_toscan'}{$key} eq '0' ) ){
	#		  Afick::Msg->debug("is_exception $key", D4);
	#		  return 1;
	#	  }
	#	  else {
	#		  Afick::Msg->debug("not an exception $key", D4);
	#		  return 0;
	#	  }
	return ( ( exists $self->{'rules_toscan'}{$key} )
		  && ( $self->{'rules_toscan'}{$key} eq '0' ) );
}

#--------------------------------------------------------------
# return true if the file should not be scanned
# else return false to be scanned
sub file_exceptions($$$) {
	my $self = shift @_;
	my $key  = shift @_;    # full path to file name
	my $fic  = shift @_;    # basename ( $key )

	# stop controls for file
	my $ret;
	if ( $self->is_control($key) ) {

		# no exclude on control files
		Afick::Msg->debug( "(parcours) scan control $key", D2 );
		$ret = 0;
	}
	elsif ( $self->get_directive('only_suffix') ) {
		$ret = !$self->test_only_suffix($key);
	}
	else {
		# true if one of the 3 tests is true
		# be careful : test_exclude_prefix works on file without path
		$ret =
		     $self->test_exclude_prefix($fic)
		  || $self->test_exclude_re($key)
		  || $self->test_exclude_suffix($key);
	}
	Afick::Msg->debug( "(file_exceptions) key $key fic=$fic ret=$ret", D4 );
	return $ret;
}

#--------------------------------------------------------------
# we have to keep a list of object to scan different from config file
# because
# 1 rules order may be important, by example for print_rule
# 2 in case of --list option
sub rules_byorder() {
	my $self = shift @_;

	return @{ $self->{'rules_byorder'} };
}
################################################################
# in file list mode, scan a given list, not all the config file
sub set_file_list($$) {
	my $self    = shift @_;
	my $ra_list = shift @_;    # array of file names to add
	Afick::Msg->debug_begin();

	# we first clear the list
	@{ $self->{'rules_byorder'} } = ();

	# set file mode
	$self->set_filemode(1);

	my %rules   = $self->rules();    # rules defined in config file
	my $control = 0;
	my $nb_ok   = 0;
	my $line    = EMPTY;
	my $line_id = 0;
	my $only    = 0;
	foreach my $fic ( @{$ra_list} ) {

		# get masq from parents
		my $masq = ( rech_parent( $fic, \%rules ) )[0];
		if ($masq) {

			# rem : addrule add file to rules_byorder
			my $attribute = $self->decode_alias($masq);
			$self->addrule( $fic, $attribute, $control, undef, \$line, $line_id,
				$only );
			Afick::Msg->debug( "scan option for file $fic : $masq", D2 );

			$nb_ok++;
		}
		else {
			Afick::Msg->warning("can not scan $fic : no rules found");
		}
	}

	Afick::Msg->debug_end();
	return $nb_ok;
}

#---------------------------------------------------------------
# set filemode status
sub set_filemode($$) {
	my $self = shift @_;
	my $mode = shift @_;

	$self->{'filemode'} = $mode;

	return;
}

#---------------------------------------------------------------
# get filemode status
sub is_filemode($) {
	my $self = shift @_;

	return $self->{'filemode'};
}
################################################################
# is used to stop the recurse search on this element
# it is only interesting on directories
sub rules_onlythis() {
	my $self = shift @_;

	return %{ $self->{'rules_onlythis'} };
}

#--------------------------------------------------------------
# return true if file has the property onlythis
sub is_onlythis($) {
	my $self = shift @_;
	my $key  = shift @_;    # file name

	return ( exists $self->{'rules_onlythis'}{$key} );
}

#--------------------------------------------------------------
sub rules_onlydir() {
	my $self = shift @_;

	return %{ $self->{'rules_onlydir'} };
}

#--------------------------------------------------------------
# return true if file has the property onlydir
sub is_onlydir($) {
	my $self = shift @_;
	my $key  = shift @_;    # file name

	return ( exists $self->{'rules_onlydir'}{$key} );
}

#--------------------------------------------------------------
# return all equal rules in a hash for get_configuration
# but we can distinguish onlydir and onlythis by the value (see addrule)
# 1 onlythis
# 2 onlydir
sub rules_only() {
	my $self = shift @_;

	return ( $self->rules_onlydir(), $self->rules_onlythis() );
}
################################################################
# print all rules in same order than config file
# and same format
sub print_rules($) {
	my $self = shift @_;

	foreach my $name ( @{ $self->{'rules_byorder'} } ) {
		my $masq = $self->{'rules_toscan'}{$name};

		if ($masq) {
			my $attribute = $self->decode_alias($masq);

			if ( $self->is_onlythis($name) ) {
				Afick::Msg->info("= $name $attribute");
			}
			elsif ( $self->is_onlydir($name) ) {
				Afick::Msg->info("= $name/ $attribute");
			}
			else {
				Afick::Msg->info("$name $attribute");
			}
		}
		else {

			# negative rule
			Afick::Msg->info("! $name");
		}
	}
	return;
}
################################################################
# auto-control
################################################################
# used by auto-control to know which program names to control
sub get_script_list($) {
	my $self = shift @_;

	# get path from caller
	my ( $progname, $path ) = fileparse($PROGRAM_NAME);

	#Afick::Msg->info( "prog=$progname path=$path PROGRAM_NAME=$PROGRAM_NAME");

	# add all afick's files
	my $search;
	if ( $self->get_directive('allow_relativepath') ) {

		# relative path
		$search = $path;
	}
	else {

		# convert in absolute path
		$search = abs_path($path) . q{/};
	}
	Afick::Msg->debug( "search=$search", D4 );

	# do not know why, but the glob sub produce a core dump
	# on my linux box (perl-5.8.1-0.RC4.3.3.92mdk)
	# but not the bsd_glob !
	my @list = bsd_glob( $search . 'afick*' );
	push @list, $search . $progname;

	# apply case
	if ( $self->get_directive('ignore_case') ) {
		foreach my $elem (@list) {
			$elem = lc $elem;
		}
	}

	Afick::Msg->debug( "(get_script_list) list = @list", D3 );

	return @list;
}
#######################################################
# add internal afick files for auto-control :
# - perl scripts
# - config files
# for databases, we have to wait for open and type detect
# look at auto_control_prepdb
sub _auto_control_prepare($$) {
	my $self = shift @_;

	Afick::Msg->debug( 'auto_control_prepare', D4 );

	# exemple to debug some code
	#my $old_debug = $self->get_directive('debug');
	#$self->set_directive('debug', 4);

	# control permissions and changes (md5)
	my $check;
	if ( $self->get_directive('allow_relativepath') ) {
		if ( is_microsoft() ) {

			# acl may changes : so no p attribute
			$check = 's+md5';
		}
		else {
			$check = 'p+s+md5';
		}
	}
	else {

		# u+g+p+s+n+md5
		$check = 'P';
	}

	# afick's programs
	my @list = $self->get_script_list();
	foreach my $elem (@list) {
		$self->add_control_file( $elem, $check );
	}

	# afick's configuration file
	$self->add_control_file( $self->get_config_control(), $check );

	# afick's modules : Afick::Msg ...
	foreach my $mod ( keys %INC ) {
		if ( $mod =~ m/^Afick/ ) {
			my $elem =
			  ( $self->get_directive('allow_relativepath') )
			  ? $INC{$mod}
			  : to_abspath( $INC{$mod} );
			$self->add_control_file( $elem, $check );
		}
	}

	# history : partial check
	if ( $self->get_directive('history') ) {
		my $elem =
		  ( $self->get_directive('allow_relativepath') )
		  ? $self->get_directive('history')
		  : to_abspath( $self->get_directive('history') );
		$check = 'p+u+g';
		$self->add_control_file( $elem, $check );
	}

	# do not scan archive
	if ( $self->get_directive('archive') ) {
		my $elem =
		  ( $self->get_directive('allow_relativepath') )
		  ? $self->get_directive('archive')
		  : to_abspath( $self->get_directive('archive') );
		$check = q{};
		$self->add_control_file( $elem, $check );
	}

	# end of debug exemple : restore previous debug level
	#$self->set_directive('debug', $old_debug);

	return;
}

#--------------------------------------------------------------
# low-level to add one control file
sub add_control_file($$$) {
	my $self      = shift @_;
	my $fic       = shift @_;    # filename
	my $attribute = shift @_;    # config format

	my $control = 1;
	my $line    = EMPTY;
	my $line_id = 0;
	my $only    = 0;

	my $err =
	  $self->addrule( $fic, $attribute, $control, undef, \$line, $line_id,
		$only );
	if ($err) {
		Afick::Msg->warning(
			"(add_control) : problem to add control file $fic : "
			  . Afick::Msg->get_error() );
	}
	else {
		Afick::Msg->debug( "(control) add file $fic $attribute", D3 );
	}
	return $err;
}

#--------------------------------------------------------------
# return hash of controlled files
sub control($) {
	my $self = shift @_;

	return %{ $self->{'rules_control'} };
}

#--------------------------------------------------------------
# return true is file is in control list
sub is_control($$) {
	my $self = shift @_;
	my $key  = shift @_;

	return exists $self->{'rules_control'}{$key};
}
#######################################################
1;
