#!/usr/bin/env perl
###############################################################################
#   afick_planning.pl
#      it's a part of the afick project
#
#    Copyright (C) 2002-2004 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# batch job for afick software on windows (same as afick_cron)
# the problem is to alert the user if something change
# on unix, cron send mails, but on windows, it could be difficult to find a smtp server
# so we will use MessageBox
###############################################################################

use strict;
use warnings;

# Windows specific module
use Win32;    # MsgBox

use Net::SMTP;
use English '-no_match_vars';
use Getopt::Long;
use Pod::Usage;

my $Version = '1.4';

###############################################################################
sub is_mail($) {
	my $r_macros = shift @_;

	if ( defined $r_macros ) {
       
		return ( ( $r_macros->{'MAILTO'} ) and ( $r_macros->{'MAILHOST'} ) );
	}
	else {
		return 0;
	}
}
###############################################################################
sub send_mail($$) {
	my $message  = shift @_;
	my $r_macros = shift @_;

	my $dest     = $r_macros->{'MAILTO'};
	my $mailhost = $r_macros->{'MAILHOST'};

	my $smtp = Net::SMTP->new($mailhost);
         print $smtp->domain,"\n";
	if ($smtp) {
		$smtp->mail( $ENV{'USERNAME'} ) or warn "problem on mail method\n";
		if ( exists $r_macros->{'MAILAUTH'} ) {
			$smtp->auth( split /,/, $r_macros->{'MAILAUTH'} )
			  or warn "problem on auth method\n";
		}
		$smtp->to($dest)               or warn "problem on to method\n";
		$smtp->data()                  or warn "problem on data method\n";
		$smtp->datasend("To: $dest\n") or warn "problem on datasend method\n";
		$smtp->datasend( 'From: afick@' . $ENV{'COMPUTERNAME'} . "\n" );
		$smtp->datasend("Subject: [AFICK] Daily report\n");
		$smtp->datasend( 'Date: ' . localtime() . "\n" );
		$smtp->datasend("\n");
		$smtp->datasend( $message . "\n" );
		$smtp->dataend() or warn "problem on dataend method\n";
		$smtp->quit()    or warn "problem on quit method\n";

		print "send mail to $dest by $mailhost\n";
	}
	else {
		warn "problem to connect smtp to $mailhost\n";
	}

	return;
}
###############################################################################
# low-level message subroutine
# open a messagebox
sub message_box($) {
	my $message = shift @_;

	Win32::MsgBox( $message, 0, 'Afick\'s messages' );
	return;
}
###############################################################################
# send a message and exit
sub send_warning($;$) {
	my $message  = shift @_;
	my $r_macros = shift @_;


	if ( is_mail($r_macros) ) {

		send_mail( $message, $r_macros );
	}
	else {
		#message_box($message);
	}
	#die $message . "\n";
        print $message;
        print "\n";
}
###############################################################################
# for debugging
sub send_debug($) {
	my $message = shift @_;

	message_box($message);
	return;
}
###############################################################################
# read config file and populate an hash-table
sub read_macros($) {
	my $file = shift @_;

	my %mac;

	if ( open my $fh_config, '<', $file ) {
		while ( my $ligne = <$fh_config> ) {
			chomp $ligne;

			# skip comments
			next if ( $ligne =~ m/^\s*#/ );

			# search macros
			if ( $ligne =~ m/\@\@define (\w+) (.*)/ ) {
				$mac{$1} = $2;
			}
		}
		close $fh_config
		  or send_warning("can not close config file $file : $ERRNO");
	}
	else {
		send_warning("can not open afick's config file $file : $ERRNO");
	}
	return %mac;
}
###############################################################################
# 				MAIN
###############################################################################
while (1) {
my %opt;
Getopt::Long::Configure('no_ignore_case');
if ( !GetOptions( \%opt, 'version|V', 'help|h', 'man', ) ) {
	pod2usage('incorrect option');
}

if ( exists $opt{'version'} ) {
	print "$PROGRAM_NAME version $Version\n";
	exit;
}
elsif ( exists $opt{'help'} ) {
	pod2usage(1);
}
elsif ( exists $opt{'man'} ) {
	pod2usage( -verbose => 2 );
}

my $afick = 'afick.pl';                       # afick's program name
my $conffile = $ARGV[0] || 'windows.conf';    # afick's config file

# debug
#send_debug("afick_planning begin");

# check if afick exists
send_warning("afick's executable $afick not found") unless ( -f $afick );

# check if config file exists
send_warning("afick's configuration file $conffile not found")
  unless ( -f $conffile );

my %macros = read_macros($conffile);

# set default if necessary
$macros{'BATCH'}   = 1    unless ( exists $macros{'BATCH'} );
$macros{'VERBOSE'} = 0    unless ( exists $macros{'VERBOSE'} );
$macros{'REPORT'}  = 1    unless ( exists $macros{'REPORT'} );
$macros{'MAILTO'}  = 0    unless ( exists $macros{'MAILTO'} );
$macros{'LINES'}   = 1000 unless ( exists $macros{'LINES'} );
$macros{'ARCHIVE_RETENTION'} = 0 unless ( exists $macros{'ARCHIVE_RETENTION'} );

exit unless ( $macros{'BATCH'} );

# notes : some macros are not used on windows
# NICE , MOUNT
# NAGIOS and co

# launch afick
#send_debug("launch afick");
print "TEST1\n";
## no critic (ProhibitBacktickOperators)

print "TEST2\n";
my @output = `perl -w $afick -c $conffile --update`;
print "TEST3\n";

# archive retention management
if ( $macros{'ARCHIVE_RETENTION'} ) {
print "TEST4\n";
	`perl -w afick_archive.pl -c $conffile -H -k $macros{'ARCHIVE_RETENTION'}`;
}
print "TEST5\n";
#send_debug("afick end");
return unless ( $macros{'REPORT'} );
print "TEST6\n";
# remove comments and blank lines
my @changes = grep { !/^#|^$/ } @output;
print "TEST7\n";
# get summary
my @summary = grep /files scanned/, @output;
print "TEST8\n";
# test result : we skip all comments and blank
if ( scalar @changes ) {

print "TEST";

	# we have to trunk the report if size is greater than LINES lines
	my $max = scalar @output;
	if ( $max > $macros{'LINES'} ) {
		my @temp = @output[ 0 .. $macros{'LINES'} ];
		@output = @temp;
	}
	send_warning( "WARNING : afick detects changes : @output", \%macros );
}
elsif ( $macros{'VERBOSE'} ) {
	send_warning( "INFO : afick's run is clean : @summary", \%macros );
}
elsif ( scalar(@summary) == 0 ) {
	send_warning( 'WARNING : can not find  summary', \%macros );
}

sleep (60);

}

__END__

=head1 NAME

afick_planning - code to be executed by windows service planning

=head1 DESCRIPTION

C<afick_planning> is a perl script over afick.pl, which use configuration
macro. It is designed to be executed by windows service planning.
The output may be sent to a windows box, or by mail.

=head1 SYNOPSIS

afick_planning.pl  [L<options|/options>] 

=head1 REQUIRED ARGUMENTS

=head1 OPTIONS

=over 4

=item --help|-h

Output help information and exit.

=item --man

Output full help information and exit.

=item --version|-V

Output version information and exit.

=back

=head1 USAGE

C<afick_planning.pl>

=head1 NOTES

this program only use perl and its standard modules.

=head1 SEE ALSO

=for html
<a href="afick.conf.5.html">afick.conf(5)</a> for the configuration file syntax
<br>
<a href="afick-tk.1.html">afick-tk(1)</a> for the graphical interface
<br>
<a href="afick.1.html">afick(1)</a> for the command-line interface
<br>
<a href="afickonfig.1.html">afickonfig(1)</a> for a tool to change afick's configuration file
<br>
<a href="afick_archive.1.html">afick_archive(1)</a> for a tool to manage archive's reports
<br>
<a href="afick_learn.1.html">afick_learn(1)</a> for a learning tool

=for man
\fIafick.conf\fR\|(5) for the configuration file syntaxe
.PP
\fIafick\-tk\fR\|(1) for the graphical interface
.PP
\fIafick\fR\|(1) for the command-line interface
.PP
\fIafickonfig\fR\|(1) for a tool to change afick's configuration file
.PP
\fIafick_archive\fR\|(1) for a tool to manage archive's reports
.PP
\fIafick_learn\fR\|(1) for a learning tool

=head1 DIAGNOSTICS


=head1 EXIT STATUS

0

=head1 CONFIGURATION

it does not use afick's configuration file

=head1 DEPENDENCIES

perl, afick common library

=head1 INCOMPATIBILITIES

none

=head1 BUGS AND LIMITATIONS

input format can be txt or html, not xml
output format can be txt, html, or xml

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2002 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your option)
any later version.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net
