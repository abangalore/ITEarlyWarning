goal
----
the goal of this project is to write another file integrity checker :
- portable without any change to all common os (unix, windows)
- with a minimum of dependencies
- quick
- config file with exceptions and "jokers"
- display new, delete and modified files
- use by any user
- any number of base and config files
- syntaxe close from aide's or tripwire's one

history
-------
I was using integrity checking tools on linux (aide) for a long time. So when I
got my first PC on windows, I search for a similar tool (freeshmeat), but do not
find anything ready to use.

I then decided to write my own, with the goal below.
my choice are :
perl as language : for portability, no need to compile, acces to source code
MD5 for checksum : quick and in perl standard package
sdbm database for storage : not clear text, ease of use

I test it on windows XP, redhat linux 7.1 and 7.3
and it seems as fast as a C tool (aide) (see http://afick.sourceforge.net/perf.html)

config file format :
--------------------
see afick.conf man page or comments in config file sample (linux.conf, windows.conf)

usage
-----
1) first choice what you want to check. a base is given in file 
- windows.conf (for windows xp)
- linux.conf (for linux)
you may edit and modify this file for your needs
(please send me your changes if they may help others users)

2) then create the database :
./afick -c your_config_file -i

3) compare regulary your filee with the database (each day ?). You have 3 possibilities :

3.1) just check some files
./afick -c your_config_file -l "file1 $file2  ...filen"

3.2) check all your config 
./afick -c your_config_file -k

3.3) check your config and update the database
./afick -c your_config_file -u

4) you can print the content of the database with 
./afick -c your_config_file -p

main site
---------
the main page for afick project is http://afick.sourceforge.net

--
$Id$
