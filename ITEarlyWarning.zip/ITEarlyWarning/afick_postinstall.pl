#!/usr/bin/env perl
###############################################################################
#    Copyright (C) 2002-2204 by Eric Gerbier
#    Bug reports to: gerbier@users.sourceforge.net
#    $Id$
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
###############################################################################
# this script is to be called at end of install
# it is in perl to allow it to work on windows

use strict;
use warnings;

use Getopt::Long;      # option analysis
use File::Basename;    # dirname
use File::Spec;        # rel2abs
use English qw(-no_match_vars);

my $Version = '0.7';

#############################################################
# just display program version
sub version($) {
	my $version = shift @_;
	print "\n";
	print
"afick_postinstall : another file integrity checker configurator\nversion $version\n";
	return;
}
#############################################################

# afick library
# it is used on post-install, so all should be ok
my $dirname = File::Spec->rel2abs( dirname($PROGRAM_NAME) );
require $dirname . '/afick-common.pl';

my $config = Afick::Cfg->new();

$OUTPUT_AUTOFLUSH = 1;

# arg line
my %opt;
Getopt::Long::Configure('no_ignore_case');
if (
	!GetOptions(
		\%opt, 'config_file|c=s', 'help|h', 'man', 'verbose|v', 'version|V',
	)
  )
{
	pod2usage('incorrect option');
}
if ( exists $opt{'help'} ) {

	# -h : help
	pod2usage(1);
}
elsif ( exists $opt{'man'} ) {
	pod2usage( -verbose => 2 );
}
elsif ( exists $opt{'version'} ) {

	# -V : version
	version($Version);
	exit;
}

if ( exists $opt{'verbose'} ) {
	$config->set_directive( 'verbose', $opt{'verbose'} );
}

my $opt_configfile = $opt{'config_file'};
if ($opt_configfile) {
	$config->set_configfile($opt_configfile);
}
else {
	# get default config
	$opt_configfile = $config->get_configfile();
}
Afick::Msg->debug("configuration file is $opt_configfile");

# first : create empty history file if a new install (not an upgrade)
# to avoid clean_config to remove directive

# get history file name from configuration file
$config->read_configuration(0);
my $history = $config->get_directive('history');

# create it if necessary
touch($history) if ($history);

# second : append local config file to config file if it exists
# to avoid duplicate copying, we read first until the mark then write
# (just append at end may append many times the same lines)
# be carefull : this is also defined in afick_preinstall !
my $mark         = 'put your local config below';
my $local_config = $opt_configfile . '.local';

# read current config to mark and store
Afick::Msg->debug('modify configuration file');

# no critic (RequireBriefOpen)
my $fh_config;
if ( !open $fh_config, '<', $opt_configfile ) {
	die "can not read $opt_configfile : $ERRNO\n";
}
my @config;
LOOP: while (<$fh_config>) {
	push @config, $_;
	last LOOP if (m/$mark/);
}
close $fh_config
  or Afick::Msg->warning("can not close $opt_configfile : $ERRNO");

Afick::Msg->debug('rewrite config');

# rewrite it
if ( !open $fh_config, '>', $opt_configfile ) {
	die "can not write to $opt_configfile : $ERRNO\n";
}
foreach my $line (@config) {
	print {$fh_config} $line;
}

# add local config
Afick::Msg->debug('add local config');
if ( -s $local_config ) {
	my $fh_local;
	if ( open $fh_local, '<', $local_config ) {

		while (<$fh_local>) {
			print {$fh_config} $_;
			Afick::Msg->debug("copy line $_");
		}
		close $fh_local
		  or Afick::Msg->warning("can not close $local_config : $ERRNO");
	}
	else {
		Afick::Msg->warning("can not open $local_config : $ERRNO");
	}
	close $fh_config
	  or Afick::Msg->warning("can not close $opt_configfile : $ERRNO");

	# remove local config
	unlink $local_config;
}

# third : clean configuration
Afick::Msg->debug('clean configuration');
Afick::Msg->debug("path = $dirname");
system $EXECUTABLE_NAME, $dirname . '/afickonfig.pl', '-c', $opt_configfile,
  '--clean_config';
system $EXECUTABLE_NAME, $dirname . '/afickonfig.pl', '-c', $opt_configfile,
  '--addpath', '--addlib';

__END__

=head1 NAME

afick_postinstall - post installation script

=head1 DESCRIPTION

C<afick_postinstall>  works with afick_preinstall.pl.
it is used on upgrade, to change afick's configuration defaults
and keep user's configuration (using a mark in configuration file)
It use the '.local' file containing this config, done by afick_preinstall.pl.
It is also 'cleaning' the configuration file.

=head1 SYNOPSIS

afick_postinstall.pl  [L<options|/options>] 

=head1 REQUIRED ARGUMENTS

afick's configuration file

=head1 OPTIONS

=over 4

=item --config_file|-c

full path to afick's configuration file

=item --help|-h

Output help information and exit.

=item --man

Output full help information and exit.

=item --version|-V

Output version information and exit.

=item --verbose|-v

add debugging messages

=back

=head1 USAGE

C<afick_postinstall.pl -c afick.conf>

=head1 NOTES

this program only use perl and its standard modules.

=head1 SEE ALSO

=for html
<a href="afick.conf.5.html">afick.conf(5)</a> for the configuration file syntax
<br>
<a href="afick-tk.1.html">afick-tk(1)</a> for the graphical interface
<br>
<a href="afick.1.html">afick(1)</a> for the command-line interface
<br>
<a href="afickonfig.1.html">afickonfig(1)</a> for a tool to change afick's configuration file
<br>
<a href="afick_archive.1.html">afick_archive(1)</a> for a tool to manage archive's reports
<br>
<a href="afick_learn.1.html">afick_learn(1)</a> for a learning tool

=for man
\fIafick.conf\fR\|(5) for the configuration file syntaxe
.PP
\fIafick\-tk\fR\|(1) for the graphical interface
.PP
\fIafick\fR\|(1) for the command-line interface
.PP
\fIafickonfig\fR\|(1) for a tool to change afick's configuration file
.PP
\fIafick_archive\fR\|(1) for a tool to manage archive's reports
.PP
\fIafick_learn\fR\|(1) for a learning tool

=head1 DIAGNOSTICS

=head1 EXIT STATUS

0

=head1 CONFIGURATION

the afick's configuration file is required and modified

=head1 DEPENDENCIES

perl, afick common library

=head1 INCOMPATIBILITIES

none

=head1 BUGS AND LIMITATIONS

=head1 LICENSE AND COPYRIGHT

Copyright (c) 2002 Eric Gerbier
All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

=head1 AUTHOR

Eric Gerbier

you can report any bug or suggest to gerbier@users.sourceforge.net
